Scripted Amiga Emulator
=======================

Amiga Emulator in javascript and HTML5.

Visit http://scriptedamigaemulator.net