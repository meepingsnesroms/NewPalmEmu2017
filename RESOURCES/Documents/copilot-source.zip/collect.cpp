/////////////////////////////////////////////////////////////////////////////
// Collection.cpp
//
// Simple task specifc collection classes
/////////////////////////////////////////////////////////////////////////////

#include "OurTypes.h"
#include "Collect.h"

// Map pointer to pointer

MapPP::MapPP()
{
	m_pe = NULL;
	m_cMac = 0;
	m_cMax = 0;
}

MapPP::~MapPP()
{
	delete m_pe;
}

bool MapPP::Add(void *pvKey, void *pv)
{
	// If it's not already in the list, add it

	for (ElemPP *pe = m_pe; pe < &m_pe[m_cMac]; pe++) {
		if (pe->pvKey == pvKey)
			return FALSE;
	}

	// alloc the space if needed

	if (m_cMax == m_cMac) {
		ElemPP *peT = new ElemPP[m_cMax + kcElemAlloc];
		if (peT == NULL)
			return FALSE;
		if (m_pe != NULL) {
			memcpy(peT, m_pe, sizeof(ElemPP) * m_cMac);
			delete m_pe;
		}
		m_pe = peT;
		m_cMax += kcElemAlloc;
	}

	// Put the new element in

	m_pe[m_cMac].pvKey = pvKey;
	m_pe[m_cMac].pv = pv;
	m_cMac++;

	return TRUE;
}

bool MapPP::Remove(void *pvKey)
{
	// Find it in the list - if not there, error

	for (int i = 0; i < m_cMac; i++) {
		if (m_pe[i].pvKey == pvKey) {
			// Found it - move everything down one

			memcpy(&m_pe[i], &m_pe[i + 1], (m_cMac - i - 1) * sizeof(ElemPP));
			m_cMac--;
			return TRUE;
		}
	}

	return FALSE;
}

bool MapPP::At(int i, void **ppvKey, void **ppv)
{
	if (i >= m_cMac || i < 0)
		return FALSE;

	*ppvKey = m_pe[i].pvKey;
	*ppv = m_pe[i].pv;

	return TRUE;
}

int MapPP::Find(void *pvKey, void **ppv)
{
	// Find it in the list - if not there, error

	for (int i = 0; i < m_cMac; i++) {
		if (m_pe[i].pvKey == pvKey) {
			*ppv = m_pe[i].pv;
			return i;
		}
	}

	return -1;
}

// Maintains a list of non-unique pointers

ListP::ListP()
{
	m_pe = NULL;
	m_cMac = 0;
	m_cMax = 0;
}

ListP::~ListP()
{
	delete m_pe;
}

bool ListP::Add(void *pv)
{
	// alloc the space if needed

	if (m_cMax == m_cMac) {
		ElemLP *peT = new ElemLP[m_cMax + kcElemAlloc];
		if (peT == NULL)
			return FALSE;
		if (m_pe != NULL) {
			memcpy(peT, m_pe, sizeof(ElemLP) * m_cMac);
			delete m_pe;
		}
		m_pe = peT;
		m_cMax += kcElemAlloc;
	}

	// Put the new element in

	m_pe[m_cMac].pv = pv;
	m_cMac++;

	return TRUE;
}

bool ListP::Remove(int i)
{
	// Make sure it's within the list

	if (i >= m_cMac || i < 0)
		return FALSE;

	// Found it - move everything down one

	memcpy(&m_pe[i], &m_pe[i + 1], (m_cMac - i - 1) * sizeof(ElemLP));
	m_cMac--;
	return TRUE;
}

void *ListP::At(int i)
{
	if (i >= m_cMac || i < 0)
		return NULL;

	return m_pe[i].pv;
}

int ListP::Find(void *pv, int i)
{
	// Find it in the list starting at i - if not there, error

	if (i < 0)
		return -1;

	while (i < m_cMac) {
		if (m_pe[i].pv == pv)
			return i;
		i++;
	}

	return -1;
}
