// persistent settings support

class TSettings {
public:
  TSettings();
  void Save(HWND hwnd);
  void UpdateMru(const char *name);
  enum {MRU_COUNT = 5};

  POINT Window;
  int Scale;
  BOOL Realistic;
  BOOL Backlight;
  BOOL Sounds;
  DWORD FPS;
  DWORD RamSize;
  char CommPort[MAX_PATH];
  BOOL DebugAtStartup;
  char PrcPath[MAX_PATH];
  char PrcMru[MRU_COUNT][MAX_PATH];
  char RomFile[MAX_PATH];
};

extern TSettings Settings;
