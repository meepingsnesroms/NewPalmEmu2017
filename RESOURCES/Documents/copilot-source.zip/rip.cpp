/////////////////////////////////////////////////////////////////////////////
// rip.cpp
/////////////////////////////////////////////////////////////////////////////
//
// This module contains support for communicating errors or messages to a
// developer or tester.
/////////////////////////////////////////////////////////////////////////////

#include <Windows.h>
#include "RIP.h"

#if defined(_DEBUG)

#define kszAppName "Copilot"
char *gpszRipFile;
int giRipLine;

/////////////////////////////////////////////////////////////////////////////
// DoRip
//
// Gets called to output a message to a developer or tester. Does one of 3
// things depending on what debug options are set in win.ini, [copilot]
// section, with the key of "RipOptions". If set to:
//
// 0: Means break if being debugged, otherwise put up a message box
// 1: Always put up a message box
// 2: Always break (nice for JIT debugging)
// 3: Ignore the rip, just output the debug string
//
// 02-28-95 ScottLu     Created.
/////////////////////////////////////////////////////////////////////////////

const DWORD kidBreakIfDebugged = 0;
const DWORD kidMsgbox = 1;
const DWORD kidBreak = 2;
const DWORD kidIgnore = 3;

void DoRip(char *pszTitle, char *psz, va_list va)
{
    int idT;
    BOOL fBeingDebugged;
    static BOOL gfRipActive = FALSE;

    // If gpszRipFile is not NULL, Format the string
    // "File: name.cpp, Line: nnn, ..."
    // Otherwise, format the string without the File/Line info.

    char szT[256];
    char szT1[128];
    wvsprintf(szT1, psz, va);

    if (gpszRipFile != NULL)
        wsprintf(szT, "\n%s: File: %s, Line: %d. %s\n", pszTitle, gpszRipFile, giRipLine, szT1);
    else
        wsprintf(szT, "%s: %s", pszTitle, szT1);

    // Find out what we're supposed to do with this string

    idT = GetProfileInt("Rip", "RipOption", kidMsgbox);

    switch (idT) {
    case kidBreakIfDebugged:
        // This'll break into the debugger if the debugger is present,
        // otherwise it'll fall through to the message box case.

        OutputDebugString(szT);

        fBeingDebugged = TRUE;
        try {
            _asm {
                int 3;
            }
        } catch (...) {
            fBeingDebugged = FALSE;
        }

        if (fBeingDebugged)
			break;
			
        // Fall through to message box case - we know we're not being
        // debugged

    case kidMsgbox:
        // Bring up a message box with these options:
        // Abort: terminate app
        // Retry: break
        // Ignore: keep running

        // We don't want to recurse, which may happen when this message
        // box comes up due to WM_ACTIVATE messages and other being
        // sent back to the app

        if (gfRipActive)
            return;

        gfRipActive = TRUE;
        idT = MessageBox(GetTopWindow(NULL), strchr(szT, ':') + 2, pszTitle,
				MB_ABORTRETRYIGNORE | MB_SETFOREGROUND);
        gfRipActive = FALSE;

        switch (idT) {
        case IDABORT:
            // The process should exit now
            // Terminate the process so we don't go through all that
            // .dll cleanup code. This'll avoid mfc dumping heap
            // allocation info to the debugger, making termination
            // faster.

            TerminateProcess(GetCurrentProcess(), 0);
            break;

        case IDRETRY:
            // Break into the debugger

            goto BreakAlways;

            // Just continue and hope things get better

            return;
        }
        break;

    case kidBreak:
        // Break always. This'll break into the debugger or cause the just
        // in time debugger to load. If neither are present, the app
        // will terminate.
BreakAlways:
        OutputDebugString(szT);

        _asm {
            int 3;
        }
        break;

    case kidIgnore:
        // asserts. Can also be used to ignore asserts.

        OutputDebugString(szT);
        break;
    }
}

void DoAssertRip(BOOL fAssert, char *psz, ...)
{
    if (fAssert)
        return;

    va_list va;
    va_start(va, psz);

    DoRip("Assertion failed!", psz, va);

    va_end(va);
}

void DoAssertRip(BOOL fAssert)
{
    if (!fAssert)
        DoRip("Assertion failed!", "", NULL);
}

void DoWarningRip(BOOL fWarn, char *psz, ...)
{
    if (fWarn || GetProfileInt(kszAppName, "Warnings", 0) == 0)
        return;

    va_list va;
    va_start(va, psz);

    DoRip("Warning!", psz, va);

    va_end(va);
}

void DoWarningRip(BOOL fWarn)
{
    if (!fWarn && GetProfileInt(kszAppName, "Warnings", 0) != 0)
        DoRip("Warning!", "", NULL);
}

void DoBadParamRip(char * psz, ...)
{
    va_list va;
    va_start(va, psz);

    DoRip("Bad parameter!", psz, va);

    va_end(va);
}

void DoGenericRip(char * psz, ...)
{
    va_list va;
    va_start(va, psz);

    DoRip("Rip!", psz, va);

    va_end(va);
}

#endif // _DEBUG
