/*
 * Copilot
 *
 * Console debugger
 *
 * Copyright (c) 1996 Greg Hewgill
 * Original UAE code (c) 1995 Bernd Schmidt
 *
 */

// New features:
// - disassembly output is more sane
// - numeric values can be specified in one of three bases: hex, decimal, 
//   binary by prefixing with '$', '#', '%' respectively
// - unassemble ('u') command accepts ROM symbols for the address
// - an empty command repeats the previous command
// - "set" command and variables
// - _NumLines variable
// - "print" command
// - "printf" command
// - "d<size>" commands dump ascii, bytes, words, or dwords
// - "e<size>" commands enter ascii, bytes, words, or dwords
// - registers can be accessed via .rn (r = a/d, n = 0-7), .sp, and .pc
// - set registers with "set <reg> <expr>"
// - expression evaluation including symbol and variable substitution
//   Operators: +, -, *, /, \, &, |, <<, >>, unary -, unary ~, (, )
//   Types: hex, dec, octal, binary numbers, registers, symbols, variables,
//          single quoted values, e.g., 'Tbmp'
// - where possible all command accept full expressions as their arguments
// - "n" command (show/set radix) matches symdeb
// - "u" syntax matches symdeb plus accepts length arg
// - "r" syntax matches symdeb
// - "t" syntax matches symdeb
// - "p" syntax matches symdeb
// - "g" syntax matches symdeb (but doesn't support multiple stop addresses)
// - "d<size>" syntax matches symdeb
// - "e<size>" syntax matches symdeb
// - "ln" command, syntax matches symdeb
// - stack backtrace command shows symbols
// - "bp" set breakpoint command
// - "bl" list breakpoints command
// - "be" enable breakpoints command
// - "bd" disable breakpoints command
// - "bc" clear breakpoints command
// - "dh" dump handle command
// - "ds" dump active module's symbols
// - "bp -na" break at next app's start address

#include <windows.h>
#include <io.h>
#include <fcntl.h>
#include <stdio.h>
#include <ctype.h>
#include <stdarg.h>

#include "readcpu.h"
#include "romprocnames.h"
#include "debug.h"
#include "RIP.h"

static void __cdecl parse_cmdline(const char *cmdstart, char **argv,
        char *args, int *numargs, int *numchars);

const int kcchCmdMax = 1000;
const long knDefaultBase = 16;
const int kcDefaultLines = 15;
const int kcchInputBuffer = 1024;

#define CFLG (regs.flags.c)
#define NFLG (regs.flags.n)
#define VFLG (regs.flags.v)
#define ZFLG (regs.flags.z)

#define nextiword() (*nextpc += 2, CPU_getword(*nextpc-2))
#define nextilong() (*nextpc += 4, MAKELONG(CPU_getword(*nextpc-2), CPU_getword(*nextpc-4)))

static Debugger *gpdbg;
static long gnDefaultBase = knDefaultBase;
static Module *gpmodActive;
static DWORD nextpc;

ulong GetPC()
{
    CPU_regs regs;
    CPU_getregs(regs);
    return regs.pc;
}

ulong *GetRegPtr(CPU_regs &regs, const char *pszName)
{
    int i;
    char ch;
    CPU_getregs(regs);

    if (*pszName == '.')
        pszName++;

    switch (tolower(*pszName++)) {
    case 'd':
        i = *pszName++ - '0';
        if (i < 0 || i > 7)
            return NULL;
        else
            return &regs.d[i];

    case 'a':
        i = *pszName++ - '0';
        if (i < 0 || i > 7)
            return NULL;
        else
            return &regs.a[i];

    case 's':
        ch = *pszName++;
        if (ch != 'p' && ch != 'P')
            return NULL;
        else
            return &regs.a[7];

    case 'p':
        ch = *pszName++;
        if (ch != 'c' && ch != 'C')
            return NULL;
        else
            return &regs.pc;
    }

    return NULL;
}


void debug(void)
{
    static char szInput[kcchCmdMax];
    static char szPrevCmd[kcchCmdMax];

    gpdbg->printf("debugging...\n");
    CPU_stop();
    read_table68k();
    do_merges();

    gpdbg->DumpCpuState();
    gpdbg->SetVariable(kszNextDisasm, GetPC());
    gpdbg->SetVariable(kszNextDump, (long)0);

    for (;;) {
        gpdbg->printf(">");
        fgets(szInput, kcchCmdMax, stdin);
        int cch = strlen(szInput);
        if (szInput[cch - 1] = '\n')
            szInput[cch - 1] = 0;

        // If no command is specified (user just hit return) then repeat the
        // last command. Otherwise, copy the command for possible repetition.

        Assert(szInput[0] != '\n');        // make sure this doesn't happen
        char *pszCmd;
        if (szInput[0] == 0) {
            pszCmd = szPrevCmd;
        } else {
            strcpy(szPrevCmd, szInput);
            pszCmd = szInput;
        }

        gpdbg->Execute(pszCmd);
   }
}

DWORD CALLBACK DoDebugThread(void *)
{
    AllocConsole();
    SetConsoleTitle("Copilot Debugger");
    // The following is a really disgusting hack to make stdin and stdout attach
    // to the newly created console using the MSVC++ libraries. I hope other
    // operating systems don't need this kind of kludge.. :)
    stdout->_file = _open_osfhandle((long)GetStdHandle(STD_OUTPUT_HANDLE), _O_TEXT);
    stdin->_file  = _open_osfhandle((long)GetStdHandle(STD_INPUT_HANDLE), _O_TEXT);
    debug();
    stdout->_file = -1;
    stdin->_file  = -1;
    FreeConsole();
    CPU_run();
    return 0;
}

HANDLE DebuggerThread;

bool Output(const char *pszOutput)
{
    printf("%s", pszOutput);
    return TRUE;
}

void StartDebugger()
{
    extern bool SysAppLaunchBpHandler(Debugger *pdbg, Bpid bpid);

    if (DebuggerThread) {
        CPU_stop();
        return;
    }

	gpdbg = new Debugger(Output);
    Assert(gpdbg != NULL);

    // Initialize some default debugger variables.

    // Set the number base to 10 before setting the default variables

    gnDefaultBase = 10;

    gpdbg->SetVariable(kszNumLines, kcDefaultLines);
    gpdbg->SetVariable(kszBreakCmd, "r");

    gnDefaultBase = knDefaultBase;

    gpdbg->SetVariable(kszAppStartup, 0x10c0c5e2);

    SetBreakpoint(0x10c0c2c6, kbpidSysAppLaunch, SysAppLaunchBpHandler);
    SetBreakpoint(0x10c0c65e, kbpidSysAppLaunchRts, SysAppLaunchBpHandler);
    SetBreakpoint(0x10c0c5b8, kbpidSysAppLaunchCallApp, SysAppLaunchBpHandler);
    SetBreakpoint(0x10c0c5ea, kbpidSysAppLaunchCallReturn, SysAppLaunchBpHandler);

    DWORD tid;
    DebuggerThread = CreateThread(NULL, 0, DoDebugThread, 0, 0, &tid);
    Assert(DebuggerThread != NULL);

    return;
}


//---------------------------------------------------------------------------
// class Debugger implementation

Debugger::Debugger(bool (*pfnOutput)(const char *pszOutput))
{
    m_pfnOutput = pfnOutput;
    m_pmodHead = NULL;
}

bool Debugger::Execute(const char *pszCmd)
{
    static char szzArgs[kcchInputBuffer];
    static char *apszArgs[kcpszArgsMax];
    int cpszArgs, cchArgs;
    
    Assert(pszCmd != NULL);
    Assert(strlen(pszCmd) < kcchCmdMax, "Command length too long");

    // Parse the pszCmd string into an argument list. Spaces serve as
    // argument delimiters.

    parse_cmdline(pszCmd, apszArgs, szzArgs, &cpszArgs, &cchArgs);

    if (cpszArgs == 0) {
        printf("Error: Type ? for a list of commands.\n");
        return FALSE;
    }

    // Clear out nonexistant arguments so command handlers can take 
    // advantage of their NULLness.

    for (int i = cpszArgs; i < kcpszArgsMax; i++)
        apszArgs[i] = NULL;

    // Pass the argument list to the first command handler. If it doesn't
    // handle the command, pass it on to the next until one of the handlers
    // takes it.

    // UNDONE: only have one handler right now. Add extension registration.

    if (DebugCommandHandler(this, apszArgs, cpszArgs))
        return TRUE;

    // If no handler handles the command let the user know the command
    // is unknown.

    printf("Error: Don't know the command \"%s\". Type ? for a list of commands.\n", 
            apszArgs[0]);

    return FALSE;
}

const int kcchOutputMax = 10000;

bool Debugger::printf(const char *pszFormat, ...)
{
    static char szT[kcchOutputMax];
    va_list vaList;
    va_start(vaList, pszFormat);

    vsprintf(szT, pszFormat, vaList);

    return m_pfnOutput(szT);
}

int Debugger::GetDefaultBase()
{
    return gnDefaultBase;
}

void Debugger::SetDefaultBase(int nBase)
{
    gnDefaultBase = nBase;
}

const char *Debugger::LookupSymbol(VirtualAddress va)
{
    static char buf[80];
    wsprintf(buf, "$%x", va);

    for (Module *pmod = m_pmodHead; pmod != NULL; pmod = pmod->m_pmodNext) {
        if (va >= pmod->m_vaCode && va < pmod->m_vaCode + pmod->m_cbCode) {
            Symbol *psym = pmod->FindSymbol(va);
            if (psym == NULL)
                return buf;

            return psym->pszName;
        }
    }

    if ((va & 0xFFF00000) == 0x10c00000) {
        int left = 0;
        int right = RomProcNameCount-1;
        while (left <= right) {
            int mid = (left + right) / 2;
            if (va == RomProcNames[mid].addr) {
                return RomProcNames[mid].name;
            } else if (va < RomProcNames[mid].addr) {
                right = mid - 1;
            } else {
                left = mid + 1;
            }
        }
    }
    return buf;
}

bool Debugger::FindNearestSymbols(VirtualAddress va,
        char **ppszBefore, long *pcbBOffset, char **ppszAfter, 
        long *pcbAOffset)
{
    for (Module *pmod = m_pmodHead; pmod != NULL; pmod = pmod->m_pmodNext) {
        if (va >= pmod->m_vaCode && va < pmod->m_vaCode + pmod->m_cbCode) {
            return pmod->FindNearestSymbols(va, ppszBefore, pcbBOffset,
                    ppszAfter, pcbAOffset);
        }
    }

    if ((va & 0xFFF00000) != 0x10c00000)
        return FALSE;

    int left = 0;
    int right = RomProcNameCount-1;
    int mid;
    while (left <= right) {
        mid = (left + right) / 2;
        if (va >= RomProcNames[mid].addr && 
                va < RomProcNames[mid + 1].addr) {
            if (ppszBefore != NULL)
                *ppszBefore = (char *)RomProcNames[mid].name;
            if (pcbBOffset != NULL)
                *pcbBOffset = va - RomProcNames[mid].addr;
            if (ppszAfter != NULL)
                *ppszAfter = (char *)RomProcNames[mid + 1].name;
            if (pcbAOffset != NULL)
                *pcbAOffset = RomProcNames[mid + 1].addr - va;
            return TRUE;
        } else if (va < RomProcNames[mid].addr) {
            right = mid - 1;
        } else {
            left = mid + 1;
        }
    }

    Assert(FALSE, "Shouldn't get here!");
    return FALSE;
}

VirtualAddress Debugger::LookupAddress(const char *pszSymbol)
{
    // Check all known modules

    // BUG: Check gpmodActive first

    for (Module *pmod = m_pmodHead; pmod != NULL; pmod = pmod->m_pmodNext) {
        Symbol *psym = pmod->FindSymbol(pszSymbol);
        if (psym != NULL)
            return psym->va;
    }

    // Check the precreated list of ROM symbols

    const TRomProc *prp = RomProcNames;
    for (int i = 0; i < RomProcNameCount; i++) {
        if (stricmp(pszSymbol, prp->name) == 0)
            return prp->addr;
        prp++;
    }

    return 0;
}

Err Debugger::EvalVariable(const char *pszName, long *plValue)
{
    const char *pszVar = GetVariablePtr(pszName);
    if (pszVar == NULL)
        return kerrUndefinedSymbol;

    Err err;
    Evaluate(pszVar, plValue, &err);
    return err;
}

bool Debugger::SetVariable(const char *pszName, const char *pszValue)
{
    return m_vl.Set(pszName, pszValue);
}

bool Debugger::SetVariable(const char *pszName, ulong ulValue)
{
    char szT[35];

    switch (GetDefaultBase()) {
    case 16:
        sprintf(szT, "$%lx", ulValue);
        break;

    case 10:
        sprintf(szT, "#%ld", ulValue);
        break;

    case 2:
        {
            szT[0] = '%';
            for (int i = 31; i >= 0; i--) {
                szT[i + 1] = '0' + (char)(ulValue & 0x00000001);
                ulValue >>= 1;
            }
            szT[33] = 0;
        }
        break;

    default:
        Assert(FALSE, "unsupported number base!");
    }

    return SetVariable(pszName, szT);
}

const char *Debugger::GetVariablePtr(const char *pszName)
{
    return m_vl.Lookup(pszName);
}

bool Debugger::GetVariable(const char *pszName, char *pszValue, 
        int cchValueMax)
{
    char *pszT = m_vl.Lookup(pszName);
    if (pszT == NULL)
        return FALSE;

    strncpy(pszValue, (char *)pszT, cchValueMax - 1);
    return TRUE;
}

bool Debugger::GetVariable(const char *pszName, ulong *pulValue)
{
    char *pszT = m_vl.Lookup(pszName);
    if (pszT == NULL)
        return FALSE;

    Err err;
    Evaluate(pszT, (long *)pulValue, &err);
    if (err != kerrNone) {
        printf("Error: Evaluation error %d\n", err);
        return FALSE;
    }
    return TRUE;
}

Variable *Debugger::GetNextVariable(Position *ppos)
{
    return m_vl.GetNext(ppos);
}

void Debugger::Step()
{
    CPU_regs regs;
    CPU_getregs(regs);

    // Skip over a hard-coded break instruction if we're sitting on one.

    if (CPU_getword(regs.pc) == kopcBreak) {
        regs.pc += 2;
        CPU_setregs(regs);
    } else {
        CPU_step();
        CPU_wait(INFINITE);
        DoBreakpoints(this);
    }
}

void Debugger::Run(VirtualAddress vaStop)
{
    if (vaStop != kvaInvalid)
        SetBreakpoint(vaStop, kbpidGo);

    // Skip over a hard-coded break instruction if we're sitting on one.

    CPU_regs regs;
    CPU_getregs(regs);
    if (CPU_getword(regs.pc) == kopcBreak) {
        regs.pc += 2;
        CPU_setregs(regs);
    }

    // Step past the current instruction (which might have a breakpoint
    // on it) before reinstalling breakpoints.

    do {
        CPU_step();
        CPU_wait(INFINITE);

        InstallBreakpoints();
        CPU_run();
        CPU_wait(INFINITE);

        // BUG: This is a clumsy way to tell if we've broken into the debugger
        // because of a breakpoint or because the user selected "Debugger"
        // from the UI.

        CPU_getregs(regs);
        bool fBreak = CPU_getword(regs.pc) == kopcBreak;
        RemoveBreakpoints();

        // UI was used to break into the debugger, not a breakpoint.
        // Don't call the breakpoint handler.

        if (!fBreak)
            break;

    // Loop while DoBreakpoint returns fContinue == TRUE

    } while (DoBreakpoints(this));
}


// This little routine was swiped from the C runtime source and pruned
// to provide only the functionality we need. It was originally used to
// prepare argv and argc to pass to main(). It's cool because it deals
// with quoted arguments and escaped quotes within them.

#define NULCHAR     '\0'
#define TABCHAR     '\t'
#define DQUOTECHAR  '\"'
#define SLASHCHAR   '\\'

static void __cdecl parse_cmdline(const char *cmdstart, char **argv,
        char *args, int *numargs, int *numchars)
{
    int inquote;                /* 1 = inside quotes */
    int copychar;               /* 1 = copy char to *args */
    unsigned numslash;          /* num of backslashes seen */

    *numchars = 0;
    *numargs = 0;

    const char *p = cmdstart;

    inquote = 0;

    /* loop on each argument */
    for (;;) {

        if (*p) {
            while (isspace(*p))
                ++p;
        }

        if (*p == NULCHAR)
            break;              /* end of args */

        /* scan an argument */
        if (argv)
            *argv++ = args;     /* store ptr to arg */
        ++*numargs;

        /* loop through scanning one argument */
        for (;;) {
            copychar = 1;
            /* Rules: 2N backslashes + " ==> N backslashes and begin/end quote
               2N+1 backslashes + " ==> N backslashes + literal "
               N backslashes ==> N backslashes */
            numslash = 0;
            while (*p == SLASHCHAR) {
                /* count number of backslashes for use below */
                ++p;
                ++numslash;
            }
            if (*p == DQUOTECHAR) {
                /* if 2N backslashes before, start/end quote, otherwise
                    copy literally */
                if (numslash % 2 == 0) {
                    if (inquote) {
                        if (p[1] == DQUOTECHAR)
                            p++;    /* Double quote inside quoted string */
                        else        /* skip first quote char and copy second */
                            copychar = 0;
                    } else
                        copychar = 0;       /* don't copy quote */

                    inquote = !inquote;
                }
                numslash /= 2;          /* divide numslash by two */
            }

            /* copy slashes */
            while (numslash--) {
                if (args)
                    *args++ = SLASHCHAR;
                ++*numchars;
            }

            /* if at end of arg, break loop */
            if (*p == NULCHAR || (!inquote && isspace(*p)))
                break;

            /* copy character into argument */
            if (copychar) {
                if (args)
                    *args++ = *p;
                ++*numchars;
            }
            ++p;
        }

        /* null-terminate the argument */

        if (args)
            *args++ = NULCHAR;          /* terminate string */
        ++*numchars;
    }

    /* We put one last argument in -- a null ptr */
    if (argv)
        *argv++ = NULL;
}


const char *Debugger::Evaluate(const char *pszExpr, long *plValue, Err *perr)
{
    extern int GetPrecedence(char chOp);
    extern Err DoOperation(long lValue1, long lValue2, char chOp, 
            long *plResult);

    long alValueStack[kclStackMax];
    char achOperStack[kclStackMax - 1];
    int ilValueStack = 0;
    int ichOperStack = 0;
    long lValue, lValue2;
    int prec;

    *perr = kerrNone;

    // Loop until a terminator character is found (loop is always exited
    // via return).

    while (TRUE) {

        //
        // Expect an operand
        //

        // Use EvalNumber to read in a number or symbol

        pszExpr = EvalNumber(pszExpr, &lValue, perr);

        // Return any errors to the caller

        if (*perr != kerrNone)
            return NULL;

        // Push the value on the stack

        alValueStack[ilValueStack++] = lValue;

        //
        // Expect an operator
        //

        // Handle the >> and << operators

        if (*pszExpr == '>' || *pszExpr == '<') {
            pszExpr++;
            if (*pszExpr != *(pszExpr - 1)) {
                *perr = kerrSyntax;
                return NULL;
            }
        }

        prec = GetPrecedence(*pszExpr);

        // Do all stacked operations that are of higher precedence than the 
        // operator just examined.

        while (ichOperStack != 0 && 
                (prec <= GetPrecedence(achOperStack[ichOperStack - 1]))) {

            // Pop operands and operator and do the operation

            lValue = alValueStack[--ilValueStack];
            lValue2 = alValueStack[--ilValueStack];

            *perr = DoOperation(lValue2, lValue, achOperStack[--ichOperStack], 
                    &lValue);
            if (*perr != kerrNone)
                return NULL;

            // Push the operation result on the stack

            alValueStack[ilValueStack++] = lValue;
        }

        if (prec != 0) {

            // If operator is valid, push it on the stack

            achOperStack[ichOperStack++] = *pszExpr;
            pszExpr++;

        } else if (*pszExpr == ',' || *pszExpr == '(' || *pszExpr == ')' || 
                *pszExpr == 0 || isspace(*pszExpr)) {

            // If the character terminates the expression, then return the 
            // various results needed.

            *plValue = alValueStack[--ilValueStack];
            return (char *)pszExpr;

        } else {

            // Otherwise report the syntax error

            *perr = kerrSyntax;
            return NULL;
        }
    }

    Assert(FALSE, "Shouldn't ever get here!");
    return 0;
}

// Compute the precedence of an operator. Higher numbers indicate higher 
// precedence, e.g., GetPecedence('*') > GetPrecedence('+'). Any character
// which is not a binary operator will be assigned a precedence of zero.

int GetPrecedence(char chOp)
{
    switch (chOp) {
    case '+':
    case '-': 
        return 1;

    case '&':
    case '|': 
        return 3;

    case '>':
    case '<': 
        return 4;

    case '*':
    case '/': 
    case '\\': 
        return 2;
    }

    return 0;
}

// Performs the operation of the operator on the two operands.
// Returns kerrNone or kerrDivideByZero.

Err DoOperation(long lValue1, long lValue2, char chOp, long *plResult)
{
    switch (chOp) {
    case '+': 
        *plResult = lValue1 + lValue2;
        return kerrNone;

    case '-': 
        *plResult = lValue1 - lValue2;
        return kerrNone;

    case '&':
        *plResult = lValue1 & lValue2;
        return kerrNone;

    case '|':
        *plResult = lValue1 | lValue2;
        return kerrNone;

    case '>':
        *plResult = lValue1 >> lValue2;
        return kerrNone;

    case '<':
        *plResult = lValue1 << lValue2;
        return kerrNone;

    case '*':
        *plResult = lValue1 * lValue2;
        return kerrNone;

    case '/':
        if (lValue2 != 0) {
            *plResult = lValue1 / lValue2;
            return kerrNone;
        } else
            return kerrDivideByZero;

    case '\\': 
        if (lValue2 != 0) {
            *plResult = lValue1 % lValue2;
            return kerrNone;
        } else
            return kerrDivideByZero;

    default: 
        printf("DoOperation: Operator error op = '%c' lValue1 = %d lValue2 = %d\n", 
                chOp, lValue1, lValue2);
    }

    return kerrNone;
}

// UNDONE: double-quoted strings

#define LONGLIMIT   0xffffffff

const char *Debugger::EvalNumber(const char *pszExpr, long *plResult, Err *perr)
{
    long base;
    long lValue;
    char szSymbol[kcchSymbolMax + 1];
    int i;
    char endFlag;

    char ch = *pszExpr;

    // Unary minus

    if (ch == '-') {

        // Evaluate unary minus operator recursively

        pszExpr = EvalNumber(++pszExpr, &lValue, perr);
        *plResult = -lValue;
        return pszExpr;
    }

    // One's complement

    else if (ch == '~') {

        // Evaluate one's complement operator recursively

        pszExpr = EvalNumber(++pszExpr, &lValue, perr);
        *plResult = ~lValue;
        return pszExpr;
    }

    // Parenthesized expression

    else if (ch == '(') {

        // Evaluate parenthesized expressions recursively

        pszExpr = Evaluate(++pszExpr, &lValue, perr);
        if (*perr != kerrNone)
            return NULL;
        else if (*pszExpr != ')') {
            *perr = kerrSyntax;
            return NULL;
        } else {
            *plResult = lValue;
            return ++pszExpr;
        }
    }

    // Hex number

    else if ((isdigit(ch) && GetDefaultBase() == 16) || 
            (ch == '$' && isxdigit(*(pszExpr + 1)))) {

        // Convert hex digits until another character is found. 
        // (At least one hex digit is present.)

        lValue = 0;
        if (ch == '$')
            pszExpr++;
        while (isxdigit(*pszExpr)) {
            if ((unsigned long)lValue > (unsigned long)LONGLIMIT / 16) {
                *perr = kerrNumberTooBig;
                break;
            }

            ch = toupper(*pszExpr);
            if (ch > '9')
                lValue = 16 * lValue + (ch - 'A' + 10);
            else
                lValue = 16 * lValue + (ch - '0');
            pszExpr++;
        }
        *plResult = lValue;
        return pszExpr;
    }

    // Binary, Octal, Decimal number

    else if (ch == '%' || ch == '@' || ch == '#' || 
            isdigit(ch)) {

        // Convert digits in the appropriate base (binary, octal, or 
        // decimal) until an invalid digit is found.

        if (*pszExpr == '%') {
            base = 2;
            pszExpr++;
        } else if (*pszExpr == '@') {
            base = 8;
            pszExpr++;
        } else if (*pszExpr == '#') {
            base = 10;
            pszExpr++;
        } else {
            base = GetDefaultBase();
        }

        // Check that at least one digit is present

        if (*pszExpr < '0' || *pszExpr >= '0' + base) {
            *perr = kerrSyntax;
            return NULL;
        }

        lValue = 0;

        // Convert the digits into an integer

        while (*pszExpr >= '0' && *pszExpr < '0' + base) {
            if ((unsigned long)lValue > (LONGLIMIT - (*pszExpr - '0')) / base) {
                *perr = kerrNumberTooBig;
                break;
            }
            lValue = (long)((long)((long)base * lValue) + 
                    (long)(*pszExpr - '0'));
            pszExpr++;
        }
        *plResult = lValue;
        return pszExpr;
    }

    // Single-quoted string

    else if (ch == '\'') {
        endFlag = FALSE;
        i = 0;
        lValue = 0;
        pszExpr++;
        while (!endFlag) {
            if (*pszExpr == '\'')
                if (*(pszExpr + 1) == '\'') {
                    lValue = (lValue << 8) + *pszExpr;
                    i++;
                    pszExpr++;
                } else
                    endFlag = TRUE;
            else {
                lValue = (lValue << 8) + *pszExpr;
                i++;
            }
            pszExpr++;
        }

        if (i == 0) {
            *perr = kerrSyntax;
            return NULL;
        } else if (i == 3)
            lValue = lValue << 8;
        else if (i > 4)
            *perr = kerrAsciiTooBig;
        *plResult = lValue;
        return pszExpr;
    }

    // Registers (d0-d7, a0-a7, sp, pc)

    else if (ch == '.') {
        CPU_regs regs;
        ulong *pulReg = GetRegPtr(regs, pszExpr);
        if (pulReg == NULL)
            *perr = kerrSyntax;
        else
            *plResult = *pulReg;

        return pszExpr + 3;
    }

    // Symbol (symbols can start with an alphabetic char or '.', '_', '?', '$',
    // and include letters, numbers, '.', '_', '$', '?', '@')

    // BUG: '$' is first grabbed by the hex number evaluator. '.' is used 
    // for the register prefix and '?' for conditional expressions

    else if (isalpha(ch) || ch == '.' || ch == '?' || 
            ch == '_' || ch == '$') {
        /* Determine the value of a symbol */
        i = 0;

        // Collect characters of the symbol's name (only kcchSymbolMax 
        // characters are significant)

        do {
            if (i < kcchSymbolMax)
                szSymbol[i++] = *pszExpr;
            pszExpr++;
        } while (isalnum(*pszExpr) || *pszExpr == '.' || *pszExpr == '_' || 
                *pszExpr == '$' || *pszExpr == '?' || *pszExpr == '@');

        szSymbol[i] = '\0';

        // First look for the name as a symbol.

        *plResult = LookupAddress(szSymbol);

        if (*plResult == 0) {

            // If not found look for the name as a variable.

            *perr = EvalVariable(szSymbol, plResult);
        }
        return pszExpr;

    } else {

        // The character was not a valid operand.

        *perr = kerrSyntax;
        return NULL;
    }

    Assert(FALSE, "Should never get here!");
    return NULL;
}


void Debugger::DumpCpuState(VirtualAddress *pvaNextPC)
{
    extern void MC68000_disasm(Debugger *pdbg, const CPU_regs &regs, DWORD addr, 
            DWORD *nextpc, int cnt);

    CPU_regs regs;
    CPU_getregs(regs);
    int i;
    for (i = 0; i < 8; i++) {
        printf("d%d: %08lx ", i, regs.d[i]);
        if ((i & 3) == 3) printf("\n");
    }
    for (i = 0; i < 8; i++) {
        printf("a%d: %08lx ", i, regs.a[i]);
        if ((i & 3) == 3) printf("\n");
    }
    printf ("T=%d S=%d X=%d N=%d Z=%d V=%d C=%d IMASK=%d\n", regs.t, regs.s,
            regs.x, NFLG, ZFLG, VFLG, CFLG, regs.intmask);
    if (pvaNextPC != NULL)
        *pvaNextPC = regs.pc;
    MC68000_disasm(this, regs, regs.pc, pvaNextPC, 1);
}

//
// Modules
//

Module *Debugger::AddModule(LocalID lidDb)
{
    // Allocate a new module structure

    Module *pmod = new Module(lidDb);

    // Link the new module structure into the module list

    pmod->m_pmodNext = m_pmodHead;
    m_pmodHead = pmod;
    return pmod;
}

Module *Debugger::FindModule(LocalID lidDb)
{
    // Search the module list for a module of the specified dbid

    for (Module *pmod = m_pmodHead; pmod != NULL; pmod = pmod->m_pmodNext)
        if (pmod->m_lidDb == lidDb)
            return pmod;

    return NULL;
}

bool Debugger::RemoveModule(LocalID lidDb)
{
    for (Module **ppmod = &m_pmodHead; *ppmod != NULL; 
            ppmod = &(*ppmod)->m_pmodNext) {
        Module *pmod = *ppmod;
        if (pmod->m_lidDb != lidDb)
            continue;

        *ppmod = pmod->m_pmodNext;
        delete pmod;
        return TRUE;
    }

    Assert(FALSE, "Module not found!");
    return FALSE;
}

static void GetEAString(Debugger *pdbg, char *pszEA, char *pszResolvedEA, 
        const CPU_regs &regs, DWORD *nextpc, int reg, amodes mode, 
        wordsizes size)
{
    WORD dp;
    signed char disp8;
    short disp16;
    int r;
    ULONG dispreg;
    DWORD addr;

    *pszResolvedEA = 0;

    switch (mode) {
    case Dreg:
        sprintf(pszEA, "d%d", reg);
        break;
    case Areg:
        sprintf(pszEA, "a%d", reg);
        break;
    case Aind:
        sprintf(pszEA, "(a%d)", reg);
        break;
    case Aipi:
        sprintf(pszEA, "(a%d)+", reg);
        break;
    case Apdi:
        sprintf(pszEA, "-(a%d)", reg);
        break;
    case Ad16:
        disp16 = nextiword();
        addr = regs.a[reg] + disp16;
        sprintf(pszEA, "%s$%lx(a%d)", disp16 < 0 ? "-" : "",
                disp16 < 0 ? -disp16 : disp16, reg);
        strcpy(pszResolvedEA, pdbg->LookupSymbol(addr));
        break;
    case Ad8r:
        dp = nextiword();
        disp8 = dp & 0xFF;
        r = (dp & 0x7000) >> 12;
        dispreg = dp & 0x8000 ? regs.a[r] : regs.d[r];
        if (!(dp & 0x800)) dispreg = (LONG)(short)(dispreg);

        addr = regs.a[reg] + disp8 + dispreg;
        sprintf(pszEA, "%s$%x(a%d, %c%d.%c)", disp8 < 0 ? "-" : "",
                disp8 < 0 ? -disp8 : disp8, reg,
                dp & 0x8000 ? 'a' : 'd', (int)r, dp & 0x800 ? 'l' : 'w');
        strcpy(pszResolvedEA, pdbg->LookupSymbol(addr));
        break;
    case PC16:
        addr = *nextpc;
        disp16 = nextiword();
        addr += disp16;
        sprintf(pszEA, "%s$%lx(pc)", disp16 < 0 ? "-" : "",
                disp16 < 0 ? -disp16 : disp16);
        strcpy(pszResolvedEA, pdbg->LookupSymbol(addr));
        break;
    case PC8r:
        addr = *nextpc;
        dp = nextiword();
        disp8 = dp & 0xFF;
        r = (dp & 0x7000) >> 12;
        dispreg = dp & 0x8000 ? regs.a[r] : regs.d[r];

        if (!(dp & 0x800)) dispreg = (LONG)(short)(dispreg);
        addr += disp8 + dispreg;
        sprintf(pszEA, "%s$%x(pc, %c%d.%c)", disp8 < 0 ? "-" : "",
                disp8 < 0 ? -disp8 : disp8, dp & 0x8000 ? 'a' : 'd',
                (int)r, dp & 0x800 ? 'l' : 'w');
        strcpy(pszResolvedEA, pdbg->LookupSymbol(addr));
        break;
    case absw:
        sprintf(pszEA, "$%lx", (LONG)(short)nextiword());
        break;
    case absl:
        sprintf(pszEA, "$%lx", nextilong());
        break;
    case imm:
        switch (size) {
        case sz_byte:
            sprintf(pszEA, "#$%02x", nextiword() & 0xff); break;
        case sz_word:
            sprintf(pszEA, "#$%04x", nextiword()); break;
        case sz_long:
            sprintf(pszEA, "#$%08lx", nextilong()); break;
        default:
            abort();
        }
        break;
    case imm0:
        sprintf(pszEA, "#$%lx", nextiword() & 0xff);
        break;
    case imm1:
        sprintf(pszEA, "#$%lx", nextiword());
        break;
    case imm2:
        sprintf(pszEA, "#$%lx", nextilong());
        break;
    case immi:
        sprintf(pszEA, "#$%lx", reg);
        break;
    default:
        abort();
    }
}

static char* ccnames[] =
{
    "ra","f","hi","ls","cc","cs","ne","eq",
    "vc","vs","pl","mi","ge","lt","gt","le"
};

static int cctrue(const CPU_regs &regs, const int cc)
{
    switch (cc) {
    case 0: return 1;                       /* T */
    case 1: return 0;                       /* F */
    case 2: return !CFLG && !ZFLG;          /* HI */
    case 3: return CFLG || ZFLG;            /* LS */
    case 4: return !CFLG;                   /* CC */
    case 5: return CFLG;                    /* CS */
    case 6: return !ZFLG;                   /* NE */
    case 7: return ZFLG;                    /* EQ */
    case 8: return !VFLG;                   /* VC */
    case 9: return VFLG;                    /* VS */
    case 10:return !NFLG;                   /* PL */
    case 11:return NFLG;                    /* MI */
    case 12:return NFLG == VFLG;            /* GE */
    case 13:return NFLG != VFLG;            /* LT */
    case 14:return !ZFLG && (NFLG == VFLG); /* GT */
    case 15:return ZFLG || (NFLG != VFLG);  /* LE */
    }
    abort();
    return 0;
}

const long kcchEAMax = 50;

inline void PadString(char *pch, char chPad, int ich)
{
    char *pchEnd = pch + ich;
    while (*pch++ != 0);
    pch--;
    while (pch < pchEnd)
        *pch++ = chPad;
    *pch = 0;
}

void MC68000_disasm(Debugger *pdbg, const CPU_regs &regs, DWORD addr, 
        DWORD *nextpc, int cnt)
{
    extern const char *apinames[];
    static char szOut[255];
    char szEA[kcchEAMax], szResolvedEA[kcchSymbolMax];
    char szAddress[15], szInstr[20], szOperands[40];
    char szPrefix[kcchSymbolMax + 5], szComment[kcchSymbolMax * 2 + 4];

    VirtualAddress vaPC;
    if (nextpc == NULL)
        nextpc = &vaPC;
    *nextpc = addr;
    for (; cnt--;) {
        szOperands[0] = szComment[0] = 0;

        VirtualAddress vaFirst = *nextpc;
        const char *pszName = pdbg->LookupSymbol(vaFirst);
        if (*pszName != '$')
            sprintf(szPrefix, "%s\n", pszName);
        else
            szPrefix[0] = 0;
        sprintf(szAddress, "%08lx", vaFirst);

        WORD opw = nextiword();
        if (opw == 0x4e4f) {    // TRAP #$F
            strcpy(szInstr, "SysTrap");
            WORD opwApi = nextiword();
            if (opwApi >= 40960 && opwApi < 40960+1024 && apinames[opwApi-40960]) {
                sprintf(szOperands, "%s", apinames[opwApi-40960]);
            } else {
                sprintf(szOperands, "$%04x", opwApi);
            }
        } else {
            struct mnemolookup *lookup;
            struct instr *dp = table68k + opw;
            for (lookup = lookuptab;lookup->mnemo != dp->mnemo; lookup++)
                ;

            strcpy(szInstr, lookup->name);
            char *pchCC = strstr(szInstr, "cc");
            if (pchCC != 0) {
                strcpy(pchCC, ccnames[dp->cc]);
                if (dp->size == sz_byte)
                    strcat(szInstr, ".s");
            } else {
                switch (dp->size) {
                case sz_byte: strcat(szInstr, ".b"); break;
                case sz_word: strcat(szInstr, ".w"); break;
                case sz_long: strcat(szInstr, ".l"); break;
                }
            }

            szEA[0] = szResolvedEA[0] = 0;

            if (strcmp(szInstr, "illegal") != 0) {
                if (dp->suse) {
                    GetEAString(pdbg, szEA, szResolvedEA, regs, nextpc, dp->sreg,
                                dp->smode, dp->size);
                    strcpy(szOperands, szEA);
                    if (szResolvedEA[0] != 0)
                        strcpy(szComment, szResolvedEA);
                }

                if (dp->suse && dp->duse)
                    strcat(szOperands, ", ");

                if (dp->duse) {
                    GetEAString(pdbg, szEA, szResolvedEA, regs, nextpc, dp->dreg,
                                dp->dmode, dp->size);
                    strcat(szOperands, szEA);
                    if (szResolvedEA[0] != 0) {
                        if (szComment[0] != 0)
                            strcat(szComment, ", ");
                        strcat(szComment, szResolvedEA);
                    }
                }

                if (pchCC != 0) {
                    if (szComment[0] != 0)
                        strcat(szComment, ", ");
                    strcat(szComment, cctrue(regs, dp->cc) ? "TRUE" : "FALSE");
                }
            }
        }

        // By constructing the string entirely before printing it only one
        // line needs to change to interface with a new output mechanism.
        // It's also faster.

        sprintf(szOut, "%s: ", szAddress);
        for (VirtualAddress va = vaFirst; va < *nextpc; va += 2)
            sprintf(szOut, "%s%04x ", szOut, CPU_getword(va));
        PadString(szOut, ' ', 30);
        strcat(szOut, szInstr);

        if (szOperands[0] != 0) {
            PadString(szOut, ' ', 39);
            strcat(szOut, szOperands);
        }

        if (szComment[0] != 0) {
            PadString(szOut, ' ', 58);
            sprintf(szOut, "%s;%s", szOut, szComment);
        }

        pdbg->printf("%s%s\n", szPrefix, szOut);
    }
}

int GetInstructionLength(Debugger *pdbg, VirtualAddress va)
{
    char szEA[kcchEAMax], szResolvedEA[kcchSymbolMax];
    DWORD vaNextPC;
    DWORD *nextpc = &vaNextPC;
    *nextpc = va;
    CPU_regs regs;
    CPU_getregs(regs);

    WORD opw = nextiword();
    if (opw == 0x4e4f) {    // TRAP #$F
        WORD opwApi = nextiword();
    } else {
        struct mnemolookup *lookup;
        struct instr *dp = table68k + opw;
        for (lookup = lookuptab;lookup->mnemo != dp->mnemo; lookup++)
            ;

        szEA[0] = szResolvedEA[0] = 0;

        if (strcmp(lookup->name, "illegal") != 0) {
            if (dp->suse) {
                GetEAString(pdbg, szEA, szResolvedEA, regs, nextpc, dp->sreg,
                            dp->smode, dp->size);
            }
            if (dp->duse) {
                GetEAString(pdbg, szEA, szResolvedEA, regs, nextpc, dp->dreg,
                            dp->dmode, dp->size);
            }
        }
    }

    return vaNextPC - va;
}

void Debugger::Disassemble(VirtualAddress vaDis, int cLines, 
        VirtualAddress *pvaNextDis)
{
    CPU_regs regs;
    CPU_getregs(regs);
    MC68000_disasm(this, regs, vaDis, pvaNextDis, cLines);
}


//
// Breakpoints
//

Breakpoint gabp[kcbpMax];

bool SetBreakpoint(VirtualAddress va, Bpid bpid, Pfnbph pfnbph)
{
    Breakpoint *pbp;
    if (bpid == kbpidUnspecified) {
        for (pbp = gabp; pbp < &gabp[kcbpMax - 1]; pbp++) {
            if (!(pbp->ff & kfBpInUse))
                break;
        }

        // No empty breakpoint slots left

        if (pbp == &gabp[kcbpUserMax - 1])
            return FALSE;
    } else {
        pbp = &gabp[bpid];
    }

    pbp->ff = kfBpInUse | kfBpEnabled;
    pbp->va = va;
    pbp->pfnbph = pfnbph;

    return TRUE;
}

bool ClearBreakpoint(Bpid bpid)
{
    if (bpid == kbpidAll) {
        for (Breakpoint *pbp = gabp; pbp < &gabp[kcbpUserMax - 1]; pbp++)
            pbp->ff = 0;
    } else {
        if (gabp[bpid].ff & kfBpInUse)
            gabp[bpid].ff = 0;
        else    // breakpoint doesn't exist!
            return FALSE;
    }

    return TRUE;
}

bool EnableBreakpoint(Bpid bpid, bool fEnable)
{
    if (bpid == kbpidAll) {
        for (Breakpoint *pbp = gabp; pbp < &gabp[kcbpMax - 1]; pbp++) {
            if (pbp->ff & kfBpInUse) {
                if (fEnable)
                    pbp->ff |= kfBpEnabled;
                else
                    pbp->ff &= ~kfBpEnabled;
            }
        }
    } else {
        if (gabp[bpid].ff & kfBpInUse) {
            if (fEnable)
                gabp[bpid].ff |= kfBpEnabled;
            else
                gabp[bpid].ff &= ~kfBpEnabled;

        } else {    // breakpoint doesn't exist!
            return FALSE;
        }
    }

    return TRUE;
}

void InstallBreakpoints()
{
    // Breakpoints are installed in two passes to handle the case when
    // two breakpoints are at the same address -- the second breakpoint
    // was picking up the kopcBreak that the first breakpoint set down
    // rather than the correct usInstr

    Breakpoint *pbp;

    // First pass retains the opcode at the breakpoint's location

    for (pbp = gabp; pbp < &gabp[kcbpMax]; pbp++) {
        if ((pbp->ff & (kfBpEnabled | kfBpInUse)) == (kfBpEnabled | kfBpInUse)) {
            ushort *pus = (ushort *)CPU_getmemptr(pbp->va);
            pbp->usInstr = *pus;
        }
    }

    // Second pass stores the break obpcode at the breakpoint's location

    for (pbp = gabp; pbp < &gabp[kcbpMax]; pbp++) {
        if ((pbp->ff & (kfBpEnabled | kfBpInUse)) == (kfBpEnabled | kfBpInUse)) {
            ushort *pus = (ushort *)CPU_getmemptr(pbp->va);
            *pus = kopcBreak;
        }
    }
}

void RemoveBreakpoints()
{
    Breakpoint *pbp;
    for (pbp = gabp; pbp < &gabp[kcbpMax]; pbp++) {
        if ((pbp->ff & (kfBpEnabled | kfBpInUse)) == (kfBpEnabled | kfBpInUse)) {
            ushort *pus = (ushort *)CPU_getmemptr(pbp->va);
            *pus = pbp->usInstr;
        }
    }
}

bool DoBreakpoints(Debugger *pdbg)
{
    bool fContinue = TRUE;

    VirtualAddress vaPC = GetPC();

    // Always reset the system breakpoint after execution has stopped
    // (whether or not it was hit)

    if (gabp[kbpidGo].ff & kfBpInUse) {
        if (gabp[kbpidGo].va == vaPC)
            fContinue = FALSE;
        ClearBreakpoint(kbpidGo);
    }

    // First pass makes sure every non-default, non-user breakpoint handler for 
    // this address is called

    bool fDoDefault = TRUE;
    Breakpoint *pbp;
    for (pbp = &gabp[kcbpUserMax]; pbp < &gabp[kcbpMax]; pbp++) {
        if ((pbp->ff & (kfBpEnabled | kfBpInUse)) == (kfBpEnabled | kfBpInUse)) {
            if (vaPC != pbp->va)
                continue;

            if (pbp->pfnbph != NULL)
                if (!pbp->pfnbph(pdbg, pbp - gabp))
                    fContinue = FALSE;
        }
    }

    // Second pass tries every user breakpoint

    for (pbp = gabp; pbp < &gabp[kcbpUserMax - 1]; pbp++) {
        if ((pbp->ff & (kfBpEnabled | kfBpInUse)) == (kfBpEnabled | kfBpInUse)) {
            if (vaPC != pbp->va)
                continue;

            Bpid bpid = pbp - gabp;
            pdbg->printf("\nBreakpoint %d hit!\n", bpid);
            fContinue = FALSE;
        }
    }

    return fContinue;
}

void ShowBreakpoints(Debugger *pdbg)
{
    bool fNoBreakpoints = TRUE;
    Breakpoint *pbp;
    Bpid bpid;
    for (bpid = 0, pbp = gabp; pbp < &gabp[kcbpUserMax]; pbp++, bpid++) {
        if (!(pbp->ff & kfBpInUse))
            continue;

        fNoBreakpoints = FALSE;

        char *pszSymbol;
        long cbOffset;
        char szT[kcchSymbolMax + 15];
        if (pdbg->FindNearestSymbols(pbp->va, &pszSymbol, &cbOffset)) {
            if (cbOffset == 0)
                strcpy(szT, pszSymbol);
            else
                sprintf(szT, "%s + $%lx", pszSymbol, cbOffset);
        } else {
            sprintf(szT, "$%lx", pbp->va);
        }
        pdbg->printf("%d %c $%0lx (%s)\n", bpid, pbp->ff & kfBpEnabled ?
                'e' : 'd', pbp->va, szT);
    }

    if (fNoBreakpoints)
        pdbg->printf("No breakpoints are set.\n");
}

bool SysAppLaunchBpHandler(Debugger *pdbg, Bpid bpid)
{
    CPU_regs regs;
    CPU_getregs(regs);

    switch (bpid) {
    case kbpidSysAppLaunch:
        pdbg->printf("- SysAppLaunch(cardNo $%x, dbID $%lx, launchFlags $%x, "
                "cmd $%x, cmdPBP %lx)\n",
                CPU_getword(regs.a[6] + 4 + 4),
                CPU_getlong(regs.a[6] + 4 + 6),
                CPU_getword(regs.a[6] + 4 + 10),
                CPU_getword(regs.a[6] + 4 + 12),
                CPU_getlong(regs.a[6] + 4 + 14));

        // BUG: not handling allocation failure
        gpmodActive = pdbg->AddModule(CPU_getlong(regs.a[6] + 4 + 6));
        break;

    case kbpidSysAppLaunchCallApp:
        {
            extern long GetSymbols(VirtualAddress vaCode, long cbCode, 
                    Symbol *psym);

            LocalID lidDb = CPU_getlong(regs.a[6] + 4 + 6);
            Module *pmod = pdbg->FindModule(lidDb);
            VirtualAddress vaSysAppInfoPtr = regs.a[2];
            ulong hCode = CPU_getlong(vaSysAppInfoPtr + 12);
            long cbCode = GetHandleSize(hCode);
            VirtualAddress vaCode = regs.d[6];

            pmod->GetSymbols(vaCode, cbCode);
        }
        break;

    case kbpidSysAppLaunchCallReturn:
        break;

    case kbpidSysAppLaunchRts:

        // LATER: can probably make this better by grabbing dbID from the 
        // stack and using it to look up pmod

        pdbg->printf("- SysAppLaunch returns %d\n", (ushort)regs.d[0]);

        if (!pdbg->RemoveModule(CPU_getlong(regs.a[6] + 4 + 6)))
            pdbg->printf("- Module not found\n");
        gpmodActive = NULL;
        break;
    }

    return TRUE;
}

long GetSymbols(VirtualAddress vaCode, long cbCode, Symbol *psym)
{
    // Always include one symbol for the very beginning of the code
    // and one for the very end.

    if (psym != NULL) {
        psym->va = vaCode;
        psym->pszName = new char[sizeof("Code1ResourceStart") + 1];
        strcpy(psym->pszName, "Code1ResourceStart");
        psym++;
    }

    int csym = 1;

    for (VirtualAddress offset = vaCode; offset < vaCode + cbCode; 
            offset += 2) {
        if (CPU_getword(offset) == kopcLink) {

            bool fSecondRts = FALSE;

            for (VirtualAddress rts = offset + 2; rts < vaCode + cbCode; 
                    rts += 2) {

                ushort opc = CPU_getword(rts);

                if (opc == kopcLink) {

                    // Oops, found the beginning of a new function. Abort
                    // the scan of the old function.

                    break;
                }

                if (opc == kopcRts) {

                    // rts found, scan after it for a symbol string.

                    char szName[kcchSymbolMax];
                    int cch = 0;
                    while (cch < kcchSymbolMax) {
                        char ch = CPU_getbyte(rts + 3 + cch);
                        szName[cch] = ch;
                        if (ch == 0)
                            break;
                        cch++;
                    }

                    if ((CPU_getbyte(rts + 2) & 0x7f) != cch) {

                        // Whoops, no symbol follows this rts.
                        // Sometimes VC++ generates more than one rts from a
                        // function. If this is the first rts we continue
                        // the loop looking for a second rts and a symbol.
                        // If this is the second rts then we give up trying 
                        // to find a symbol for this function.

                        if (!fSecondRts) {
                            fSecondRts = TRUE;
                            continue;
                        } else {
                            break;
                        }
                    } else {

                        // Symbol found, add it to the symbol list.

                        csym++;
                        if (psym != NULL) {
                            psym->va = offset;
                            // BUG: no error handling
                            psym->pszName = new char[cch + 1];
                            strcpy(psym->pszName, szName);
                            psym++;
                        }
                    }
                    break;
                }
            }
        }
    }

    if (psym != NULL) {
        psym->va = vaCode + cbCode;
        psym->pszName = new char[sizeof("Code1ResourceEnd") + 1];
        strcpy(psym->pszName, "Code1ResourceEnd");
    }

    return ++csym;
}

//
// VariableList
//

VariableList::VariableList()
{
    m_pvarHead = NULL;
}

VariableList::~VariableList()
{
   Variable *pvar = m_pvarHead;

   while (pvar != NULL) {
       Variable *pvarDel = pvar;
       pvar = pvar->pvarNext;
       delete pvarDel->pszName;
       delete pvarDel->pszValue;
       delete pvarDel;
   }
}

bool VariableList::Set(const char *pszName, const char *pszValue)
{
    // First try to find pszName.

    Variable **ppvar;
    Variable *pvar = Lookup(pszName, &ppvar);

    // If not found, add it.

    if (pvar == NULL) {
        if (pszValue == NULL)
            return FALSE;

        // UNDONE: Allocation exception handling
        pvar = new Variable();
        pvar->pszName = new char[strlen(pszName) + 1];
        strcpy(pvar->pszName, pszName);
        pvar->pszValue = new char[strlen(pszValue) + 1];
        strcpy(pvar->pszValue, pszValue);

        // Link the new variable into the list.

        pvar->pvarNext = m_pvarHead;
        m_pvarHead = pvar;

        return TRUE;
    }

    // Found, are we trying to clear it? (pszValue == NULL)

    if (pszValue == NULL) {

        // Unlink it from the list

        *ppvar = pvar->pvarNext;

        // Delete its members

        delete pvar->pszName;
        delete pvar->pszValue;
        delete pvar;
        
        return TRUE;
    }

    // Overwrite the old value. Don't overwrite the name, the original name
    // (casing) holds.

    delete pvar->pszValue;
    pvar->pszValue = new char[strlen(pszValue) + 1];
    strcpy(pvar->pszValue, pszValue);

    return TRUE;
}

char *VariableList::Lookup(const char *pszName)
{
    Variable *pvar, **ppvar;

    pvar = Lookup(pszName, &ppvar);
    if (pvar == NULL)
        return NULL;

    return pvar->pszValue;
}

Variable *VariableList::Lookup(const char *pszName, Variable ***pppvar)
{
    Variable *pvar, **ppvar;

    // First try a strict case sensitive match.

    for (ppvar = &m_pvarHead; *ppvar != NULL; ppvar = &(*ppvar)->pvarNext) {
        pvar = *ppvar;
        if (strcmp(pvar->pszName, pszName) == 0) {
            *pppvar = ppvar;
            return pvar;
        }
    }

    // Didn't find an exact match. Try a case insensitive match.

    for (ppvar = &m_pvarHead; *ppvar != NULL; ppvar = &(*ppvar)->pvarNext) {
        pvar = *ppvar;
        if (stricmp(pvar->pszName, pszName) == 0) {
            *pppvar = ppvar;
            return pvar;
        }
    }

    // Didn't find an inexact match either, return NULL.

    return NULL;
}

Variable *VariableList::GetNext(Position *ppos)
{
    Assert(ppos->m_pvNext != NULL, "Enumerating off the end of the list!");

    if (ppos->m_pvNext == (void *)kPosFirst) {
        ppos->m_pvNext = m_pvarHead;
        return m_pvarHead;
    }

    Variable *pvar = ((Variable *)ppos->m_pvNext)->pvarNext;
    ppos->m_pvNext = pvar;
    return pvar;
}


bool DumpSymbols(Debugger *pdbg)
{
    if (gpmodActive == NULL) {
        pdbg->printf("No active module to dump symbols for\n");
        return FALSE;
    }

    long csym = gpmodActive->m_csym;
    pdbg->printf("Database id $%08lx, %d symbols\n", gpmodActive->m_lidDb, csym);

    for (Symbol *psym = gpmodActive->m_asym; csym-- > 0; psym++)
        pdbg->printf("$%08lx  %s\n", psym->va, psym->pszName);

    return TRUE;
}


Module::Module(LocalID lidDb)
{
    m_lidDb = lidDb;
    m_pszName = NULL;
    m_csym = 0;
    m_asym = NULL;
    m_vaCode = 0;
    m_cbCode = 0;
}

Module::~Module()
{
    long csym = m_csym;
    for (Symbol *psym = m_asym; csym-- > 0; psym++)
        delete psym->pszName;

    if (m_asym != NULL)
        delete m_asym;
}

Symbol *Module::FindSymbol(const char *pszName)
{
    Symbol *psym = m_asym;
    for (long csym = m_csym; csym > 0; csym--, psym++) {
        if (stricmp(pszName, psym->pszName) == 0)
            return psym;
    }

    return NULL;
}

Symbol *Module::FindSymbol(VirtualAddress va)
{
    Assert(va >= m_vaCode && va < m_vaCode + m_cbCode);

    int left = 0;
    int right = m_csym - 1;
    while (left <= right) {
        int mid = (left + right) / 2;
        if (va == m_asym[mid].va) {
            return &m_asym[mid];
        } else if (va < m_asym[mid].va) {
            right = mid - 1;
        } else {
            left = mid + 1;
        }
    }

    return NULL;
}

bool Module::GetSymbols(VirtualAddress vaCode, long cbCode)
{
    m_vaCode = vaCode;
    m_cbCode = cbCode;
    m_csym = ::GetSymbols(vaCode, cbCode, NULL);
    if (m_csym != 0) {
        // BUG: not handling allocation failure
        m_asym = new Symbol[m_csym];
        ::GetSymbols(vaCode, cbCode, m_asym);
    }

    return TRUE;
}

bool Module::FindNearestSymbols(VirtualAddress va,
        char **ppszBefore, long *pcbBOffset, char **ppszAfter, 
        long *pcbAOffset)
{
    int left = 0;
    int right = m_csym - 1;
    int mid;
    while (left <= right) {
        mid = (left + right) / 2;
        if (va >= m_asym[mid].va && va < m_asym[mid + 1].va) {
            if (ppszBefore != NULL)
                *ppszBefore = (char *)m_asym[mid].pszName;
            if (pcbBOffset != NULL)
                *pcbBOffset = va - m_asym[mid].va;
            if (ppszAfter != NULL)
                *ppszAfter = m_asym[mid + 1].pszName;
            if (pcbAOffset != NULL)
                *pcbAOffset = m_asym[mid + 1].va - va;
            return TRUE;
        } else if (va < m_asym[mid].va) {
            right = mid - 1;
        } else {
            left = mid + 1;
        }
    }

    Assert(FALSE, "Shouldn't get here!");
    return FALSE;
}
