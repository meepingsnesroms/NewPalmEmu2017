// rom proc definitions

struct TRomProc {
  unsigned long addr;
  const char *name;
};

extern const TRomProc RomProcNames[];
extern const int RomProcNameCount;