// persistent settings support

#include <windows.h>
#pragma hdrstop

#include "settings.h"

#include "registry.h"

TSettings Settings;

TSettings::TSettings()
{
  Window.x = CW_USEDEFAULT;
  Window.y = CW_USEDEFAULT;
  Scale = 1;
  Realistic = TRUE;
  Backlight = FALSE;
  OSVERSIONINFO osv;
  osv.dwOSVersionInfoSize = sizeof(osv);
  GetVersionEx(&osv);
  Sounds = osv.dwPlatformId == VER_PLATFORM_WIN32_NT;
  FPS = 20;
  RamSize = 1024;
  strcpy(CommPort, "None");
  DebugAtStartup = FALSE;
  PrcPath[0] = 0;
  for (int i = 0; i < MRU_COUNT; i++) {
    PrcMru[i][0] = 0;
  }
  strcpy(RomFile, "pilot.rom");
  DWORD x;
  if (GetRegistryDword("WindowX", x)) {
    Window.x = x;
  }
  if (GetRegistryDword("WindowY", x)) {
    Window.y = x;
  }
  if (GetRegistryDword("Scale", x)) {
    if (x < 1) {
      x = 0;
    } else if (x > 2) {
      x = 2;
    }
    Scale = x;
  }
  BOOL b;
  if (GetRegistryBool("Realistic", b)) {
    Realistic = b;
  }
  if (GetRegistryBool("Backlight", b)) {
    Backlight = b;
  }
  if (GetRegistryBool("Sounds", b)) {
    Sounds = b;
  }
  if (GetRegistryDword("FPS", x) && x > 0) {
    FPS = x;
  }
  if (GetRegistryDword("RamSize", x) && x > 0) {
    RamSize = x;
  }
  char s[MAX_PATH];
  if (GetRegistryString("CommPort", s, sizeof(s))) {
    strcpy(CommPort, s);
  }
  if (GetRegistryBool("DebugAtStartup", b)) {
    DebugAtStartup = b;
  }
  if (GetRegistryString("PrcPath", s, sizeof(s))) {
    strcpy(PrcPath, s);
  }
  for (i = 0; i < MRU_COUNT; i++) {
    char buf[20];
    wsprintf(buf, "PrcMru.%d", i);
    if (GetRegistryString(buf, s, sizeof(s))) {
      strcpy(PrcMru[i], s);
    }
  }
  if (GetRegistryString("RomFile", s, sizeof(s))) {
    strcpy(RomFile, s);
  }
}

void TSettings::Save(HWND hwnd)
{
  RECT wr;
  GetWindowRect(hwnd, &wr);
  SetRegistryDword("WindowX", wr.left);
  SetRegistryDword("WindowY", wr.top);
  SetRegistryDword("Scale", Scale);
  SetRegistryDword("Realistic", Realistic);
  SetRegistryDword("Backlight", Backlight);
  SetRegistryDword("Sounds", Sounds);
  SetRegistryDword("FPS", FPS);
  SetRegistryDword("RamSize", RamSize);
  SetRegistryString("CommPort", CommPort);
  SetRegistryDword("DebugAtStartup", DebugAtStartup);
  SetRegistryString("PrcPath", PrcPath);
  for (int i = 0; i < MRU_COUNT; i++) {
    if (PrcMru[i][0]) {
      char buf[20];
      wsprintf(buf, "PrcMru.%d", i);
      SetRegistryString(buf, PrcMru[i]);
    }
  }
  SetRegistryString("RomFile", RomFile);
}

void TSettings::UpdateMru(const char *name)
{
  for (int i = 0; i < MRU_COUNT-1; i++) {
    if (stricmp(name, PrcMru[i]) == 0) {
      break;
    }
  }
  if (i > 0) {
    MoveMemory(PrcMru[1], PrcMru[0], i*MAX_PATH);
  }
  strcpy(PrcMru[0], name);
}
