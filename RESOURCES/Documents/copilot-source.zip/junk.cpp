#include <stdio.h>

unsigned char buf[0x3000];

int main(int, char *[])
{
  FILE *f = fopen("small.rom", "rb");
  fread(buf, 1, sizeof(buf), f);
  fclose(f);
  printf("unsigned char SmallRom[0x3000] = {\n");
  int i = 0;
  while (i < 0x3000) {
    printf("  ");
    for (int j = 0; j < 16; j++) {
      printf("0x%02x,", buf[i++]);
    }
    printf("\n");
  }
  printf("};\n");
  return 0;
}
