#include <windows.h>
#include <stdio.h>      // For sprintf
#include <stdarg.h>

#include "readcpu.h"

#include "romprocnames.h"
#include "debug.h"
#include "RIP.h"

#define kszDumpMode "_DumpMode"
#define kszEnterMode "_EnterMode"

long GetDefaultLines(Debugger *pdbg)
{
    long cLines;
    if (pdbg->EvalVariable(kszNumLines, &cLines) != kerrNone) {
        pdbg->printf("Error: %s is screwed up\n", kszNumLines);
        return 0;
    }
    return cLines;
}

static void dumpstack(Debugger *pdbg)
{
    CPU_regs regs;
    CPU_getregs(regs);
    pdbg->printf("FramePtr Parameters                              Return Address\n");
    DWORD a6 = regs.a[6];
    DWORD lasta6 = a6-1;
    while (CPU_addrcheck(a6, 8) && a6 > lasta6) {
        pdbg->printf("%08x", a6);
        for (int i = 0; i < 8; i++) {
            pdbg->printf(" %04x", CPU_getword(a6+8+i*2));
        }

        char *pszBefore;
        long cbBOffset;
        if (pdbg->FindNearestSymbols(CPU_getlong(a6 + 4), &pszBefore, 
                &cbBOffset))
            pdbg->printf(" %s + $%lx\n", pszBefore, cbBOffset);
        else
            pdbg->printf(" $%lx\n", CPU_getlong(a6 + 4));

        lasta6 = a6;
        a6 = CPU_getlong(a6);
    }
}

void Disassemble(Debugger *pdbg, const char *pszAddress, const char *pszLen, 
        VirtualAddress *pvaNextDis)
{
    VirtualAddress vaDis;
    long count;
    Err err;

    if (pszAddress != NULL) {
        pdbg->Evaluate(pszAddress, (long *)&vaDis, &err);
        if (err != kerrNone) {
            pdbg->printf("Error: Evaluation error %d\n", err);
            return;
        }
    } else {
        vaDis = *pvaNextDis;
    }
    if (pszLen != NULL) {
        pdbg->Evaluate(pszLen, &count, &err);
        if (err != kerrNone) {
            pdbg->printf("Error: Evaluation error %d\n", err);
            return;
        }
    } else
        count = GetDefaultLines(pdbg);

    pdbg->Disassemble(vaDis, count, pvaNextDis);
}

void ExecuteBreakCmd(Debugger *pdbg)
{
   const char *pszCmd = pdbg->GetVariablePtr(kszBreakCmd);
   if (pszCmd != NULL)
        pdbg->Execute(pszCmd);
}

bool DebugCommandHandler(Debugger *pdbg, char *apszArgs[], int cpszArgs)
{
    extern bool IsDumpCmd(const char *pszCmd);
    extern bool IsEnterCmd(const char *pszCmd);
    extern void DcDumpMemory(Debugger *pdbg, const char *pszCmd, 
            const char *pszAddress, const char *pszLen);
    CPU_regs regs;

    char *pszCmd = apszArgs[0];

    //
    // Show or set CPU registers
    //

    if (strcmp("r", pszCmd) == 0) {
        if (cpszArgs > 3) {
            pdbg->printf("Error: incorrect number of arguments\n");
            return TRUE;
        }

        if (cpszArgs == 1) {
            pdbg->DumpCpuState();
            pdbg->SetVariable(kszNextDisasm, GetPC());
        } else {
            ulong *preg = GetRegPtr(regs, apszArgs[1]);
            if (preg == NULL) {
                pdbg->printf("Error: invalid register \"%s\"\n", 
                        apszArgs[1]);
                return TRUE;
            }

            if (cpszArgs == 2) {
                pdbg->printf("%s = $%08lx\n", &apszArgs[1][1], *preg);
            } else {
                Err err;
                pdbg->Evaluate(apszArgs[2], (long *)preg, &err);
                if (err != kerrNone)
                    pdbg->printf("Error: invalid argument \"%s\"\n",
                            apszArgs[2]);
                else
                    CPU_setregs(regs);
            }
        }

    //
    // Disassemble memory
    //
    
    } else if (strcmp("u", pszCmd) == 0) {
        if (cpszArgs > 3) {
            pdbg->printf("Error: too many arguments\n");
            return TRUE;
        }

        VirtualAddress vaNextDisasm;
        pdbg->GetVariable(kszNextDisasm, &vaNextDisasm);

        char *pszAddress = NULL;
        char *pszLen = NULL;

        if (apszArgs[1] != NULL) {
            if (apszArgs[1][0] == 'l')
                pszLen = &apszArgs[1][1];
            else
                pszAddress = apszArgs[1];
        }

        if (apszArgs[2] != NULL) {
            if (apszArgs[2][0] != 'l') {
                pdbg->printf("Error: Invalid length\n");
                return TRUE;
            }

            pszLen = &apszArgs[2][1];
        }

        Disassemble(pdbg, pszAddress, pszLen, &vaNextDisasm);

        pdbg->SetVariable(kszNextDisasm, vaNextDisasm);

    //
    // Trace an instruction (or instructions)
    //
    
    } else if (strcmp("t", pszCmd) == 0) {
        if (cpszArgs > 3) {
            pdbg->printf("Error: too many arguments\n");
            return TRUE;
        }

        if (apszArgs[1] != NULL && apszArgs[1][0] == '=') {
            Err err;
            VirtualAddress vaStart;
            pdbg->Evaluate(&apszArgs[1][1], (long *)&vaStart, &err);
            if (err != kerrNone) {
                pdbg->printf("Error: invalid start address\n");
                return TRUE;
            }

            // Set program counter to new start address

            CPU_getregs(regs);
            regs.pc = vaStart;
            CPU_setregs(regs);

            apszArgs++;
        }

        long cReps;
        if (apszArgs[1] != NULL) {
            Err err;
            pdbg->Evaluate(apszArgs[1], &cReps, &err);
            if (err != kerrNone) {
                pdbg->printf("Error: invalid repeat count\n");
                return TRUE;
            }
        } else {
            cReps = 1;
        }

        for (; cReps > 0; cReps--) {
            pdbg->Step();
            ExecuteBreakCmd(pdbg);
        }
        pdbg->SetVariable(kszNextDisasm, GetPC());

    //
    // Step an instruction (doesn't trace into JSRs, BSRs, etc)
    //
    
    } else if (strcmp("p", pszCmd) == 0) {
        if (cpszArgs > 3) {
            pdbg->printf("Error: too many arguments\n");
            return TRUE;
        }

        if (apszArgs[1] != NULL && apszArgs[1][0] == '=') {
            Err err;
            VirtualAddress vaStart;
            pdbg->Evaluate(&apszArgs[1][1], (long *)&vaStart, &err);
            if (err != kerrNone) {
                pdbg->printf("Error: invalid start address\n");
                return TRUE;
            }

            // Set program counter to new start address

            CPU_getregs(regs);
            regs.pc = vaStart;
            CPU_setregs(regs);

            apszArgs++;
        }

        long cReps;
        if (apszArgs[1] != NULL) {
            Err err;
            pdbg->Evaluate(apszArgs[1], &cReps, &err);
            if (err != kerrNone) {
                pdbg->printf("Error: invalid repeat count\n");
                return TRUE;
            }
        } else {
            cReps = 1;
        }

        for (; cReps > 0; cReps--) {
            VirtualAddress vaPC = GetPC();

            mnemolookup *plup;
            instr *pinstr = table68k + CPU_getword(vaPC);
            for (plup = lookuptab; plup->mnemo != pinstr->mnemo; plup++);
            if (strstr(plup->name, "jsr") != NULL ||
                    strstr(plup->name, "bsr") != NULL ||
                    strstr(plup->name, "trap") != NULL) {
                pdbg->Run(vaPC + GetInstructionLength(pdbg, vaPC));
            } else {
                pdbg->Step();
            }
            ExecuteBreakCmd(pdbg);
        }
        pdbg->SetVariable(kszNextDisasm, GetPC());

    //
    // Run (go) to an address or forever
    //
    
    } else if (strcmp("g", pszCmd) == 0) {
        CPU_regs regs;

        if (cpszArgs > 3) {
            pdbg->printf("Error: too many arguments\n");
            return TRUE;
        }

        if (apszArgs[1] != NULL && apszArgs[1][0] == '=') {
            Err err;
            VirtualAddress vaStart;
            pdbg->Evaluate(&apszArgs[1][1], (long *)&vaStart, &err);
            if (err != kerrNone) {
                pdbg->printf("Error: invalid start address\n");
                return TRUE;
            }

            // Set program counter to new start address

            CPU_getregs(regs);
            regs.pc = vaStart;
            CPU_setregs(regs);

            apszArgs++;
        }

        VirtualAddress vaStop;
        if (apszArgs[1] != NULL) {
            Err err;
            pdbg->Evaluate(apszArgs[1], (long *)&vaStop, &err);
            if (err != kerrNone) {
                pdbg->printf("Error: Bad address \"%s\"\n", apszArgs[1]);
                return TRUE;
            }
        } else {
            vaStop = kvaInvalid;
        }

        pdbg->Run(vaStop);
        ExecuteBreakCmd(pdbg);

        pdbg->SetVariable(kszNextDisasm, GetPC());
    
    // 
    // Dump memory
    //

    } else if (IsDumpCmd(pszCmd)) {
        char *pszAddress = NULL;
        char *pszLen = NULL;

        if (apszArgs[1] != NULL) {
            if (apszArgs[1][0] == 'l')
                pszLen = &apszArgs[1][1];
            else
                pszAddress = apszArgs[1];
        }

        if (apszArgs[2] != NULL) {
            if (apszArgs[2][0] != 'l') {
                pdbg->printf("Error: Invalid length\n");
                return TRUE;
            }

            pszLen = &apszArgs[2][1];
        }

        DcDumpMemory(pdbg, pszCmd, pszAddress, pszLen);

    //
    // Dump a stack backtrace
    //

    } else if (strcmp("k", pszCmd) == 0) {
        dumpstack(pdbg);

    //
    // Show help
    //

    } else if (strcmp("help", pszCmd) == 0 || strcmp("?", pszCmd) == 0) {
        char szT[100];
        FILE *pfil = fopen("debugger.hlp", "r");
        if (pfil == (FILE *)-1 || pfil == NULL) {
            pdbg->printf("Error: Can't file help file \"debugger.hlp\"\n");
            return TRUE;
        }

        while (fgets(szT, sizeof(szT), pfil) != NULL)
            pdbg->printf(szT);
        fclose(pfil);

    //
    // Show/set/clear variables
    //

    } else if (strcmp("set", pszCmd) == 0) {
        CPU_regs regs;

        if (cpszArgs > 3) {
            pdbg->printf("Error: too many arguments.\n");
            return TRUE;
        }

        // If no other args then the user just wants a list.

        if (cpszArgs == 1) {
            Variable *pvar;
            Position pos;
            while ((pvar = pdbg->GetNextVariable(&pos)) != NULL)
                pdbg->printf("%s = %s\n", pvar->pszName, pvar->pszValue);
        } else {
            if (apszArgs[1][0] == '.') {
                ulong *preg = GetRegPtr(regs, apszArgs[1]);
                if (preg == NULL) {
                    pdbg->printf("Error: invalid register \"%s\"\n", 
                            apszArgs[1]);
                } else {
                    Err err;
                    pdbg->Evaluate(apszArgs[2], (long *)preg, &err);
                    if (err != kerrNone)
                        pdbg->printf("Error: invalid argument \"%s\"\n",
                                apszArgs[2]);
                    else
                        CPU_setregs(regs);
                }
            } else if (!pdbg->SetVariable(apszArgs[1], apszArgs[2])) {
                if (apszArgs[2] == NULL)
                    pdbg->printf("Error: variable \"%s\" doesn't exist.\n", 
                            apszArgs[1]);
                else
                    pdbg->printf("Error: can't set variable \"%s\".\n", 
                            apszArgs[1]);
            }
        }

    //
    // Print the results of an evaluated expression(s)
    //

    } else if (strcmp("print", pszCmd) == 0) {

        if (cpszArgs > 1) {
            for (int i = 1; i < cpszArgs; i++) {
                Err err;
                long lValue;
                pdbg->Evaluate(apszArgs[i], &lValue, &err);
                if (err != kerrNone)
                    pdbg->printf("<err> ");
                else
                    pdbg->printf("$%lx ", lValue);
            }
        }
        pdbg->printf("\n");

    //
    // Print the formatted results of an evaluated expression(s)
    //

    } else if (strcmp("printf", pszCmd) == 0) {

        if (cpszArgs < 2) {
            pdbg->printf("Error: missing format string\n");
        } else {
            long alT[20];
            Assert(cpszArgs <= 20);
            for (int i = 2; i < cpszArgs; i++) {
                Err err;
                pdbg->Evaluate(apszArgs[i], &alT[i - 2], &err);
                if (err != kerrNone)
                    alT[i - 2] = 0;
            }

            char szT[512];
            vsprintf(szT, apszArgs[1], (char *)alT);
            pdbg->printf("%s\n", szT); 
        }

    //
    // Show or set the default number base (radix)
    //

    } else if (strcmp("n", pszCmd) == 0) {
        if (cpszArgs > 2) {
            pdbg->printf("Error: too many arguments\n");
            return TRUE;
        }

        if (cpszArgs == 1) {
            pdbg->printf("Current default radix is %d\n", 
                    pdbg->GetDefaultBase());
            return TRUE;
        }

        Err err;
        long nBase;
        pdbg->Evaluate(apszArgs[1], &nBase, &err);
        if (err != kerrNone) {
            pdbg->printf("Error: Couldn't evaluate \"%s\"\n", apszArgs[1]);
            return TRUE;
        }
        pdbg->SetDefaultBase(nBase);

    //
    // Enter data into memory
    //

    } else if (IsEnterCmd(pszCmd)) {
        if (cpszArgs < 3) {
            pdbg->printf("Error: not enough arguments\n");
            return TRUE;
        }

        // Figure out which enter mode we're supposed to use.

        char chEnterMode = *(pszCmd + 1);
        if (chEnterMode == 0) {
            const char *pszEnterMode = pdbg->GetVariablePtr(kszEnterMode);
            if (pszEnterMode != NULL)
                chEnterMode = *pszEnterMode;
            else
                chEnterMode = 'b';
        }

        VirtualAddress vaEnter;
        Err err;
        pdbg->Evaluate(apszArgs[1], (long *)&vaEnter, &err);
        if (err != kerrNone) {
            pdbg->printf("Error: Bad address \"%s\"\n", apszArgs[1]);
            return TRUE;
        }

        for (int i = 2; i < cpszArgs; i++) {
            long lValue;
            if (chEnterMode != 'a') {
                pdbg->Evaluate(apszArgs[i], &lValue, &err);
                if (err != kerrNone) {
                    pdbg->printf("Error: Invalid expression \"%s\"\n",
                            apszArgs[i]);
                    return TRUE;
                }
            }

            switch (chEnterMode) {
            case 'a':
                {
                    char *pch = apszArgs[i];
                    while (*pch != 0)
                        CPU_putbyte(vaEnter++, *pch++);
                }
                break;

            case 'b':
                // UNDONE: error handling?
                CPU_putbyte(vaEnter++, (byte)lValue);
                break;

            case 'w':
                CPU_putword(vaEnter, (ushort)lValue);
                vaEnter += 2;
                break;

            case 'd':
                CPU_putlong(vaEnter, (ulong)lValue);
                vaEnter += 4;
                break;
            }
        }

    //
    // List first symbols before and after address
    //

    } else if (strcmp("ln", pszCmd) == 0) {
        if (cpszArgs > 2) {
            pdbg->printf("Error: too many arguments\n");
            return TRUE;
        }

        VirtualAddress va;
        if (apszArgs[1] != NULL) {
            Err err;
            pdbg->Evaluate(apszArgs[1], (long *)&va, &err);
            if (err != kerrNone) {
                pdbg->printf("Error: invalid address\n");
                return TRUE;
            }
        } else {
            CPU_getregs(regs);
            va = regs.pc;
        }

        char *pszBefore, *pszAfter;
        long cbBOffset, cbAOffset;
        if (pdbg->FindNearestSymbols(va, &pszBefore, &cbBOffset, &pszAfter, 
                &cbAOffset)) {
            pdbg->printf("%s + $%lx, %s - $%lx\n", pszBefore, cbBOffset, 
                    pszAfter, cbAOffset);
        } else {
            pdbg->printf("<unknown>\n");
        }

    //
    // Set a breakpoint
    //

    } else if (strcmp("bp", pszCmd) == 0) {
        VirtualAddress va;
        Err err;
        if (cpszArgs > 1) {
            if (strcmp("-na", apszArgs[1]) == 0) {
                extern bool NextAppStartupBpHandler(Debugger *pdbg, Bpid bpid);
                SetBreakpoint(kvaNextAppStartup, kbpidNextAppStartup, 
                        NextAppStartupBpHandler);
                return TRUE;
            } else {
                pdbg->Evaluate(apszArgs[1], (long *)&va, &err);
                if (err != kerrNone) {
                    pdbg->printf("Error: invalid address\n");
                    return TRUE;
                }
            }
        } else {
            va = GetPC();
        }

        if (!SetBreakpoint(va))
            pdbg->printf("Error: breakpoint not set -- all breakpoint slots used up\n");

    //
    // List breakpoints
    //

    } else if (strcmp("bl", pszCmd) == 0) {
        if (cpszArgs != 1) {
            pdbg->printf("Error: too many arguments\n");
            return TRUE;
        }

        ShowBreakpoints(pdbg);

    //
    // Clear breakpoints
    //

    } else if (strcmp("bc", pszCmd) == 0) {
        if (cpszArgs != 2) {
            pdbg->printf("Error: incorrect number of arguments\n");
            return TRUE;
        }

        if (strcmp(apszArgs[1], "*") == 0) {
            ClearBreakpoint(kbpidAll);
        } else {
            long lValue;
            Err err;
            pdbg->Evaluate(apszArgs[1], &lValue, &err);
            if (err != kerrNone || lValue < 0 || lValue >= kcbpUserMax) {
                pdbg->printf("Error: invalid breakpoint id\n");
                return TRUE;
            }

            if (!ClearBreakpoint(lValue))
                pdbg->printf("Error: no breakpoint id %d\n", lValue);
        }

    //
    // Enable breakpoints
    //

    } else if (strcmp("be", pszCmd) == 0) {
        if (cpszArgs != 2) {
            pdbg->printf("Error: incorrect number of arguments\n");
            return TRUE;
        }

        if (strcmp(apszArgs[1], "*") == 0) {
            EnableBreakpoint(kbpidAll, TRUE);
        } else {
            long lValue;
            Err err;
            pdbg->Evaluate(apszArgs[1], &lValue, &err);
            if (err != kerrNone || lValue < 0 || lValue >= kcbpUserMax) {
                pdbg->printf("Error: invalid breakpoint id\n");
                return TRUE;
            }
            if (!EnableBreakpoint(lValue, TRUE))
                pdbg->printf("Error: no breakpoint id %d\n", lValue);
        }

    //
    // Disable breakpoints
    //

    } else if (strcmp("bd", pszCmd) == 0) {
        if (cpszArgs != 2) {
            pdbg->printf("Error: incorrect number of arguments\n");
            return TRUE;
        }

        if (strcmp(apszArgs[1], "*") == 0) {
            EnableBreakpoint(kbpidAll, FALSE);
        } else {
            long lValue;
            Err err;
            pdbg->Evaluate(apszArgs[1], &lValue, &err);
            if (err != kerrNone || lValue < 0 || lValue >= kcbpUserMax) {
                pdbg->printf("Error: invalid breakpoint id\n");
                return TRUE;
            }
            if (!EnableBreakpoint(lValue, FALSE))
                pdbg->printf("Error: no breakpoint id %d\n", lValue);
        }

    //
    // Dump handle info and (optionally) chunk data
    //

    } else if (strcmp("dh", pszCmd) == 0) {
        if (cpszArgs < 2) {
            pdbg->printf("Error: incorrect number of arguments\n");
            return TRUE;
        }

        bool fDumpData = FALSE;
        if (strcmp(apszArgs[1], "-d") == 0) {
            apszArgs++;
            fDumpData = TRUE;
        }

        ulong h;
        Err err;
        pdbg->Evaluate(apszArgs[1], (long *)&h, &err);
        if (err != kerrNone) {
            pdbg->printf("Error: invalid address\n");
            return TRUE;
        }

        VirtualAddress va = GetHandlePtr(h);
        pdbg->printf("handle:    $%lx\n", h);
        pdbg->printf("pointer:   $%lx\n", va);
        long cbSize = CPU_getword(va - 6);
        pdbg->printf("size:      $%x (%d)\n", cbSize, cbSize);
        byte flags = CPU_getbyte(va - 6 + 3);
        long cbAdjSize = (cbSize - (flags & 0xf)) - 6;
        pdbg->printf("adj. size: $%x (%d)\n", cbAdjSize, cbAdjSize);
        pdbg->printf("lockOwner: $%x\n", CPU_getbyte(va - 6 + 2));
        pdbg->printf("flags:     $%x\n", flags);
        pdbg->printf("hOffset:   $%x\n", CPU_getword(va - 2));

        if (fDumpData) {
            pdbg->printf("\n");
            char szT[80];
            sprintf(szT, "db $%lx l$%lx", va, cbAdjSize);
            pdbg->Execute(szT);
        }

    //
    // Dump active module's symbol list
    //

    } else if (strcmp("ds", pszCmd) == 0) {
        extern bool DumpSymbols(Debugger *pdbg);

        DumpSymbols(pdbg);

    //
    // Command not handled!
    //

    } else {
        return FALSE;
    }

    return TRUE;
}


bool IsDumpCmd(const char *pszCmd)
{
    if (*pszCmd++ != 'd')
        return FALSE;
    if (*pszCmd == 0)
        return TRUE;
    if (strchr("abwd", *pszCmd++) == NULL)
        return FALSE;
    if (*pszCmd != 0)
        return FALSE;
    return TRUE;
}

bool IsEnterCmd(const char *pszCmd)
{
    if (*pszCmd++ != 'e')
        return FALSE;
    if (*pszCmd == 0)
        return TRUE;
    if (strchr("abwd", *pszCmd++) == NULL)
        return FALSE;
    if (*pszCmd != 0)
        return FALSE;
    return TRUE;
}

void DcDumpMemory(Debugger *pdbg, const char *pszCmd, const char *pszAddress,
        const char *pszLen)
{
    // Figure out which dump mode we're supposed to use.

    char chDumpMode = *(pszCmd + 1);
    if (chDumpMode == 0) {
        const char *pszDumpMode = pdbg->GetVariablePtr(kszDumpMode);
        if (pszDumpMode != NULL)
            chDumpMode = *pszDumpMode;
        else
            chDumpMode = 'b';
    }

    int cPerLine;
    switch (chDumpMode) {
    case 'a':
        cPerLine = 64;
        break;

    case 'b':
        cPerLine = 16;
        break;

    case 'w':
        cPerLine = 12;
        break;

    case 'd':
        cPerLine = 7;
        break;

    default:
        Assert(FALSE, "Unknown dump mode!");
    }

    VirtualAddress vaDump;
    Err err;

    if (pszAddress != NULL) {
        pdbg->Evaluate(pszAddress, (long *)&vaDump, &err);
        if (err != kerrNone) {
            pdbg->printf("Error: Bad address \"%s\"\n", pszAddress);
            return;
        }
    } else {
        if (!pdbg->GetVariable(kszNextDump, &vaDump)) {
            pdbg->printf("Error: Someone deleted the _NextDump variable!\n");
            return;
        }
    }

    long cCount;
    if (pszLen != NULL) {
        pdbg->Evaluate(pszLen, &cCount, &err);
        if (err != kerrNone || cCount == 0) {
            pdbg->printf("Error: Bad count \"%s\"\n", pszLen);
            return;
        }
    } else {
        cCount = GetDefaultLines(pdbg) * cPerLine;
    }

    // UNDONE: can't CPU_getXXX fail? what should we do?

    while (cCount > 0) {
        char ch, szOut[12], szT[85];
        VirtualAddress va = vaDump;
        int c = min(cPerLine, cCount);
        sprintf(szT, "%08lx: ", vaDump);

        szT[0] = 0;
        for (int i = 0; i < c; i++) {
            switch (chDumpMode) {
            case 'a':
                ch = CPU_getbyte(va++);
                if (ch < ' ' || ch > 0x7f)
                    ch = '.';
                sprintf(szOut, "%c", ch);
                break;

            case 'b':
                sprintf(szOut, "%02x ", CPU_getbyte(va));
                va++;
                break;

            case 'w':
                sprintf(szOut, "%04x ", CPU_getword(va));
                va += 2;
                break;

            case 'd':
                sprintf(szOut, "%08x ", CPU_getlong(va));
                va += 4;
                break;
            }
            strcat(szT, szOut);
        }

        if (chDumpMode == 'b') {
            char *pch = szT;
            char *pchAsciiStart = pch + 52;
            while (*++pch);
            while (pch < pchAsciiStart)
                *pch++ = ' ';
            va = vaDump;
            for (i = 0; i < c; i++) {
                ch = CPU_getbyte(va++);
                if (ch < ' ' || ch > 0x7f)
                    ch = '.';
                *pch++ = ch;
            }
            *pch = 0;
        }

        pdbg->printf("%08lx: %s\n", vaDump, szT);
        vaDump += c;
        cCount -= c;
    }
        

    pdbg->SetVariable(kszNextDump, vaDump);

    // Update the new dump mode

    char szT[2];
    szT[0] = chDumpMode;
    szT[1] = 0;
    pdbg->SetVariable(kszDumpMode, szT);
}


bool NextAppStartupBpHandler(Debugger *pdbg, Bpid bpid)
{
    ClearBreakpoint(bpid);

    if (bpid == kbpidNextAppStartup) {
        CPU_regs regs;
        CPU_getregs(regs);

        SetBreakpoint(regs.d[6], kbpidAppEntrypoint, NextAppStartupBpHandler);
        return TRUE;
    }

    return FALSE;
}
