 /* 
  * Copilot
  * 
  * memory management
  * 
  * Original UAE code Copyright (c) 1995 Bernd Schmidt
  */

typedef ULONG (*lget_func)(CPTR);
typedef UWORD (*wget_func)(CPTR);
typedef UBYTE (*bget_func)(CPTR);
typedef void (*lput_func)(CPTR,ULONG);
typedef void (*wput_func)(CPTR,UWORD);
typedef void (*bput_func)(CPTR,UBYTE);
typedef UWORD *(*xlate_func)(CPTR);
typedef int (*check_func)(CPTR, ULONG);

typedef struct {
    lget_func lget;
    wget_func wget;
    bget_func bget;
    lput_func lput;
    wput_func wput;
    bput_func bput;
    xlate_func xlateaddr;
    check_func check;
} addrbank;

extern addrbank ram_bank;
extern addrbank rom_bank;
extern addrbank custom_bank;

/* Default memory access functions */

extern int default_check(CPTR addr, ULONG size);
extern UWORD *default_xlate(CPTR addr);

extern addrbank *membanks;
static inline unsigned int bankindex(CPTR a)
{
    return a>>16;
}

static inline ULONG longget(CPTR addr)
{
    return membanks[bankindex(addr)].lget(addr);
}
static inline UWORD wordget(CPTR addr)
{
    return membanks[bankindex(addr)].wget(addr);
}
static inline UBYTE byteget(CPTR addr) 
{
    return membanks[bankindex(addr)].bget(addr);
}
static inline void longput(CPTR addr, ULONG l)
{
    membanks[bankindex(addr)].lput(addr, l);
}
static inline void wordput(CPTR addr, UWORD w)
{
    membanks[bankindex(addr)].wput(addr, w);
}
static inline void byteput(CPTR addr, UBYTE b)
{
    membanks[bankindex(addr)].bput(addr, b);
}

static inline int check_addr(CPTR a)
{
#ifdef NO_EXCEPTION_3
    return 1;
#else
    return (a & 1) == 0;
#endif
}
extern int buserr;
    
extern int memory_init(int ramsize, const char *romfn);
    
static inline ULONG get_long(CPTR addr) 
{
    if (check_addr(addr))
	return longget(addr);
    buserr = 1;
    return 0;
}
static inline UWORD get_word(CPTR addr) 
{
    if (check_addr(addr))
	return wordget(addr);
    buserr = 1;
    return 0;
}
static inline UBYTE get_byte(CPTR addr) 
{
    return byteget(addr); 
}
static inline void put_long(CPTR addr, ULONG l) 
{
    if (!check_addr(addr))
	buserr = 1;
    longput(addr, l);
}
static inline void put_word(CPTR addr, UWORD w) 
{
    if (!check_addr(addr))
	buserr = 1;
    wordput(addr, w);
}
static inline void put_byte(CPTR addr, UBYTE b) 
{
    byteput(addr, b);
}

static inline UWORD *get_real_address(CPTR addr)
{
    if (!check_addr(addr))
	buserr = 1;
    return membanks[bankindex(addr)].xlateaddr(addr);
}

static inline int valid_address(CPTR addr, ULONG size)
{
    if (!check_addr(addr))
	buserr = 1;
    return membanks[bankindex(addr)].check(addr, size);
}
