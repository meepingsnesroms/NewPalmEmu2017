// pilotcpu.dll CPU_init() error definitions

const PILOTCPU_ROM_NOT_FOUND = 1;
const PILOTCPU_ERROR_LOADING_ROM = 2;
const PILOTCPU_ERROR_LOADING_RAM = 3;
