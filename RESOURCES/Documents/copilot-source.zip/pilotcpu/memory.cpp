 /*
  * Copilot
  *
  * Memory management
  *
  * Original UAE code Copyright (c) 1995 Bernd Schmidt
  */

#include "win.h"

#include "sysdeps.h"

#include "memory.h"
#include "custom.h"
#include "cpuerror.h"

int ram_size;
int ram_size_mask;
//#define rom_size 0x080000 // 512k
#define rom_size 0x100000 // 1 MB

#define ram_start 0x00000000
#define rom_start 0x10c00000
#define scratch_start 0x00010000

int sram_protect;

int buserr;
addrbank *membanks;

#include "smallrom.inc"

/* Default memory access functions */

int default_check(CPTR a, ULONG b)
{
    return 0;
}

UWORD *default_xlate(CPTR a)
{
//    fprintf(stderr, "Your Pilot program just did something terribly stupid\n");
    return 0;
}

/* A dummy bank that only contains zeros */

static ULONG dummy_lget(CPTR);
static UWORD dummy_wget(CPTR);
static UBYTE dummy_bget(CPTR);
static void  dummy_lput(CPTR, ULONG);
static void  dummy_wput(CPTR, UWORD);
static void  dummy_bput(CPTR, UBYTE);
static int   dummy_check(CPTR addr, ULONG size);
static UWORD *dummy_xlate(CPTR addr);

ULONG dummy_lget(CPTR addr)
{
    buserr = 1;
    return 0;
}

UWORD dummy_wget(CPTR addr)
{
    if ((addr & 0xFF000000) != 0x10000000) {
      buserr = 1;
    }
    return 0;
}

UBYTE dummy_bget(CPTR addr)
{
    buserr = 1;
    return 0;
}

void dummy_lput(CPTR addr, ULONG l)
{
  buserr = 1;
}

void dummy_wput(CPTR addr, UWORD w)
{
  if ((addr & 0xFF000000) != 0x10000000) {
    buserr = 1;
  }
}

void dummy_bput(CPTR addr, UBYTE b)
{
  buserr = 1;
}

int dummy_check(CPTR addr, ULONG size)
{
    return 0;
}

UWORD *dummy_xlate(CPTR addr)
{
    return NULL;
}

/* RAM */

UWORD *rammemory;

static ULONG ram_lget(CPTR);
static UWORD ram_wget(CPTR);
static UBYTE ram_bget(CPTR);
static void  ram_lput(CPTR, ULONG);
static void  ram_wput(CPTR, UWORD);
static void  ram_bput(CPTR, UBYTE);
static int   ram_check(CPTR addr, ULONG size);
static UWORD *ram_xlate(CPTR addr);

ULONG ram_lget(CPTR addr)
{
    addr -= ram_start & (ram_size_mask);
    addr &= ram_size_mask;
    return ((ULONG)rammemory[addr >> 1] << 16) | rammemory[(addr >> 1)+1];
}

UWORD ram_wget(CPTR addr)
{
    addr -= ram_start & (ram_size_mask);
    addr &= ram_size_mask;
    return rammemory[addr >> 1];
}

UBYTE ram_bget(CPTR addr)
{
    addr -= ram_start & (ram_size_mask);
    addr &= ram_size_mask;
    if (addr & 1) 
	return rammemory[addr >> 1];
    else
	return rammemory[addr >> 1] >> 8;
}

void ram_lput(CPTR addr, ULONG l)
{
    addr -= ram_start & (ram_size_mask);
    addr &= ram_size_mask;
    rammemory[addr >> 1] = l >> 16;
    rammemory[(addr >> 1)+1] = (UWORD)l;
}

void sram_lput(CPTR addr, ULONG l)
{
    if (sram_protect) {
      buserr = 1;
    } else {
      ram_lput(addr, l);
    }
}

void ram_wput(CPTR addr, UWORD w)
{
    addr -= ram_start & (ram_size_mask);
    addr &= ram_size_mask;
    rammemory[addr >> 1] = w;
}

void sram_wput(CPTR addr, UWORD w)
{
    if (sram_protect) {
      buserr = 1;
    } else {
      ram_wput(addr, w);
    }
}

void ram_bput(CPTR addr, UBYTE b)
{
    addr -= ram_start & (ram_size_mask);
    addr &= ram_size_mask;
    if (!(addr & 1)) {
	rammemory[addr>>1] = (rammemory[addr>>1] & 0xff) | (((UWORD)b) << 8);
    } else {
	rammemory[addr>>1] = (rammemory[addr>>1] & 0xff00) | b;
    }
}

void sram_bput(CPTR addr, UBYTE b)
{
    if (sram_protect) {
      buserr = 1;
    } else {
      ram_bput(addr, b);
    }
}

int ram_check(CPTR addr, ULONG size)
{
    addr -= ram_start & (ram_size_mask);
    addr &= ram_size_mask;
    return (addr + size) < (ULONG)ram_size;
}

UWORD *ram_xlate(CPTR addr)
{
    addr -= ram_start & (ram_size_mask);
    addr &= ram_size_mask;
    return rammemory + (addr >> 1);
}

/* ROM */

static UWORD *rommemory;

static ULONG rom_lget(CPTR);
static UWORD rom_wget(CPTR);
static UBYTE rom_bget(CPTR);
static void  rom_lput(CPTR, ULONG);
static void  rom_wput(CPTR, UWORD);
static void  rom_bput(CPTR, UBYTE);
static int  rom_check(CPTR addr, ULONG size);
static UWORD *rom_xlate(CPTR addr);

ULONG rom_lget(CPTR addr)
{
    addr -= rom_start & (rom_size-1);
    addr &= rom_size-1;
    return ((ULONG)rommemory[addr >> 1] << 16) | rommemory[(addr >> 1)+1];
}

UWORD rom_wget(CPTR addr)
{
    addr -= rom_start & (rom_size-1);
    addr &= rom_size-1;
    return rommemory[addr >> 1];
}

UBYTE rom_bget(CPTR addr)
{
    addr -= rom_start & (rom_size-1);
    addr &= rom_size-1;
    return rommemory[addr >> 1] >> (addr & 1 ? 0 : 8);
}

void rom_lput(CPTR a, ULONG b)
{
  buserr = 1;
}

void rom_wput(CPTR a, UWORD b)
{
  buserr = 1;
}

void rom_bput(CPTR a, UBYTE b)
{
  buserr = 1;
}

int rom_check(CPTR addr, ULONG size)
{
    addr -= rom_start & (rom_size-1);
    addr &= rom_size-1;
    return (addr + size) < rom_size;
}

UWORD *rom_xlate(CPTR addr)
{
    addr -= rom_start & (rom_size-1);
    addr &= rom_size-1;
    return rommemory + (addr >> 1);
}

static int load_rom(const char *romfn)
{
    rommemory = (UWORD *)VirtualAlloc(NULL, rom_size, MEM_COMMIT, PAGE_READWRITE);
    if (rommemory == NULL) {
        return PILOTCPU_ERROR_LOADING_ROM;
    }
    
    HANDLE f = CreateFile(romfn, GENERIC_READ, FILE_SHARE_READ, NULL, OPEN_EXISTING, FILE_FLAG_SEQUENTIAL_SCAN, NULL);
    if (f == INVALID_HANDLE_VALUE) {
        return PILOTCPU_ROM_NOT_FOUND;
    }
    
    unsigned long n;
    if (!ReadFile(f, rommemory, rom_size, &n, NULL)) {
        return PILOTCPU_ERROR_LOADING_ROM;
    }
    CloseHandle(f);

    if (rommemory[0x3008/2] != 0xedfe || rommemory[0x300a/2] != 0xefbe) {
      memmove(&rommemory[0x3000/2], rommemory, rom_size-0x3000);
      memmove(rommemory, SmallRom, 0x3000);
    }
    
    for (int i = 0; i < rom_size/2; i++) {
	UWORD *p = rommemory + i;
	UBYTE *bp = (UBYTE *)p;
	*p = (*bp << 8) | *(bp+1);
    }

    return 0;
}

/* Scratch area */

UBYTE *scratchmemory = NULL;

static ULONG scratch_lget(CPTR);
static UWORD scratch_wget(CPTR);
static UBYTE scratch_bget(CPTR);
static void  scratch_lput(CPTR, ULONG);
static void  scratch_wput(CPTR, UWORD);
static void  scratch_bput(CPTR, UBYTE);
static int   scratch_check(CPTR addr, ULONG size);
static UWORD *scratch_xlate(CPTR addr);

ULONG scratch_lget(CPTR addr)
{
    if (scratchmemory == NULL) return dummy_lget(addr);
    addr -= scratch_start;
    return ((ULONG)scratchmemory[addr] << 24)
         | ((ULONG)scratchmemory[addr+1] << 16)
         | ((ULONG)scratchmemory[addr+2] << 8)
         | scratchmemory[addr+3];
}

UWORD scratch_wget(CPTR addr)
{
    if (scratchmemory == NULL) return dummy_wget(addr);
    addr -= scratch_start;
    return ((UWORD)scratchmemory[addr] << 8) | scratchmemory[addr+1];
}

UBYTE scratch_bget(CPTR addr)
{
    if (scratchmemory == NULL) return dummy_lget(addr);
    addr -= scratch_start;
    return scratchmemory[addr];
}

void scratch_lput(CPTR addr, ULONG l)
{
    if (scratchmemory == NULL) return;
    addr -= scratch_start;
    scratchmemory[addr] = l >> 24;
    scratchmemory[addr+1] = l >> 16;
    scratchmemory[addr+2] = l >> 8;
    scratchmemory[addr+3] = l;
}

void scratch_wput(CPTR addr, UWORD w)
{
    if (scratchmemory == NULL) return;
    addr -= scratch_start;
    scratchmemory[addr] = w >> 8;
    scratchmemory[addr+1] = w;
}

void scratch_bput(CPTR addr, UBYTE b)
{
    if (scratchmemory == NULL) return;
    addr -= scratch_start;
    scratchmemory[addr] = b;
}

int scratch_check(CPTR addr, ULONG size)
{
    if (scratchmemory == NULL) return 0;
    return 1;
}

UWORD *scratch_xlate(CPTR addr)
{
    return NULL; // anything that calls this will assume swapped byte order!
}

/* Address banks */

addrbank dummy_bank = {
    dummy_lget, dummy_wget, dummy_bget,
    dummy_lput, dummy_wput, dummy_bput,
    dummy_xlate, dummy_check
};

addrbank ram_bank = {
    ram_lget, ram_wget, ram_bget,
    ram_lput, ram_wput, ram_bput,
    ram_xlate, ram_check
};

// sram is Storage RAM
addrbank sram_bank = {
    ram_lget, ram_wget, ram_bget,
    sram_lput, sram_wput, sram_bput,
    ram_xlate, ram_check
};

addrbank rom_bank = {
    rom_lget, rom_wget, rom_bget,
    rom_lput, rom_wput, rom_bput,
    rom_xlate, rom_check
};

addrbank scratch_bank = {
    scratch_lget, scratch_wget, scratch_bget,
    scratch_lput, scratch_wput, scratch_bput,
    scratch_xlate, scratch_check
};

void map_banks(addrbank bank, int start, int size)
{
    int bnr;
    for (bnr = start; bnr < start+size; bnr++) 
       membanks[bnr] = bank;
}

int memory_init(int ramsize, const char *romfn)
{
    int i;
    buserr = 0;

    if (ramsize & (ramsize-1)) {
      return PILOTCPU_ERROR_LOADING_RAM;
    }
    ram_size = ramsize * 1024;
    ram_size_mask = ram_size-1;
    char fn[40];
    sprintf(fn, "pilot%d.ram", ramsize);
    HANDLE f = CreateFile(fn, GENERIC_READ|GENERIC_WRITE, FILE_SHARE_READ, NULL, OPEN_ALWAYS, FILE_FLAG_RANDOM_ACCESS, NULL);
    if (f == INVALID_HANDLE_VALUE) {
      return PILOTCPU_ERROR_LOADING_RAM;
    }
    while (1) {
      long left = ram_size - GetFileSize(f, NULL);
      if (left <= 0) {
        break;
      }
      BYTE buf[8192];
      memset(buf, 0, sizeof(buf));
      if (left > sizeof(buf)) {
        left = sizeof(buf);
      }
      DWORD n;
      if (!WriteFile(f, buf, left, &n, NULL) || n != (DWORD)left) {
        return PILOTCPU_ERROR_LOADING_RAM;
      }
    }
    HANDLE map = CreateFileMapping(f, NULL, PAGE_READWRITE, 0, ram_size, NULL);
    if (map == NULL) {
      return PILOTCPU_ERROR_LOADING_RAM;
    }
    rammemory = (UWORD *)MapViewOfFile(map, FILE_MAP_ALL_ACCESS, 0, 0, ram_size);
    if (rammemory == NULL) {
      return PILOTCPU_ERROR_LOADING_RAM;
    }

    membanks = (addrbank *)VirtualAlloc(NULL, 65536*sizeof(addrbank), MEM_COMMIT, PAGE_READWRITE);

    for(i = 0; i < 65536; i++)
	membanks[i] = dummy_bank;
    
    map_banks(ram_bank, 0x0000, 1);
    map_banks(sram_bank, 0x1000, ram_size/0x10000);
    map_banks(rom_bank, 0x10c0, rom_size/0x10000);
    map_banks(scratch_bank, 0x0001, 16);
    map_banks(custom_bank, 0xFFFF, 1);
    
    return load_rom(romfn);
}
