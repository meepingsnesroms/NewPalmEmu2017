 /* 
  * Copilot
  * 
  * Dragonball chip support
  *
  * Copyright (c) 1996 Greg Hewgill
  */

extern void custom_init(void *commhandle);
extern void customreset(void);
extern int intbase(void);
extern int intlev(void);
extern void dumpcustom(void);
extern void do_cycles(int longtime);
extern int do_api(int api);

extern unsigned long cycles;
extern unsigned long specialflags;

#define SPCFLAG_STOP 2
#define SPCFLAG_INT  8
#define SPCFLAG_BRK  16
#define SPCFLAG_TRACE 64
#define SPCFLAG_DOTRACE 128
#define SPCFLAG_DOINT 256
