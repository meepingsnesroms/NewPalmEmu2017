// stuff from Windows, without Windows

#define WORD unsigned short
#define LONG signed long

#define APIENTRY __stdcall

typedef void *HANDLE;
typedef unsigned long DWORD;
typedef int BOOL;

const BOOL FALSE = 0;
const BOOL TRUE = !FALSE;

const DWORD INFINITE = 0xFFFFFFFF;
const HANDLE INVALID_HANDLE_VALUE = (HANDLE)0xFFFFFFFF;
const DWORD WAIT_OBJECT_0 = 0;

#define CreateEvent       CreateEventA
#define CreateFile        CreateFileA
#define CreateFileMapping CreateFileMappingA
#define CreateMutex       CreateMutexA
#define CreateSemaphore   CreateSemaphoreA
#define OutputDebugString OutputDebugStringA

#define STANDARD_RIGHTS_REQUIRED         (0x000F0000L)

#define SECTION_QUERY       0x0001
#define SECTION_MAP_WRITE   0x0002
#define SECTION_MAP_READ    0x0004
#define SECTION_MAP_EXECUTE 0x0008
#define SECTION_EXTEND_SIZE 0x0010

#define SECTION_ALL_ACCESS (STANDARD_RIGHTS_REQUIRED|SECTION_QUERY|\
                            SECTION_MAP_WRITE |      \
                            SECTION_MAP_READ |       \
                            SECTION_MAP_EXECUTE |    \
                            SECTION_EXTEND_SIZE)

#define FILE_MAP_ALL_ACCESS SECTION_ALL_ACCESS

#define PAGE_READWRITE         0x04     
#define MEM_COMMIT           0x1000     

#define GENERIC_READ                     (0x80000000L)
#define GENERIC_WRITE                    (0x40000000L)
#define FILE_SHARE_READ                 0x00000001  

#define OPEN_EXISTING       3
#define OPEN_ALWAYS         4
#define FILE_FLAG_OVERLAPPED            0x40000000
#define FILE_FLAG_RANDOM_ACCESS         0x10000000
#define FILE_FLAG_SEQUENTIAL_SCAN       0x08000000

#define ERROR_IO_PENDING                 997L    // dderror

#define THREAD_BASE_PRIORITY_MAX    2   // maximum thread base priority boost
#define THREAD_PRIORITY_HIGHEST         THREAD_BASE_PRIORITY_MAX

typedef struct _LIST_ENTRY {
   struct _LIST_ENTRY *Flink;
   struct _LIST_ENTRY *Blink;
} LIST_ENTRY, *PLIST_ENTRY;

typedef struct _RTL_CRITICAL_SECTION_DEBUG {
    WORD   Type;
    WORD   CreatorBackTraceIndex;
    struct _RTL_CRITICAL_SECTION *CriticalSection;
    LIST_ENTRY ProcessLocksList;
    DWORD EntryCount;
    DWORD ContentionCount;
    DWORD Spare[ 2 ];
} RTL_CRITICAL_SECTION_DEBUG, *PRTL_CRITICAL_SECTION_DEBUG;

#define RTL_CRITSECT_TYPE 0
#define RTL_RESOURCE_TYPE 1

typedef struct _RTL_CRITICAL_SECTION {
    PRTL_CRITICAL_SECTION_DEBUG DebugInfo;

    //
    //  The following three fields control entering and exiting the critical
    //  section for the resource
    //

    LONG LockCount;
    LONG RecursionCount;
    HANDLE OwningThread;        // from the thread's ClientId->UniqueThread
    HANDLE LockSemaphore;
    DWORD Reserved;
} RTL_CRITICAL_SECTION, *PRTL_CRITICAL_SECTION;

typedef RTL_CRITICAL_SECTION CRITICAL_SECTION;

typedef struct _SYSTEMTIME {
    WORD wYear;
    WORD wMonth;
    WORD wDayOfWeek;
    WORD wDay;
    WORD wHour;
    WORD wMinute;
    WORD wSecond;
    WORD wMilliseconds;
} SYSTEMTIME, *PSYSTEMTIME, *LPSYSTEMTIME;

typedef struct _DCB { // dcb  
    unsigned long DCBlength;           // sizeof(DCB) 
    unsigned long BaudRate;            // current baud rate 
    unsigned long fBinary: 1;          // binary mode, no EOF check 
    unsigned long fParity: 1;          // enable parity checking 
    unsigned long fOutxCtsFlow:1;      // CTS output flow control 
    unsigned long fOutxDsrFlow:1;      // DSR output flow control 
    unsigned long fDtrControl:2;       // DTR flow control type 
    unsigned long fDsrSensitivity:1;   // DSR sensitivity 
    unsigned long fTXContinueOnXoff:1; // XOFF continues Tx 
    unsigned long fOutX: 1;            // XON/XOFF out flow control 
    unsigned long fInX: 1;             // XON/XOFF in flow control 
    unsigned long fErrorChar: 1;       // enable error replacement 
    unsigned long fNull: 1;            // enable null stripping 
    unsigned long fRtsControl:2;       // RTS flow control 
    unsigned long fAbortOnError:1;     // abort reads/writes on error 
    unsigned long fDummy2:17;          // reserved 
    unsigned short wReserved;            // not currently used 
    unsigned short XonLim;               // transmit XON threshold 
    unsigned short XoffLim;              // transmit XOFF threshold 
    unsigned char ByteSize;             // number of bits/byte, 4-8 
    unsigned char Parity;               // 0-4=no,odd,even,mark,space 
    unsigned char StopBits;             // 0,1,2 = 1, 1.5, 2 
    char XonChar;              // Tx and Rx XON character 
    char XoffChar;             // Tx and Rx XOFF character 
    char ErrorChar;            // error replacement character 
    char EofChar;              // end of input character 
    char EvtChar;              // received event character 
    unsigned short wReserved1;           // reserved; do not use 
} DCB; 

#define DTR_CONTROL_ENABLE     0x01
#define RTS_CONTROL_ENABLE     0x01
#define RTS_CONTROL_HANDSHAKE  0x02
#define NOPARITY            0
#define ONESTOPBIT          0

typedef struct _COMMTIMEOUTS {   // ctmo  
    unsigned long ReadIntervalTimeout; 
    unsigned long ReadTotalTimeoutMultiplier; 
    unsigned long ReadTotalTimeoutConstant; 
    unsigned long WriteTotalTimeoutMultiplier; 
    unsigned long WriteTotalTimeoutConstant; 
} COMMTIMEOUTS,*LPCOMMTIMEOUTS; 

typedef struct _OVERLAPPED {
    DWORD   Internal;
    DWORD   InternalHigh;
    DWORD   Offset;
    DWORD   OffsetHigh;
    HANDLE  hEvent;
} OVERLAPPED, *LPOVERLAPPED;

extern "C" {

BOOL   APIENTRY Beep(DWORD dwFreq, DWORD dwDuration);
BOOL   APIENTRY CloseHandle(HANDLE handle);
HANDLE APIENTRY CreateEvent(void *sa, BOOL manualreset, BOOL initialstate, const char *name);
HANDLE APIENTRY CreateFile(const char *fn, DWORD access, DWORD sharemode, void *sa, DWORD create, DWORD flags, HANDLE templatefile);
HANDLE APIENTRY CreateFileMapping(HANDLE handle, void *sa, DWORD protect, DWORD sizehigh, DWORD size, const char *name);
HANDLE APIENTRY CreateMutex(HANDLE handle, BOOL own, const char *name);
HANDLE APIENTRY CreateSemaphore(void *sa, LONG initcount, LONG maxcount, const char *name);
HANDLE APIENTRY CreateThread(void *sa, DWORD stacksize, DWORD __stdcall routine(void *), void *param, DWORD flags, DWORD *tid);
void   APIENTRY DeleteCriticalSection(CRITICAL_SECTION *cs);
void   APIENTRY EnterCriticalSection(CRITICAL_SECTION *cs);
BOOL   APIENTRY GetCommState(HANDLE handle, DCB *dcb);
DWORD  APIENTRY GetFileSize(HANDLE handle, DWORD *high);
DWORD  APIENTRY GetLastError();
void   APIENTRY GetLocalTime(SYSTEMTIME *st);
BOOL   APIENTRY GetOverlappedResult(HANDLE handle, OVERLAPPED *ov, DWORD *bytes, BOOL wait);
DWORD  APIENTRY GetTickCount();
void   APIENTRY InitializeCriticalSection(CRITICAL_SECTION *cs);
void   APIENTRY LeaveCriticalSection(CRITICAL_SECTION *cs);
void * APIENTRY MapViewOfFile(HANDLE handle, DWORD access, DWORD offsethigh, DWORD offset, DWORD size);
void   APIENTRY OutputDebugString(const char *str);
BOOL   APIENTRY ReadFile(HANDLE handle, void *buffer, DWORD buffersize, DWORD *bytesread, OVERLAPPED *ov);
BOOL   APIENTRY ReleaseMutex(HANDLE handle);
BOOL   APIENTRY ReleaseSemaphore(HANDLE handle, LONG releasecount, LONG *prevcount);
BOOL   APIENTRY ResetEvent(HANDLE event);
BOOL   APIENTRY SetCommState(HANDLE handle, DCB *dcb);
BOOL   APIENTRY SetCommTimeouts(HANDLE handle, COMMTIMEOUTS *ctmo);
BOOL   APIENTRY SetEvent(HANDLE event);
BOOL   APIENTRY SetThreadPriority(HANDLE thread, int priority);
void   APIENTRY Sleep(DWORD ms);
void * APIENTRY VirtualAlloc(void *address, DWORD size, DWORD alloctype, DWORD protect);
DWORD  APIENTRY WaitForMultipleObjects(DWORD count, const HANDLE *handles, BOOL waitall, DWORD ms);
DWORD  APIENTRY WaitForSingleObject(HANDLE handle, DWORD ms);
BOOL   APIENTRY WriteFile(HANDLE handle, const void *buffer, DWORD buffersize, DWORD *byteswritten, OVERLAPPED *ov);

} // extern "C"

#undef WORD
#undef LONG
