// pilotcpu.dll interface

// changes in this must be mirrored in newcpu.h!
enum {
  cpuInitial,
  cpuRunning,
  cpuStopped,
  cpuBreakpoint,
  cpuBusError,
  cpuException // must be last in enumeration
};

union flagu {
  struct {
    char v;
    char c;
    char n;
    char z;
  };
  DWORD longflags;
};

struct CPU_regs {
  DWORD d[8];
  DWORD a[8], usp;
  WORD sr;
  BYTE t;
  BYTE s;
  BYTE x;
  BYTE stopped;
  int intmask;
  DWORD pc;
  flagu flags;
  DWORD dummy;
};

extern "C" {

int  APIENTRY CPU_init(HANDLE commhandle, DWORD ramsize, const char *romfn);
void APIENTRY CPU_reset();
void APIENTRY CPU_run();
void APIENTRY CPU_stop();
BOOL APIENTRY CPU_wait(DWORD timeout);
void APIENTRY CPU_step();
void APIENTRY CPU_skip(DWORD addr);
int APIENTRY CPU_getstate();
void APIENTRY CPU_getregs(CPU_regs &r);
void APIENTRY CPU_setregs(const CPU_regs &r);
BOOL APIENTRY CPU_getexceptionflag(int exception);
BOOL APIENTRY CPU_setexceptionflag(int exception, BOOL flag);
BOOL APIENTRY CPU_addrcheck(DWORD addr, int size);
BYTE APIENTRY CPU_getbyte(DWORD addr);
WORD APIENTRY CPU_getword(DWORD addr);
DWORD APIENTRY CPU_getlong(DWORD adddr);
void *APIENTRY CPU_getmemptr(DWORD addr);
void APIENTRY CPU_putbyte(DWORD addr, BYTE x);
void APIENTRY CPU_putword(DWORD addr, WORD x);
void APIENTRY CPU_putlong(DWORD adddr, DWORD x);
void APIENTRY CPU_pen(int down, int x, int y);
void APIENTRY CPU_key(int down, int key);
void APIENTRY CPU_hotsync(int down);
void APIENTRY CPU_putkey(BYTE key);
void APIENTRY CPU_setscratchaddr(void *addr);
void APIENTRY CPU_setsounds(BOOL enablesounds);

inline BOOL CPU_running() { return CPU_getstate() == cpuRunning; }

} // extern "C"
