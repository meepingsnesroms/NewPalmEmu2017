 /*
  * Copilot
  *
  * Global include file used by all code originally from UAE.
  *
  * Original UAE code Copyright (c) 1996 Bernd Schmidt
  */

#pragma warning(disable: 4244)

#include <stdio.h>
#include <stdlib.h>
#include <assert.h>
#include <memory.h>
#include <string.h>

#define CPU_LEVEL 0

//#define NO_EXCEPTION_3

/* If char has more then 8 bits, good night. */
typedef unsigned char UBYTE;
typedef signed char BYTE;

typedef unsigned short UWORD;
typedef short WORD;

typedef unsigned long ULONG;
typedef long LONG;

typedef ULONG CPTR;
