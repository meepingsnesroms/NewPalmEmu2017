 /*
  * Copilot
  * 
  * Dragonball chip emulation
  * 
  * Copyright (c) 1996 Greg Hewgill
  */

#include "win.h"

#include "sysdeps.h"

#include <ctype.h>
#include <assert.h>

#include "memory.h"
#include "custom.h"
#include "newcpu.h"

#include "dragonball.h"

int EnableSounds;

extern int sram_protect;

class TByteQueue {
public:
  TByteQueue();
  void Put(UBYTE b);
  UBYTE Get();
  int GetUsed() { return UsedCount; }
  int GetFree() { return FreeCount; }
private:
  enum {QUEUE_SIZE = 8};
  HANDLE Mutex;
  HANDLE Used;
  int UsedCount;
  HANDLE Free;
  int FreeCount;
  UBYTE Buffer[QUEUE_SIZE];
  int Head;
  int Tail;
};

TByteQueue::TByteQueue()
{
  Mutex = CreateMutex(NULL, FALSE, NULL);
  Used = CreateSemaphore(NULL, 0, QUEUE_SIZE, NULL);
  UsedCount = 0;
  Free = CreateSemaphore(NULL, QUEUE_SIZE, QUEUE_SIZE, NULL);
  FreeCount = QUEUE_SIZE;
  Head = 0;
  Tail = 0;
}

void TByteQueue::Put(UBYTE b)
{
  HANDLE a[2];
  a[0] = Free;
  a[1] = Mutex;
  WaitForMultipleObjects(2, a, TRUE, INFINITE);
  Buffer[Head] = b;
  Head = (Head + 1) % QUEUE_SIZE;
  UsedCount++;
  FreeCount--;
  ReleaseSemaphore(Used, 1, NULL);
  ReleaseMutex(Mutex);
}

UBYTE TByteQueue::Get()
{
  HANDLE a[2];
  a[0] = Used;
  a[1] = Mutex;
  WaitForMultipleObjects(2, a, TRUE, INFINITE);
  UBYTE r = Buffer[Tail];
  Tail = (Tail + 1) % QUEUE_SIZE;
  FreeCount++;
  UsedCount--;
  ReleaseSemaphore(Free, 1, NULL);
  ReleaseMutex(Mutex);
  return r;
}

HANDLE CommHandle;
// read stuff
HANDLE OverlappedReadEvent;
TByteQueue ReadBuffer;
// write stuff
HANDLE OverlappedWriteEvent;
OVERLAPPED OverlappedWrite;
BOOL OverlappedWritePending;

TByteQueue KeyBuffer;

// dragonball register definitions

union {
  UBYTE x;
  struct {
    unsigned WDTH8: 1;
    unsigned RSVD : 1;
    unsigned DMAP : 1;
    unsigned SO   : 1;
    unsigned BETEN: 1;
    unsigned PRV  : 1;
    unsigned WPV  : 1;
    unsigned BETO : 1;
  };
} db_SCR;

union {
  UWORD x;
  struct {
    unsigned V     : 1;
    unsigned unused: 3;
    unsigned GMA   : 12;
  };
} db_GRPBASEA, db_GRPBASEC;

union {
  UWORD x;
  struct {
    unsigned unused: 4;
    unsigned GMA   : 12;
  };
} db_GRPMASKA, db_GRPMASKC;

union {
  ULONG x;
  struct {
    unsigned WAIT   : 3;
    unsigned RO     : 1;
    unsigned unused1: 4;
    unsigned AM     : 8;
    unsigned BSW    : 1;
    unsigned unused2: 7;
    unsigned AC     : 8;
  };
} db_CSA[4], db_CSC[4];

union {
  UWORD x;
  struct {
    unsigned unused1  : 3;
    unsigned DISPLL   : 1;
    unsigned CLKEN    : 1;
    unsigned unused2  : 3;
    unsigned SYSCLKSEL: 3;
    unsigned PIXCLKSEL: 3;
    unsigned unused3  : 2;
  };
} db_PLLCR;

union {
  UWORD x;
  struct {
    unsigned PC    : 8;
    unsigned QC    : 4;
    unsigned unused: 2;
    unsigned PROT  : 1;
    unsigned CLK32 : 1;
  };
} db_PLLFSR;

union {
  UBYTE x;
  struct {
    unsigned WIDTH : 5;
    unsigned unused: 1;
    unsigned STOP  : 1;
    unsigned PCEN  : 1;
  };
} db_PCTLR;

union {
  UBYTE x;
  struct {
    unsigned LEVEL : 3;
    unsigned VECTOR: 5;
  };
} db_IVR;

union {
  UWORD x;
  struct {
    unsigned unused: 8;
    unsigned POL6: 1;
    unsigned POL3: 1;
    unsigned POL2: 1;
    unsigned POL1: 1;
    unsigned ET6 : 1;
    unsigned ET3 : 1;
    unsigned ET2 : 1;
    unsigned ET1 : 1;
  };
} db_ICR;

union {
  ULONG x;
  struct {
    unsigned SPIM: 1;
    unsigned TMR2: 1;
    unsigned UART: 1;
    unsigned WDT : 1;
    unsigned RTC : 1;
    unsigned LCDC: 1;
    unsigned KB  : 1;
    unsigned PWM : 1;
    unsigned INT0: 1;
    unsigned INT1: 1;
    unsigned INT2: 1;
    unsigned INT3: 1;
    unsigned INT4: 1;
    unsigned INT5: 1;
    unsigned INT6: 1;
    unsigned INT7: 1;
    unsigned IRQ1: 1;
    unsigned IRQ2: 1;
    unsigned IRQ3: 1;
    unsigned IRQ6: 1;
    unsigned PEN : 1;
    unsigned SPIS: 1;
    unsigned TMR1: 1;
    unsigned IRQ7: 1;
    unsigned unused: 8;
  };
} db_IMR, db_IWR, db_ISR, db_IPR;

union {
  UBYTE x;
  struct {
    unsigned MOCLK  : 1;
    unsigned UDS    : 1;
    unsigned LDS    : 1;
    unsigned unused1: 1;
    unsigned NMI    : 1;
    unsigned DTACK  : 1;
    unsigned WE     : 1;
    unsigned unused2: 1;
  };
} db_PCDIR, db_PCDATA, db_PCSEL;

union {
  UBYTE x;
  struct {
    unsigned B0: 1;
    unsigned B1: 1;
    unsigned B2: 1;
    unsigned B3: 1;
    unsigned B4: 1;
    unsigned B5: 1;
    unsigned B6: 1;
    unsigned B7: 1;
  };
} db_PDDIR, db_PDPUEN, db_PDPOL, db_PDIRQEN, db_PDIRQEDGE;

struct {
  union {
    UBYTE x;
    struct {
      unsigned B0: 1;
      unsigned B1: 1;
      unsigned B2: 1;
      unsigned B3: 1;
      unsigned B4: 1;
      unsigned B5: 1;
      unsigned B6: 1;
      unsigned B7: 1;
    };
  };
  UBYTE edge;
} db_PDDATA;

union {
  UBYTE x;
  struct {
    unsigned unused: 1;
    unsigned CSA1  : 1;
    unsigned CSA2  : 1;
    unsigned CSA3  : 1;
    unsigned CSB0  : 1;
    unsigned CSB1  : 1;
    unsigned CSB2  : 1;
    unsigned CSB3  : 1;
  };
} db_PEDIR, db_PEDATA, db_PEPUEN, db_PESEL;

union {
  UBYTE x;
  struct {
    unsigned A: 8;
  };
} db_PFDIR, db_PFDATA, db_PFPUEN, db_PFSEL;

union {
  UBYTE x;
  struct {
    unsigned UART_TXD: 1;
    unsigned UART_RXD: 1;
    unsigned PWMOUT  : 1;
    unsigned TOUT2   : 1;
    unsigned TIN2    : 1;
    unsigned TOUT1   : 1;
    unsigned TIN1    : 1;
    unsigned RTCOUT  : 1;
  };
} db_PGDIR, db_PGDATA, db_PGPUEN, db_PGSEL;

union {
  UBYTE x;
  struct {
    unsigned SPIM_TXD  : 1;
    unsigned SPIM_RXD  : 1;
    unsigned SPIM_CLKO : 1;
    unsigned SPIS_EN   : 1;
    unsigned SPIS_RXD  : 1;
    unsigned SPIS_CLKI : 1;
    unsigned PCMCIA_CE2: 1;
    unsigned PCMCIA_CE1: 1;
  };
} db_PKDIR, db_PKDATA, db_PKPUEN, db_PKSEL;

union {
  UBYTE x;
  struct {
    unsigned CTS      : 1;
    unsigned RTS      : 1;
    unsigned IRQ6     : 1;
    unsigned IRQ3     : 1;
    unsigned IRQ2     : 1;
    unsigned IRQ1     : 1;
    unsigned PEN_IRQ  : 1;
    unsigned UART_GPIO: 1;
  };
} db_PMDIR, db_PMDATA, db_PMPUEN, db_PMSEL;

union {
  UWORD x;
  struct {
    unsigned CLKSEL : 3;
    unsigned unused1: 1;
    unsigned PWMEN  : 1;
    unsigned POL    : 1;
    unsigned unused2: 1;
    unsigned PIN    : 1;
    unsigned LOAD   : 1;
    unsigned unused3: 5;
    unsigned IRQEN  : 1;
    unsigned PWMIRQ : 1;
  };
} db_PWMC;

union {
  UWORD x;
  struct {
    unsigned PERIOD: 16;
  };
} db_PWMP;

union {
  UWORD x;
  struct {
    unsigned WIDTH: 16;
  };
} db_PWMW;

union {
  UWORD x;
  struct {
    unsigned TEN         : 1;
    unsigned CLKSOURCE   : 3;
    unsigned IRQEN       : 1;
    unsigned OM          : 1;
    unsigned CAPTURE_EDGE: 2;
    unsigned FRR         : 1;
    unsigned unused      : 7;
  };
} db_TCTL1, db_TCTL2;

union {
  UWORD x;
  struct {
    unsigned PRESCALE: 8;
    unsigned unused  : 8;
  };
} db_TPRER1, db_TPRER2;

union {
  UWORD x;
  struct {
    unsigned COMPARE: 16;
  };
} db_TCMP1, db_TCMP2;

union {
  UWORD x;
  struct {
    unsigned COUNT: 16;
  };
} db_TCN1, db_TCN2;

struct {
  union {
    UWORD x;
    struct {
      unsigned COMP  : 1;
      unsigned CAPT  : 1;
      unsigned unused: 14;
    };
  };
  UWORD lastseen;
} db_TSTAT1, db_TSTAT2;

union {
  UWORD x;
  struct {
    unsigned WDEN  : 1;
    unsigned FI    : 1;
    unsigned LOCK  : 1;
    unsigned WDRST : 1;
    unsigned unused: 12;
  };
} db_WCR;

union {
  UWORD x;
  struct {
    unsigned COUNT: 16;
  };
} db_WCN;

union {
  UWORD x;
  struct {
    unsigned DATA: 16;
  };
} db_SPIMDATA;

union {
  UWORD x;
  struct {
    unsigned BITCOUNT: 4;
    unsigned POL     : 1;
    unsigned PHA     : 1;
    unsigned IRQEN   : 1;
    unsigned SPIMIRQ : 1;
    unsigned XCH     : 1;
    unsigned SPMEN   : 1;
    unsigned unused  : 3;
    unsigned DATARATE: 3;
  };
} db_SPIMCONT;

union {
  UWORD x;
  struct {
    unsigned TX_AVAIL_ENABLE  : 1;
    unsigned TX_HALF_ENABLE   : 1;
    unsigned TX_EMPTY_ENABLE  : 1;
    unsigned RX_READY_ENABLE  : 1;
    unsigned RX_HALF_ENABLE   : 1;
    unsigned RX_FULL_ENABLE   : 1;
    unsigned CTS_DELTA_ENABLE : 1;
    unsigned GPIO_DELTA_ENABLE: 1;
    unsigned BITS_8           : 1;
    unsigned STOP_BITS        : 1;
    unsigned ODD_EVEN         : 1;
    unsigned PARITY_ENABLE    : 1;
    unsigned RX_CLK_CONT      : 1;
    unsigned TX_ENABLE        : 1;
    unsigned RX_ENABLE        : 1;
    unsigned UART_ENABLE      : 1;
  };
} db_USTCNT;

union {
  UWORD x;
  struct {
    unsigned PRESCALER : 6;
    unsigned unused    : 2;
    unsigned DIVIDE    : 3;
    unsigned BAUD_SRC  : 1;
    unsigned GPIO_SRC  : 1;
    unsigned GPIO_DIR  : 1;
    unsigned GPIO      : 1;
    unsigned GPIO_DELTA: 1;
  };
} db_UBAUD;

union {
  UWORD x;
  struct {
    unsigned DATA        : 8;
    unsigned PARITY_ERROR: 1;
    unsigned BREAK       : 1;
    unsigned FRAME_ERROR : 1;
    unsigned OVRUN       : 1;
    unsigned unused      : 1;
    unsigned DATA_READY  : 1;
    unsigned FIFO_HALF   : 1;
    unsigned FIFO_FULL   : 1;
  };
} db_URX;

union {
  UWORD x;
  struct {
    unsigned DATA      : 8;
    unsigned CTS_DELTA : 1;
    unsigned CTS_STATUS: 1;
    unsigned unused    : 1;
    unsigned IGNORE_CTS: 1;
    unsigned SEND_BREAK: 1;
    unsigned TX_AVAIL  : 1;
    unsigned FIFO_HALF : 1;
    unsigned FIFO_EMPTY: 1;
  };
} db_UTX;

union {
  UWORD x;
  struct {
    unsigned unused1    : 4;
    unsigned IRDA_LOOP  : 1;
    unsigned IRDA_ENABLE: 1;
    unsigned RTS        : 1;
    unsigned RTS_CONT   : 1;
    unsigned unused2    : 4;
    unsigned LOOP       : 1;
    unsigned FORCE_PERR : 1;
    unsigned CLK_SRC    : 1;
    unsigned unused3    : 1;
  };
} db_UMISC;

union {
  ULONG x;
  struct {
    unsigned SSA: 32;
  };
} db_LSSA;

union {
  UBYTE x;
  struct {
    unsigned VPW: 8;
  };
} db_LVPW;

union {
  UWORD x;
  struct {
    unsigned XMAX  : 10;
    unsigned unused: 6;
  };
} db_LXMAX;

union {
  UWORD x;
  struct {
    unsigned YMAX  : 10;
    unsigned unused: 6;
  };
} db_LYMAX;

union {
  UWORD x;
  struct {
    unsigned CXP   : 10;
    unsigned unused: 4;
    unsigned CC    : 2;
  };
} db_LCXP;

union {
  UWORD x;
  struct {
    unsigned CYP   : 10;
    unsigned unused: 6;
  };
} db_LCYP;

union {
  UWORD x;
  struct {
    unsigned CH     : 5;
    unsigned unused1: 3;
    unsigned CW     : 5;
    unsigned unused2: 3;
  };
} db_LCWCH;

union {
  UWORD x;
  struct {
    unsigned BD  : 7;
    unsigned BKEN: 1;
  };
} db_LBLKC;

union {
  UBYTE x;
  struct {
    unsigned GS    : 1;
    unsigned PBSIZ : 2;
    unsigned unused: 5;
  };
} db_LPICF;

union {
  UBYTE x;
  struct {
    unsigned PCD   : 6;
    unsigned unused: 2;
  };
} db_LPXCD;

union {
  UBYTE x;
  struct {
    unsigned PCDS  : 1;
    unsigned DWIDTH: 1;
    unsigned unused: 2;
    unsigned WS0   : 1;
    unsigned WS1   : 1;
    unsigned DMA16 : 1;
    unsigned LCDCON: 1;
  };
} db_LCKCON;

union {
  UBYTE x;
  struct {
    unsigned LBAR: 8;
  };
} db_LLBAR;

union {
  UBYTE x;
  struct {
    unsigned OTC: 8;
  };
} db_LOTCR;

union {
  UBYTE x;
  struct {
    unsigned YMOD: 4;
    unsigned XMOD: 4;
  };
} db_LFRCM;

union {
  UWORD x;
  struct {
    unsigned G2: 4;
    unsigned G3: 4;
    unsigned G0: 4;
    unsigned G1: 4;
  };
} db_LGPMR;

union {
  ULONG x;
  struct {
    unsigned SECONDS: 6;
    unsigned unused1: 10;
    unsigned MINUTES: 6;
    unsigned unused2: 2;
    unsigned HOURS  : 5;
    unsigned unused3: 3;
  };
} db_RTCHMS, db_RTCALARM;

union {
  UBYTE x;
  struct {
    unsigned unused1: 5;
    unsigned REF384 : 1;
    unsigned unused2: 1;
    unsigned ENABLE : 1;
  };
} db_RTCCTL;

union {
  UBYTE x;
  struct {
    unsigned SW    : 1;
    unsigned MININT: 1;
    unsigned ALARM : 1;
    unsigned HOUR24: 1;
    unsigned HZ1   : 1;
    unsigned unused: 3;
  };
} db_RTCISR, db_RTCIENR;

int pendown, penx, peny;

 /*
  * Events
  */

unsigned long int cycles, specialflags;

#ifdef _DEBUG
//#define LOGGING
#endif

#ifdef LOGGING
#include <stdio.h>
FILE *logfile = fopen("hotsync.log", "wt");
BOOL lastoutput = FALSE;
char s[80];
int col = 0;

void LOG(BOOL output, UBYTE b)
{
  if (output != lastoutput) {
    if (col > 0) {
      fprintf(logfile, "%s", s);
    }
    if (output) {
      fprintf(logfile, "\n\nPilot -> Desktop\n\n");
    } else {
      fprintf(logfile, "\n\nDesktop -> Pilot\n\n");
    }
    fflush(logfile);
    lastoutput = output;
    col = 0;
  }
  sprintf(&s[col], "%02x ", b);
  col += 3;
  if (col > 75) {
    fprintf(logfile, "%s\n", s);
    col = 0;
  }
}
#endif

DWORD __stdcall CommRead(void *)
{
  while (1) {
    OVERLAPPED ov = {0};
    ov.hEvent = OverlappedReadEvent;
    BYTE buf[16];
    DWORD n;
    if ((ReadFile(CommHandle, buf, sizeof(buf), &n, &ov) || GetOverlappedResult(CommHandle, &ov, &n, TRUE)) && n > 0) {
      for (DWORD i = 0; i < n; i++) {
        ReadBuffer.Put(buf[i]);
      }
    }
  }
  return 0;
}

void CommWrite(UBYTE b)
{
  if (CommHandle == NULL) {
    return;
  }
#ifdef LOGGING
  LOG(TRUE, b);
#endif
  DWORD n;
  if (OverlappedWritePending) {
    GetOverlappedResult(CommHandle, &OverlappedWrite, &n, TRUE);
    OverlappedWritePending = FALSE;
  }
  static UBYTE bytetosend;
  bytetosend = b;
  memset(&OverlappedWrite, 0, sizeof(OverlappedWrite));
  OverlappedWrite.hEvent = OverlappedWriteEvent;
  if (!WriteFile(CommHandle, &bytetosend, 1, &n, &OverlappedWrite) && GetLastError() == ERROR_IO_PENDING) {
    OverlappedWritePending = TRUE;
  }
}

/*
 * helper functions
 */

void updateisr()
{
  db_ISR.x = db_IPR.x & ~db_IMR.x;
  if (db_ISR.x) {
    specialflags |= SPCFLAG_INT;
  }
}

int intbase()
{
  return db_IVR.VECTOR << 3;
}

int intlev()
{
  if (db_ISR.IRQ7) return 7;
  if (db_ISR.SPIS) return 6;
  if (db_ISR.TMR1) return 6;
  if (db_ISR.IRQ6) return 6;
  if (db_ISR.PEN ) return 5;
  if (db_ISR.SPIM) return 4;
  if (db_ISR.TMR2) return 4;
  if (db_ISR.UART) return 4;
  if (db_ISR.WDT ) return 4;
  if (db_ISR.RTC ) return 4;
  if (db_ISR.KB  ) return 4;
  if (db_ISR.PWM ) return 4;
  if (db_ISR.INT0) return 4;
  if (db_ISR.INT1) return 4;
  if (db_ISR.INT2) return 4;
  if (db_ISR.INT3) return 4;
  if (db_ISR.INT4) return 4;
  if (db_ISR.INT5) return 4;
  if (db_ISR.INT6) return 4;
  if (db_ISR.INT7) return 4;
  if (db_ISR.IRQ3) return 3;
  if (db_ISR.IRQ2) return 2;
  if (db_ISR.IRQ1) return 1;
  return -1;
}

void pen(int down, int x, int y)
{
  if (!pendown && down) {
    db_IPR.PEN = 1;
    updateisr();
  } else if (pendown && !down) {
    db_IPR.PEN = 0;
    updateisr();
  }
  pendown = down;
  penx = x;
  peny = y;
}

void dokey(int down, int key)
{
  UBYTE d = db_PDDATA.x;
  if (down) {
    db_PDDATA.x |= (1 << key);
  } else {
    db_PDDATA.x &= ~(1 << key);
  }
  db_PDDATA.edge |= db_PDDATA.x & ~d;
  db_IPR.x = (db_IPR.x & 0xFFFF00FF) | (((db_PDDATA.edge & db_PDIRQEDGE.x | db_PDDATA.x & ~db_PDIRQEDGE.x) & db_PDIRQEN.x) << 8);
  updateisr();
}

void hotsync(int down)
{
  if (down) {
    db_IPR.IRQ1 = 1;
  } else {
    db_IPR.IRQ1 = 0;
  }
  updateisr();
}

void putkey(UBYTE key)
{
  if (KeyBuffer.GetFree() > 0) {
    KeyBuffer.Put(key);
  }
}

void customreset(void)
{
  cycles = 0; 
  specialflags = 0;
    
  db_SCR.x      = 0x0C;
  db_GRPBASEA.x = 0x0000;
  db_GRPBASEC.x = 0x0000;
  db_GRPMASKA.x = 0x0000;
  db_GRPMASKC.x = 0x0000;
  db_CSA[0].x   = 0x00010006;
  db_CSA[1].x   = 0x00010006;
  db_CSA[2].x   = 0x00010006;
  db_CSA[3].x   = 0x00010006;
  db_CSC[0].x   = 0x00010006;
  db_CSC[1].x   = 0x00010006;
  db_CSC[2].x   = 0x00010006;
  db_CSC[3].x   = 0x00010006;
  db_PLLCR.x    = 0x2400;
  db_PLLFSR.x   = 0x0123;
  db_PCTLR.x    = 0x1F;
  db_IVR.x      = 0x00;
  db_ICR.x      = 0x0000;
  db_IMR.x      = 0x00FFFFFF;
  db_IWR.x      = 0x00FFFFFF;
  db_ISR.x      = 0x00000000;
  db_IPR.x      = 0x00000000;
  db_PCDIR.x    = 0x00;
  db_PCDATA.x   = 0x00;
  db_PCSEL.x    = 0x00;
  db_PDDIR.x    = 0x00;
  db_PDDATA.x   = 0x00;
  db_PDDATA.edge= 0x00;
  db_PDPUEN.x   = 0xFF;
  db_PDPOL.x    = 0x00;
  db_PDIRQEN.x  = 0x00;
  db_PDIRQEDGE.x= 0x00;
  db_PEDIR.x    = 0x00;
  db_PEDATA.x   = 0x00;
  db_PEPUEN.x   = 0x80;
  db_PESEL.x    = 0x80;
  db_PFDIR.x    = 0x00;
  db_PFDATA.x   = 0x00;
  db_PFPUEN.x   = 0xFF;
  db_PFSEL.x    = 0xFF;
  db_PGDIR.x    = 0x00;
  db_PGDATA.x   = 0x00;
  db_PGPUEN.x   = 0xFF;
  db_PGSEL.x    = 0xFF;
  db_PKDIR.x    = 0x00;
  db_PKDATA.x   = 0x00;
  db_PKPUEN.x   = 0xFF;
  db_PKSEL.x    = 0xFF;
  db_PMDIR.x    = 0x00;
  db_PMDATA.x   = 0x00;
  db_PMPUEN.x   = 0xFF;
  db_PMSEL.x    = 0xFF;
  db_PWMC.x     = 0x0000;
  db_PWMP.x     = 0x0000;
  db_PWMW.x     = 0x0000;
  db_TCTL1.x    = 0x0000;
  db_TPRER1.x   = 0x0000;
  db_TCMP1.x    = 0xFFFF;
  db_TCN1.x     = 0x0000;
  db_TSTAT1.x   = 0x0000;
  db_TSTAT1.lastseen = 0x0000;
  db_TCTL2.x    = 0x0000;
  db_TPRER2.x   = 0x0000;
  db_TCMP2.x    = 0xFFFF;
  db_TCN2.x     = 0x0000;
  db_TSTAT2.x   = 0x0000;
  db_TSTAT2.lastseen = 0x0000;
  db_WCR.x      = 0x0000;
  db_WCN.x      = 0x0000;
  db_SPIMDATA.x = 0x0000;
  db_SPIMCONT.x = 0x0000;
  db_USTCNT.x   = 0x0000;
  db_UBAUD.x    = 0x003F;
  db_URX.x      = 0x0000;
  db_UTX.x      = 0x0000;
  db_UMISC.x    = 0x0000;
  db_LSSA.x     = 0x00000000;
  db_LVPW.x     = 0xFF;
  db_LXMAX.x    = 0x03FF;
  db_LYMAX.x    = 0x01FF;
  db_LCXP.x     = 0x0000;
  db_LCYP.x     = 0x0000;
  db_LCWCH.x    = 0x0101;
  db_LBLKC.x    = 0x7F;
  db_LPICF.x    = 0x00;
  db_LPXCD.x    = 0x00;
  db_LCKCON.x   = 0x40;
  db_LLBAR.x    = 0x3E;
  db_LOTCR.x    = 0x3F;
  db_LFRCM.x    = 0xB9;
  db_LGPMR.x    = 0x1073;
  db_RTCHMS.x   = 0x00000000;
  db_RTCALARM.x = 0x00000000;
  db_RTCCTL.x   = 0x00;
  db_RTCISR.x   = 0x00;
  db_RTCIENR.x  = 0x00;
}

void dumpcustom(void)
{
}

void custom_init(HANDLE commhandle)
{
    CommHandle = commhandle;
    if (CommHandle) {
      DCB dcb;
      GetCommState(CommHandle, &dcb);
      dcb.BaudRate = 9600;
      dcb.fBinary = 1;
      dcb.fParity = 0;
      dcb.fOutxCtsFlow = TRUE;
      dcb.fOutxDsrFlow = 0;
      dcb.fDtrControl = DTR_CONTROL_ENABLE;
      dcb.fDsrSensitivity = 0;
      dcb.fOutX = 0;
      dcb.fInX = 0;
      dcb.fErrorChar = 0;
      dcb.fNull = 0;
      dcb.fRtsControl = RTS_CONTROL_HANDSHAKE;
      dcb.fAbortOnError = 0;
      dcb.ByteSize = 8;
      dcb.Parity = NOPARITY;
      dcb.StopBits = ONESTOPBIT;
      SetCommState(CommHandle, &dcb);
      COMMTIMEOUTS ctmo;
      ctmo.ReadIntervalTimeout = 0xFFFFFFFF;
      ctmo.ReadTotalTimeoutMultiplier = 0xFFFFFFFF;
      ctmo.ReadTotalTimeoutConstant = 1000;
      ctmo.WriteTotalTimeoutMultiplier = 0;
      ctmo.WriteTotalTimeoutConstant = 0;
      SetCommTimeouts(CommHandle, &ctmo);
      OverlappedReadEvent = CreateEvent(NULL, TRUE, FALSE, NULL);
      OverlappedWriteEvent = CreateEvent(NULL, TRUE, FALSE, NULL);
      OverlappedWritePending = FALSE;
      DWORD tid;
      HANDLE commread = CreateThread(NULL, 0, CommRead, NULL, 0, &tid);
      SetThreadPriority(commread, THREAD_PRIORITY_HIGHEST);
      CloseHandle(commread);
    }
    customreset();
}

void do_cycles(int longtime)
{
  if (db_TCTL2.TEN) {
    db_TCN2.COUNT++;
    if (db_TCN2.COUNT > db_TCMP2.COMPARE || longtime) {
      db_TSTAT2.COMP = 1;
      if (db_TCTL2.FRR == 0) {
        db_TCN2.COUNT = 0;
      }
      if (db_TCTL2.IRQEN) {
        db_IPR.TMR2 = 1;
        updateisr();
      }
    }
  }
  if (db_USTCNT.UART_ENABLE && !db_URX.DATA_READY && ReadBuffer.GetUsed() > 0) {
    db_URX.DATA = ReadBuffer.Get();
    db_URX.DATA_READY = 1;
    if (db_USTCNT.RX_READY_ENABLE) {
      db_IPR.UART = 1;
      updateisr();
    }
#ifdef LOGGING
    LOG(FALSE, db_URX.DATA);
#endif
  }
}

struct EventType {
  UWORD eType;
  UWORD penDown;
  UWORD screenX;
  UWORD screenY;
  UWORD data[8];
};

struct SndCommandType {
  UWORD cmd;
  UWORD param1hi;
  UWORD param1lo;
  UWORD param2;
  UWORD param3;
};

const keyDownEvent = 4;

const sysTrapEvtGetEvent  = 41245;
const sysTrapSndDoCmd     = 41523;

int do_api(int api)
{
  switch (api) {
    case sysTrapEvtGetEvent:
      if (KeyBuffer.GetUsed() > 0) {
        EventType *ev = (EventType *)get_real_address(get_long(regs.a[7]));
        ev->eType = keyDownEvent;
        ev->data[0] = KeyBuffer.Get();
        ev->data[1] = 0;
        ev->data[2] = 0;
        return 1;
      }
      break;
    case sysTrapSndDoCmd:
      SndCommandType *sc = (SndCommandType *)get_real_address(get_long(regs.a[7]+4));
      if ((sc->cmd >> 8) == 1) {
        if (EnableSounds) {
          Beep(sc->param1lo, sc->param2);
        }
        return 1;
      }
      break;
  }
  return 0;
}

/* Custom chip memory bank */

static ULONG custom_lget(CPTR);
static UWORD custom_wget(CPTR);
static UBYTE custom_bget(CPTR);
static void  custom_lput(CPTR, ULONG);
static void  custom_wput(CPTR, UWORD);
static void  custom_bput(CPTR, UBYTE);

addrbank custom_bank = {
    custom_lget, custom_wget, custom_bget,
    custom_lput, custom_wput, custom_bput,
    default_xlate, default_check
};

UWORD custom_wget(CPTR addr)
{
  switch (addr & 0xFFFF) {
    case GRPBASEA:
      return db_GRPBASEA.x;
    case GRPBASEC:
      return db_GRPBASEC.x;
    case GRPMASKA:
      return db_GRPMASKA.x;
    case GRPMASKC:
      return db_GRPMASKC.x;
    case PLLCR:
      return db_PLLCR.x;
    case PLLFSR:
      db_PLLFSR.CLK32 ^= 1;
      return db_PLLFSR.x;
    case ICR:
      return db_ICR.x;
    case IMR:
      return db_IMR.x >> 16;
    case IMR+2:
      return db_IMR.x;
    case IWR:
      return db_IWR.x >> 16;
    case IWR+2:
      return db_IWR.x;
    case ISR:
      return db_ISR.x >> 16;
    case ISR+2:
      return db_ISR.x;
    case IPR:
      //{
      //  static DWORD last = 0;
      //  DWORD now = GetTickCount();
      //  char buf[80];
      //  sprintf(buf, "%d (%d): IPR = %08x\n", now, now-last, db_IPR.x);
      //  last = now;
      //  OutputDebugString(buf);
      //  Beep(1000, 10);
      //}
      return db_IPR.x >> 16;
    case PWMC:
      return db_PWMC.x;
    case PWMP:
      return db_PWMP.x;
    case PWMW:
      return db_PWMW.x;
    case TCTL1:
      return db_TCTL1.x;
    case TPRER1:
      return db_TPRER1.x;
    case TCMP1:
      return db_TCMP1.x;
    case TSTAT1:
      db_TCN1.COUNT += 16;
      if (db_TCN1.COUNT - db_TCMP1.COMPARE < 16) {
        db_TSTAT1.COMP = 1;
        if (db_TCTL1.FRR == 0) {
          db_TCN1.COUNT = 0;
        }
      }
      db_TSTAT1.lastseen |= db_TSTAT1.x;
      return db_TSTAT1.x;
    case TCTL2:
      return db_TCTL2.x;
    case TPRER2:
      return db_TPRER2.x;
    case TCMP2:
      return db_TCMP2.x;
    case TSTAT2:
      db_TSTAT2.lastseen |= db_TSTAT2.x;
      return db_TSTAT2.x;
    case WCR:
      return db_WCR.x;
    case WCN:
      return db_WCN.x;
    case SPIMDATA:
      return db_SPIMDATA.x;
    case SPIMCONT:
      return db_SPIMCONT.x;
    case USTCNT:
      return db_USTCNT.x;
    case UBAUD:
      return db_UBAUD.x;
    case URX:
      db_URX.DATA_READY = 0;
      db_IPR.UART = 0;
      updateisr();
      return db_URX.x;
    case UTX:
      db_UTX.FIFO_EMPTY = 1;
      db_UTX.FIFO_HALF = 1;
      db_UTX.TX_AVAIL = 1;
      db_UTX.CTS_STATUS = 1;
      return db_UTX.x;
    case UMISC:
      return db_UMISC.x;
    case LXMAX:
      return db_LXMAX.x;
    case LYMAX:
      return db_LYMAX.x;
    case LCXP:
      return db_LCXP.x;
    case LCYP:
      return db_LCYP.x;
    case LCWCH:
      return db_LCWCH.x;
    case LGPMR:
      return db_LGPMR.x;
    case RTCCTL:
      return db_RTCCTL.x;
    case RTCISR:
      return db_RTCISR.x;
    case RTCIENR:
      return db_RTCIENR.x;
    default:
      __asm int 3;
      return 0xffff;
  }
}

UBYTE custom_bget(CPTR addr)
{
  switch (addr & 0xFFFF) {
    case SCR:
      return db_SCR.x;
    case PCTLR:
      return db_PCTLR.x;
    case IVR:
      return db_IVR.x;
    case PCDIR:
      return db_PCDIR.x;
    case PCDATA:
      db_PCDATA.NMI = 1; // who knows, this makes the power on key work
      return db_PCDATA.x;
    case PCSEL:
      return db_PCSEL.x;
    case PDDIR:
      return db_PDDIR.x;
    case PDDATA:
      return db_PDDATA.x;
    case PDPUEN:
      return db_PDPUEN.x;
    case PDPOL:
      return db_PDPOL.x;
    case PDIRQEN:
      return db_PDIRQEN.x;
    case PDIRQEDGE:
      return db_PDIRQEDGE.x;
    case PEDIR:
      return db_PEDIR.x;
    case PEDATA:
      return db_PEDATA.x;
    case PEPUEN:
      return db_PEPUEN.x;
    case PESEL:
      return db_PESEL.x;
    case PFDIR:
      return db_PFDIR.x;
    case PFDATA:
      return db_PFDATA.x;
    case PFPUEN:
      return db_PFPUEN.x;
    case PFSEL:
      return db_PFSEL.x;
    case PGDIR:
      return db_PGDIR.x;
    case PGDATA:
      return db_PGDATA.x;
    case PGPUEN:
      return db_PGPUEN.x;
    case PGSEL:
      return db_PGSEL.x;
    case PKDIR:
      return db_PKDIR.x;
    case PKDATA:
      return db_PKDATA.x;
    case PKPUEN:
      return db_PKPUEN.x;
    case PKSEL:
      return db_PKSEL.x;
    case PMDIR:
      return db_PMDIR.x;
    case PMDATA:
      return db_PMDATA.x;
    case PMPUEN:
      return db_PMPUEN.x;
    case PMSEL:
      return db_PMSEL.x;
    case URX: 
      return db_URX.x >> 8;
    case LVPW:
      return db_LVPW.x;
    case LBLKC:
      return db_LBLKC.x;
    case LPICF:
      return db_LPICF.x;
    case LPXCD:
      return db_LPXCD.x;
    case LCKCON:
      return db_LCKCON.x;
    case LLBAR:
      return db_LLBAR.x;
    case LOTCR:
      return db_LOTCR.x;
    case LFRCM:
      return db_LFRCM.x;
    default:
      __asm int 3;
      return custom_wget(addr & 0xfffe) >> (addr & 1 ? 0 : 8);
  }
}

ULONG custom_lget(CPTR addr)
{
  switch (addr & 0xFFFF) {
    case CSAx:
      return db_CSA[0].x;
    case CSAx+4:
      return db_CSA[1].x;
    case CSAx+8:
      return db_CSA[2].x;
    case CSAx+12:
      return db_CSA[3].x;
    case CSCx:
      return db_CSC[0].x;
    case CSCx+4:
      return db_CSC[1].x;
    case CSCx+8:
      return db_CSC[2].x;
    case CSCx+12:
      return db_CSC[3].x;
    case IMR:
      return db_IMR.x;
    case IWR:
      return db_IWR.x;
    case ISR:
      return db_ISR.x;
    case IPR:
      return db_IPR.x;
    case LSSA:
      return db_LSSA.x;
    case RTCHMS: {
      SYSTEMTIME st;
      GetLocalTime(&st);
      db_RTCHMS.HOURS = st.wHour;
      db_RTCHMS.MINUTES = st.wMinute;
      db_RTCHMS.SECONDS = st.wSecond;
      return db_RTCHMS.x;
    }
    case RTCALARM:
      return db_RTCALARM.x;
    default:
      __asm int 3;
      return ((ULONG)custom_wget(addr & 0xfffe) << 16) | custom_wget((addr+2) & 0xfffe);
  }
}

void custom_wput(CPTR addr, UWORD value)
{
  switch (addr & 0xFFFF) {
    case GRPBASEA:
      db_GRPBASEA.x = value;
      break;
    case GRPBASEC:
      db_GRPBASEC.x = value;
      break;
    case GRPMASKA:
      db_GRPMASKA.x = value;
      break;
    case GRPMASKC:
      db_GRPMASKC.x = value;
      break;
    case PLLCR:
      db_PLLCR.x = value;
      break;
    case PLLFSR:
      db_PLLFSR.x = value;
      break;
    case ICR:
      db_ICR.x = value;
      break;
    case IMR:
      db_IMR.x &= 0x0000FFFF;
      db_IMR.x |= value << 16;
      updateisr();
      break;
    case IMR+2:
      db_IMR.x &= 0xFFFF0000;
      db_IMR.x |= value;
      updateisr();
      break;
    case IWR:
      db_IWR.x &= 0x0000FFFF;
      db_IWR.x |= value << 16;
      break;
    case IWR+2:
      db_IWR.x &= 0xFFFF0000;
      db_IWR.x |= value;
      break;
    case ISR:
      if (db_ICR.ET1 && (value & 0x0001)) {
        db_IPR.IRQ1 = 0;
        updateisr();
      }
      if (db_ICR.ET2 && (value & 0x0002)) {
        db_IPR.IRQ2 = 0;
        updateisr();
      }
      if (db_ICR.ET3 && (value & 0x0004)) {
        db_IPR.IRQ3 = 0;
        updateisr();
      }
      if (db_ICR.ET6 && (value & 0x0008)) {
        db_IPR.IRQ6 = 0;
        updateisr();
      }
      if (value & 0x0080) {
        db_IPR.IRQ7 = 0;
        updateisr();
      }
      break;
    case ISR+2:
      // do nothing
      break;
    case PWMC:
      db_PWMC.x = value;
      break;
    case PWMP:
      db_PWMP.x = value;
      break;
    case PWMW:
      db_PWMW.x = value;
      break;
    case TCTL1:
      db_TCTL1.x = value;
      break;
    case TPRER1:
      db_TPRER1.x = value;
      break;
    case TCMP1:
      db_TCMP1.x = value;
      break;
    case TSTAT1:
      db_TSTAT1.x = db_TSTAT1.x & (value | ~db_TSTAT1.lastseen);
      db_TSTAT1.lastseen = 0;
      if (db_TSTAT1.COMP == 0) {
        db_IPR.TMR1 = 0;
        updateisr();
      }
      break;
    case TCTL2:
      db_TCTL2.x = value;
      break;
    case TPRER2:
      db_TPRER2.x = value;
      break;
    case TCMP2:
      db_TCMP2.x = value;
      break;
    case TSTAT2:
      db_TSTAT2.x = db_TSTAT2.x & (value | ~db_TSTAT2.lastseen);
      db_TSTAT2.lastseen = 0;
      if (db_TSTAT2.COMP == 0) {
        db_IPR.TMR2 = 0;
        updateisr();
      }
      break;
    case WCR:
      db_WCR.x = value;
      break;
    case WCN:
      db_WCN.x = 0;
      break;
    case SPIMDATA:
      db_SPIMDATA.x = value;
      break;
    case SPIMCONT:
      db_SPIMCONT.x = value;
      if (db_SPIMCONT.XCH && db_SPIMCONT.IRQEN) {
        db_SPIMCONT.SPIMIRQ = 1;
        db_SPIMCONT.XCH = 0;
        switch (db_PFDATA.x & 0x0F) {
          case 0x6: db_SPIMDATA.x = (0xff-penx)*2; break;
          case 0x9: db_SPIMDATA.x = (0xff-peny)*2; break;
        }
      }
      break;
    case USTCNT:
      db_USTCNT.x = value;
      break;
    case UBAUD: {
      db_UBAUD.x = value;
      if (CommHandle) {
        DCB dcb;
        GetCommState(CommHandle, &dcb);
        dcb.BaudRate = 1036800 / (db_UBAUD.DIVIDE+1) / (65-db_UBAUD.PRESCALER);
        SetCommState(CommHandle, &dcb);
      }
      break;
    }
    case URX:
      // ignore db_URX.x = value;
      break;
    case UTX:
      db_UTX.x = value;
      if (db_UMISC.LOOP) {
        db_URX.DATA = db_UTX.DATA;
        db_URX.DATA_READY = 1;
        if (db_USTCNT.RX_READY_ENABLE) {
          db_IPR.UART = 1;
          updateisr();
        }
      } else {
        CommWrite(db_UTX.DATA);
      }
      break;
    case UMISC:
      db_UMISC.x = value;
      break;
    case LXMAX:
      db_LXMAX.x = value;
      break;
    case LYMAX:
      db_LYMAX.x = value;
      break;
    case LCXP:
      db_LCXP.x = value;
      break;
    case LCYP:
      db_LCYP.x = value;
      break;
    case LCWCH:
      db_LCWCH.x = value;
      break;
    case LGPMR:
      db_LGPMR.x = value;
      break;
    case RTCCTL:
      db_RTCCTL.x = (UBYTE)value;
      break;
    case RTCISR:
      db_RTCISR.x &= ~(UBYTE)value;
      break;
    case RTCIENR:
      db_RTCIENR.x = (UBYTE)value;
      break;
    default:
      __asm int 3;
      Beep(1000, 100);
      break;
  }
}

void custom_bput(CPTR addr, UBYTE value)
{
  switch (addr & 0xFFFF) {
    case SCR:
      db_SCR.x = value & ~(value & 0xE0);
      break;
    case PCTLR:
      db_PCTLR.x = value;
      break;
    case IVR:
      db_IVR.x = value;
      break;
    case PCDIR:
      db_PCDIR.x = value;
      break;
    case PCDATA:
      db_PCDATA.x = value;
      break;
    case PCSEL:
      db_PCSEL.x = value;
      break;
    case PDDIR:
      db_PDDIR.x = value;
      break;
    case PDDATA:
      db_PDDATA.edge &= ~value;
      db_IPR.x = (db_IPR.x & 0xFFFF00FF) | (((db_PDDATA.edge & db_PDIRQEDGE.x | db_PDDATA.x & ~db_PDIRQEDGE.x) & db_PDIRQEN.x) << 8);
      updateisr();
      break;
    case PDPUEN:
      db_PDPUEN.x = value;
      break;
    case PDPOL:
      db_PDPOL.x = value;
      break;
    case PDIRQEN:
      db_PDIRQEN.x = value;
      db_IPR.x = (db_IPR.x & 0xFFFF00FF) | (((db_PDDATA.edge & db_PDIRQEDGE.x | db_PDDATA.x & ~db_PDIRQEDGE.x) & db_PDIRQEN.x) << 8);
      updateisr();
      break;
    case PDIRQEDGE:
      db_PDIRQEDGE.x = value;
      break;
    case PEDIR:
      db_PEDIR.x = value;
      break;
    case PEDATA:
      db_PEDATA.x = value;
      break;
    case PEPUEN:
      db_PEPUEN.x = value;
      break;
    case PESEL:
      db_PESEL.x = value;
      break;
    case PFDIR:
      db_PFDIR.x = value;
      break;
    case PFDATA:
      db_PFDATA.x = value;
      break;
    case PFPUEN:
      db_PFPUEN.x = value;
      break;
    case PFSEL:
      db_PFSEL.x = value;
      break;
    case PGDIR:
      db_PGDIR.x = value;
      break;
    case PGDATA:
      db_PGDATA.x = value;
      break;
    case PGPUEN:
      db_PGPUEN.x = value;
      break;
    case PGSEL:
      db_PGSEL.x = value;
      break;
    case PKDIR:
      db_PKDIR.x = value;
      break;
    case PKDATA:
      db_PKDATA.x = value;
      break;
    case PKPUEN:
      db_PKPUEN.x = value;
      break;
    case PKSEL:
      db_PKSEL.x = value;
      break;
    case PMDIR:
      db_PMDIR.x = value;
      break;
    case PMDATA:
      db_PMDATA.x = value;
      break;
    case PMPUEN:
      db_PMPUEN.x = value;
      break;
    case PMSEL:
      db_PMSEL.x = value;
      break;
    case UTX+1:
      db_UTX.DATA = value;
      if (db_UMISC.LOOP) {
        db_URX.DATA = db_UTX.DATA;
        db_URX.DATA_READY = 1;
        if (db_USTCNT.RX_READY_ENABLE) {
          db_IPR.UART = 1;
          updateisr();
        }
      } else {
        CommWrite(db_UTX.DATA);
      }
      break;
    case LVPW:
      db_LVPW.x = value;
      break;
    case LBLKC:
      db_LBLKC.x = value;
      break;
    case LPICF:
      db_LPICF.x = value;
      break;
    case LPXCD:
      db_LPXCD.x = value;
      break;
    case LCKCON:
      db_LCKCON.x = value;
      break;
    case LLBAR:
      db_LLBAR.x = value;
      break;
    case LOTCR:
      db_LOTCR.x = value;
      break;
    case LFRCM:
      db_LFRCM.x = value;
      break;
    case RTCCTL:
      db_RTCCTL.x = value;
      break;
    case RTCISR:
      db_RTCISR.x &= ~value;
      break;
    case RTCIENR:
      db_RTCIENR.x = value;
      break;
    default:
      __asm int 3;
      Beep(1000, 100);
      break;
  }
}

void custom_lput(CPTR addr, ULONG value)
{
  switch (addr & 0xFFFF) {
    case CSAx:
      db_CSA[0].x = value;
      break;
    case CSAx+4:
      db_CSA[1].x = value;
      sram_protect = (value & 0x0008) != 0;
      break;
    case CSAx+8:
      db_CSA[2].x = value;
      break;
    case CSAx+12:
      db_CSA[3].x = value;
      break;
    case CSCx:
      db_CSC[0].x = value;
      break;
    case CSCx+4:
      db_CSC[1].x = value;
      break;
    case CSCx+8:
      db_CSC[2].x = value;
      break;
    case CSCx+12:
      db_CSC[3].x = value;
      break;
    case IMR:
      db_IMR.x = value;
      updateisr();
      break;
    case IWR:
      db_IWR.x = value;
      break;
    case ISR:
      if (db_ICR.ET1 && (value & 0x00010000)) {
        db_IPR.IRQ1 = 0;
        updateisr();
      }
      if (db_ICR.ET2 && (value & 0x00020000)) {
        db_IPR.IRQ2 = 0;
        updateisr();
      }
      if (db_ICR.ET3 && (value & 0x00040000)) {
        db_IPR.IRQ3 = 0;
        updateisr();
      }
      if (db_ICR.ET6 && (value & 0x00080000)) {
        db_IPR.IRQ6 = 0;
        updateisr();
      }
      if (value & 0x00800000) {
        db_IPR.IRQ7 = 0;
        updateisr();
      }
      break;
    case IPR:
      // do nothing
      break;
    case LSSA:
      db_LSSA.x = value;
      break;
    case RTCHMS:
      db_RTCHMS.x = value;
      break;
    case RTCALARM:
      db_RTCALARM.x = value;
      break;
    default:
      __asm int 3;
      custom_wput(addr & 0xfffe, value >> 16);
      custom_wput((addr+2) & 0xfffe, (UWORD)value);
      break;
  }
}

