 /* 
  * Copilot
  * 
  * MC68000 emulation
  *
  * Original UAE code Copyright (c) 1995 Bernd Schmidt
  */

#include "win.h"

#include "sysdeps.h"

#include "memory.h"
#include "custom.h"
#include "newcpu.h"

int areg_byteinc[] = { 1,1,1,1,1,1,1,2 };
int imm8_table[] = { 8,1,2,3,4,5,6,7 };

UWORD *InstructionStart_p;
int ExceptionFlags[48];

#ifdef COUNT_INSTRS
static unsigned long int instrcount[65536];
static UWORD opcodenums[65536];

int compfn(const void *el1, const void *el2)
{
    return instrcount[*(const UWORD *)el1] < instrcount[*(const UWORD *)el2];
}

void dump_counts(void)
{
    FILE *f = fopen("insncount", "w");
    unsigned long int total = 0;
    int i;
    
    for(i=0; i < 65536; i++) {
	opcodenums[i] = i;
    	total += instrcount[i];
    }
    qsort(opcodenums, 65536, sizeof(UWORD), compfn);
    
    fprintf(f, "Total: %ld\n", total);
    for(i=0; i < 65536; i++) {
	unsigned long int cnt = instrcount[opcodenums[i]];
	if (!cnt)
	    break;
	fprintf(f, "%04x: %ld\n", opcodenums[i], cnt);
    }
    fclose(f);
}
#endif

#ifdef INTEL_FLAG_OPT
union flagu intel_flag_lookup[256];
#endif

void init_m68k (void)
{
#ifdef COUNT_INSTRS
    memset(instrcount, 0, sizeof instrcount);
#endif
#ifdef INTEL_FLAG_OPT
    for (i = 0; i < 256; i++) {
	intel_flag_lookup[i].flags.c = !!(i & 1);
	intel_flag_lookup[i].flags.z = !!(i & 64);
	intel_flag_lookup[i].flags.n = !!(i & 128);
	intel_flag_lookup[i].flags.v = 0;
    }
#endif
/*    printf("Building CPU table...\n");
    read_table68k ();
    do_merges ();
    for (opcode = 0; opcode < 65536; opcode++)
	cpufunctbl[opcode] = op_illg;
    for (i = 0; smallcputbl[i].handler != NULL; i++) {
	if (!smallcputbl[i].specific)
	    cpufunctbl[smallcputbl[i].opcode] = smallcputbl[i].handler;
    }
    for (opcode = 0; opcode < 65536; opcode++) {
	cpuop_func *f;
	
	if (table68k[opcode].mnemo == i_ILLG)
	    continue;
	
	if (table68k[opcode].handler != -1) {
	    f = cpufunctbl[table68k[opcode].handler];
	    if (f == op_illg)
		abort();
	    cpufunctbl[opcode] = f;
	}
    }	
    for (i = 0; smallcputbl[i].handler != NULL; i++) {
	if (smallcputbl[i].specific)
	    cpufunctbl[smallcputbl[i].opcode] = smallcputbl[i].handler;
    }*/
}

struct regstruct regs;
union flagu regflags;

#if CPU_LEVEL > 1
ULONG get_disp_ea (ULONG base, UWORD dp)
{
    int reg = (dp >> 12) & 7;
    LONG regd;
    if (dp & 0x8000)
	regd = regs.a[reg];
    else
	regd = regs.d[reg];
    if (!(dp & 0x800))
	regd = (LONG)(WORD)regd;
    if (dp & 0x100) {
	LONG extraind = 0;
	printf("020\n");
	regd <<= (dp >> 9) & 3;
	if (dp & 0x80)
	    base = 0;
	if (dp & 0x40)
	    regd = 0;
	if ((dp & 0x30) == 0x20)
	    base += (LONG)(WORD)nextiword();
	if ((dp & 0x30) == 0x30)
	    base += nextilong();
	
	if ((dp & 0x3) == 0x2)
	    extraind = (LONG)(WORD)nextiword();
	if ((dp & 0x3) == 0x3)
	    extraind = nextilong();
	
	if (!(dp & 4))
	    base += regd;
	if (dp & 3)
	    base = get_long (base);
	if (dp & 4)
	    base += regd;
	
	return base + extraind;
	/* Yikes, that's complicated */
    } else {
	return base + (BYTE)(dp) + regd;
    }
}
#endif

void MakeSR(void)
{
#if 0
    assert((NFLG & 1) == NFLG);
    assert((regs.s & 1) == regs.s);
    assert((regs.x & 1) == regs.x);
    assert((CFLG & 1) == CFLG);
    assert((VFLG & 1) == VFLG);
    assert((ZFLG & 1) == ZFLG);
#endif
    regs.sr = ((regs.t << 15) | (regs.s << 13) | (regs.intmask << 8)
	       | (regs.x << 4) | (NFLG << 3) | (ZFLG << 2) | (VFLG << 1) 
	       |  CFLG);
}

void MakeFromSR(void)
{
    int olds = regs.s;

    regs.t = (regs.sr >> 15) & 1;
    regs.s = (regs.sr >> 13) & 1;
    regs.intmask = (regs.sr >> 8) & 7;
    regs.x = (regs.sr >> 4) & 1;
    NFLG = (regs.sr >> 3) & 1;
    ZFLG = (regs.sr >> 2) & 1;
    VFLG = (regs.sr >> 1) & 1;
    CFLG = regs.sr & 1;
    if (olds != regs.s) {
	CPTR temp = regs.usp;
	regs.usp = regs.a[7];
	regs.a[7] = temp;
    }
    specialflags |= SPCFLAG_INT;
    if (regs.t)
    	specialflags |= SPCFLAG_TRACE;
    else
    	specialflags &= ~(SPCFLAG_TRACE | SPCFLAG_DOTRACE);
}

void Exception(int nr)
{
    if (nr < 48 && ExceptionFlags[nr] && InstructionStart_p) {
      regs.pc_p = InstructionStart_p;
      CpuState = cpuException + nr;
      return;
    }
    if (nr == 32+0xF && do_api(*regs.pc_p)) {
      nextiword();
      return;
    }
    MakeSR();
    if (!regs.s) {
	CPTR temp = regs.usp;
	regs.usp = regs.a[7];
	regs.a[7] = temp;
	regs.s = 1;
    }
    if (CPU_LEVEL > 0) {
	regs.a[7] -= 2;
	put_word (regs.a[7], nr * 4);
    }
    regs.a[7] -= 4;
    put_long (regs.a[7], m68k_getpc ());
    regs.a[7] -= 2;
    put_word (regs.a[7], regs.sr);
    m68k_setpc(get_long(4*nr));
    regs.t = 0;
    specialflags &= ~(SPCFLAG_TRACE | SPCFLAG_DOTRACE);
}

static void Interrupt(int nr)
{
    assert(nr < 8 && nr >= 0);
    Exception(nr+intbase());
    
    regs.intmask = nr;
    specialflags |= SPCFLAG_INT;
}

void MC68000_reset(void)
{
    regs.a[7] = get_long(0x10c00000);
    m68k_setpc(get_long(0x10c00004));
    regs.s = 1;
    regs.stopped = 0;
    regs.t = 0;
    specialflags = 0;
    CpuState = cpuInitial;
    regs.intmask = 7;
    customreset();
}

void op_illg(ULONG opcode)
{
    regs.pc_p--;
    if ((opcode & 0xF000) == 0xF000) {
	if ((opcode & 0xE00) == 0x200)
	    Exception(0xB);
	else 
	    switch (opcode & 0x1FF) {
	     case 0x17:
		regs.pc_p+=2;
		break;
	     default:
		regs.pc_p++;
	    }
	return;
    }
    if ((opcode & 0xF000) == 0xA000) {
    	Exception(0xA);
	return;
    }
    if (opcode == 0x4AFC) { // breakpoint
      CpuState = cpuBreakpoint;
      return;
    }
//    fprintf(stderr, "Illegal instruction: %04x\n", opcode);
    Exception(4);
}

static int n_insns=0, n_spcinsns=0;

void MC68000_run(void)
{
    for(;;) {
        //{
        //  static char x = 0;
        //  if (x++ == 0) {
        //    FILE *f = fopen("cpu.log", "at");
        //    fprintf(f, "%d: %08x\n", GetTickCount(), regs.pc + ((char *)regs.pc_p - (char *)regs.pc_oldp));
        //    fclose(f);
        //  }
        //}
        InstructionStart_p = regs.pc_p;
	UWORD opcode;
	/* assert (!regs.stopped && !(specialflags & SPCFLAG_STOP)); */
	opcode = nextiword();
#ifdef COUNT_INSTRS
	instrcount[opcode]++;
#endif
	(*cpufunctbl[opcode])(opcode);
#ifndef NO_EXCEPTION_3
	if (buserr) {
      if ((specialflags & SPCFLAG_BRK) == 0) { // allow user to skip over bus errors
        regs.pc_p = InstructionStart_p;
        CpuState = cpuBusError;
        return;
      }
      //Exception(3);
      buserr = 0;
	}
#endif
        InstructionStart_p = NULL;
        /*n_insns++;*/
	do_cycles(0);	
	if (specialflags) {
	    /*n_spcinsns++;*/
	    if (specialflags & SPCFLAG_DOTRACE) {
		Exception(9);
	    }
	    while (specialflags & SPCFLAG_STOP) {
                Sleep(10);
		do_cycles(1);
		if (specialflags & (SPCFLAG_INT | SPCFLAG_DOINT)){
		    int intr = intlev();
		    specialflags &= ~(SPCFLAG_INT | SPCFLAG_DOINT);
		    specialflags &= ~(SPCFLAG_INT | SPCFLAG_DOINT);
		    if (intr != -1 && intr > regs.intmask) {
			Interrupt(intr);
			regs.stopped = 0;
			specialflags &= ~SPCFLAG_STOP;
		    }	    
		}
                if (CpuState > cpuRunning) {
                  return;
                }
	    }
	    if (specialflags & SPCFLAG_TRACE) {
		specialflags &= ~SPCFLAG_TRACE;
		specialflags |= SPCFLAG_DOTRACE;
	    }
	    
	    if (specialflags & SPCFLAG_DOINT) {
		int intr = intlev();
		specialflags &= ~(SPCFLAG_INT | SPCFLAG_DOINT);
		if (intr != -1 && intr > regs.intmask) {
		    Interrupt(intr);
		    regs.stopped = 0;
		}	    
	    }
	    if (specialflags & SPCFLAG_INT) {
		specialflags &= ~SPCFLAG_INT;
		specialflags |= SPCFLAG_DOINT;
	    }
	    if (specialflags & SPCFLAG_BRK) {
		specialflags &= ~SPCFLAG_BRK;
		return;		
	    }
	}
        if (CpuState > cpuRunning) {
          return;
        }
    }
}

void MC68000_step(void)
{
    specialflags |= SPCFLAG_BRK;
    MC68000_run();
}

void MC68000_skip(CPTR nextpc)
{
    specialflags |= SPCFLAG_BRK;
    do {
	MC68000_step();
    } while (nextpc != m68k_getpc());
    CpuState = cpuStopped;
}
