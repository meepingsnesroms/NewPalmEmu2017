// Copilot cpu interface module
//
// Copyright (c) 1996 Greg Hewgill

#include "win.h"

#include "sysdeps.h"

#include "memory.h"
#include "custom.h"
#include "newcpu.h"

extern void pen(int down, int x, int y);
extern void dokey(int down, int key);
extern void hotsync(int down);
extern void putkey(UBYTE key);

extern UBYTE *scratchmemory;

int CpuState;

HANDLE CpuBeginEvent;
HANDLE CpuStoppedEvent;
CPTR skipaddr = 0;
int resetflag = 0;

DWORD __stdcall CPU(void *)
{
  CpuState = cpuInitial;
  while (1) {
    WaitForSingleObject(CpuBeginEvent, INFINITE);
    // CpuState should be cpuRunning now
    while (1) {
      if (skipaddr) {
        MC68000_skip(skipaddr);
        skipaddr = 0;
      } else {
        MC68000_run();
      }
      if (resetflag) {
        resetflag = 0;
        MC68000_reset();
        // hope the debugger doesn't kick in for the brief time CpuState
        // is not CpuRunning
        CpuState = cpuRunning;
      } else {
        break;
      }
    }
    // CpuState should be > cpuRunning now
    SetEvent(CpuStoppedEvent);
  }
  return 0;
}

extern "C" {

int APIENTRY CPU_init(HANDLE commhandle, int ramsize, const char *romfn)
{
  int r = memory_init(ramsize, romfn);
  if (r != 0) {
    return r;
  }
  custom_init(commhandle);
  init_m68k();
  MC68000_reset();
  CpuBeginEvent = CreateEvent(NULL, FALSE, FALSE, NULL);
  CpuStoppedEvent = CreateEvent(NULL, TRUE, FALSE, NULL);
  SetEvent(CpuStoppedEvent);
  DWORD tid;
  CloseHandle(CreateThread(NULL, 0, CPU, NULL, 0, &tid));
  return 0;
}

void APIENTRY CPU_reset()
{
  if (WaitForSingleObject(CpuStoppedEvent, 0) == WAIT_OBJECT_0) {
    MC68000_reset();
  } else {
    CpuState = cpuStopped;
    resetflag = 1;
  }
}

void APIENTRY CPU_run()
{
  if (WaitForSingleObject(CpuStoppedEvent, 0) == WAIT_OBJECT_0) {
    ResetEvent(CpuStoppedEvent);
    CpuState = cpuRunning;
    SetEvent(CpuBeginEvent);
  }
}

void APIENTRY CPU_stop()
{
  CpuState = cpuStopped;
  WaitForSingleObject(CpuStoppedEvent, INFINITE);
}

BOOL APIENTRY CPU_wait(DWORD timeout)
{
  return WaitForSingleObject(CpuStoppedEvent, timeout) == WAIT_OBJECT_0;
}

void APIENTRY CPU_step()
{
  if (WaitForSingleObject(CpuStoppedEvent, 0) == WAIT_OBJECT_0) {
    ResetEvent(CpuStoppedEvent);
    specialflags |= SPCFLAG_BRK;
    CpuState = cpuRunning;
    SetEvent(CpuBeginEvent);
  }
}

void APIENTRY CPU_skip(CPTR addr)
{
  if (WaitForSingleObject(CpuStoppedEvent, 0) == WAIT_OBJECT_0) {
    ResetEvent(CpuStoppedEvent);
    skipaddr = addr;
    CpuState = cpuRunning;
    SetEvent(CpuBeginEvent);
  }
}

int APIENTRY CPU_getstate()
{
  return CpuState;
}

void APIENTRY CPU_getregs(regstruct &r)
{
  r = regs;
  r.pc = m68k_getpc();
  *(flagu *)&r.pc_p = regflags;
}

void APIENTRY CPU_setregs(const regstruct &r)
{
  regs = r;
  MakeFromSR();
  m68k_setpc(r.pc);
}

int APIENTRY CPU_getexceptionflag(int exception)
{
  if (exception < 0 || exception >= 48) {
    return 0;
  }
  return ExceptionFlags[exception];
}

int APIENTRY CPU_setexceptionflag(int exception, int flag)
{
  if (exception < 0 || exception >= 48) {
    return 0;
  }
  int r = ExceptionFlags[exception];
  ExceptionFlags[exception] = flag;
  return r;
}

int APIENTRY CPU_addrcheck(CPTR addr, int size)
{
  return valid_address(addr, size);
}

UBYTE APIENTRY CPU_getbyte(CPTR addr)
{
  return get_byte(addr);
}

UWORD APIENTRY CPU_getword(CPTR addr)
{
  return get_word(addr);
}

ULONG APIENTRY CPU_getlong(CPTR addr)
{
  return get_long(addr);
}

void *APIENTRY CPU_getmemptr(CPTR addr)
{
  return get_real_address(addr);
}

void APIENTRY CPU_putbyte(CPTR addr, UBYTE x)
{
  put_byte(addr, x);
}

void APIENTRY CPU_putword(CPTR addr, UWORD x)
{
  put_word(addr, x);
}

void APIENTRY CPU_putlong(CPTR addr, ULONG x)
{
  put_long(addr, x);
}

void APIENTRY CPU_pen(int down, int x, int y)
{
  pen(down, x, y);
}

void APIENTRY CPU_key(int down, int key)
{
  dokey(down, key);
}

void APIENTRY CPU_hotsync(int down)
{
  hotsync(down);
}

void APIENTRY CPU_putkey(UBYTE key)
{
  putkey(key);
}

void APIENTRY CPU_setscratchaddr(UBYTE *addr)
{
  scratchmemory = addr;
}

void APIENTRY CPU_setsounds(BOOL enablesounds)
{
  EnableSounds = enablesounds;
}

} // extern "C"
