// LCD display
//
// Copyright (c) 1996 Greg Hewgill

#include <windows.h>
#include <malloc.h>
#pragma hdrstop

#include "pilotcpu\pilotcpu.h"
#include "pilotcpu\dragonball.h"

#include "settings.h"

#define NON_PORTABLE
#define HW_REV 5
#include "HardwareTD1.h"

#include "resource.h"

extern void StartDebugger(); // this might come from any debugger

const char *DefaultRegistryKey = "Software\\Test\\Copilot";

const DWORD CM_RESET      = 1001;
const DWORD CM_HOTSYNC    = 1002;
const DWORD CM_LOADAPP    = 1003;
const DWORD CM_DEBUG      = 1004;
const DWORD CM_EXIT       = 1005;
const DWORD CM_ABOUT      = 1006;
const DWORD CM_PROPERTIES = 1007;

const DWORD CM_LOADAPPMRU = 2000;

const int PlasticWidth = 221;
const int PlasticHeight = 337;
const int PlasticBaseX = 34;
const int PlasticBaseY = 33;

const POINT points[] = {
  {  3,   0},
  {217,   0},
  {220,   3},
  {220, 310},
  {218, 313},
  {210, 316},
  {210, 333},
  {207, 336},
  { 13, 336},
  { 10, 333},
  { 10, 314},
  {  2, 311},
  {  0, 308},
  {  0,   3}
};
const int NPOINTS = sizeof(points)/sizeof(POINT);

TSettings TempSettings;

OSVERSIONINFO OSVersionInfo;
HWND CopilotWindow;
BITMAPINFO *plasticBMI;
void *plasticBits;
HBITMAP silkscreen, silkscreen2;
HPALETTE Palette;
BOOL movedrag = FALSE;
RECT DragOrigRect;
POINT DragBase;
BOOL pentracking = FALSE;
BOOL keytracking = FALSE;
int curkey;
WORD screenimage[160][160/16];
DWORD HotSyncDownStart = 0;

inline WORD swap(WORD x) { return (x << 8) | (x >> 8); }

class FakeCall {
public:
  FakeCall();
  ~FakeCall();
  void PushWord(WORD x);
  void PushLong(DWORD x);
  void *PushPtr(int size);
  void Call(WORD api);
  DWORD GetResultD0();
  DWORD GetResultA0();
private:
  CPU_regs origregs, regs;
  enum {addrstart = 0x2000};
  DWORD nextaddr;
  void *SaveMemory;
  void PutSwap(DWORD addr, WORD word);
  void SwapRange(DWORD startaddr, DWORD endaddr);
};

FakeCall::FakeCall()
{
  CPU_getregs(origregs);
  regs = origregs;
  SaveMemory = malloc(4096);
  CopyMemory(SaveMemory, CPU_getmemptr(addrstart), 4096);
  nextaddr = addrstart;
}

FakeCall::~FakeCall()
{
  CPU_setregs(origregs);
  CopyMemory(CPU_getmemptr(0x2000), SaveMemory, 4096);
  free(SaveMemory);
}

void FakeCall::PushWord(WORD x)
{
  regs.a[7] -= 2;
  CPU_putword(regs.a[7], x);
}

void FakeCall::PushLong(DWORD x)
{
  regs.a[7] -= 4;
  CPU_putlong(regs.a[7], x);
}

void *FakeCall::PushPtr(int size)
{
  regs.a[7] -= 4;
  if (size == 0) {
    CPU_putlong(regs.a[7], 0);
    return NULL;
  }
  CPU_putlong(regs.a[7], nextaddr);
  void *r = CPU_getmemptr(nextaddr);
  nextaddr += size + (size & 1);
  return r;
}

void FakeCall::Call(WORD api)
{
  SwapRange(addrstart, nextaddr);
  WORD oldapi = CPU_getword(regs.pc+2);
  WORD oldnxt = CPU_getword(regs.pc+4);
  PutSwap(regs.pc+2, api);
  PutSwap(regs.pc+4, 0x4AFC);
  CPU_setregs(regs);
  CPU_run();
  CPU_wait(INFINITE);
  CPU_getregs(regs);
  CPU_setregs(origregs);
  PutSwap(origregs.pc+2, oldapi);
  PutSwap(origregs.pc+4, oldnxt);
  SwapRange(addrstart, nextaddr);
}

void FakeCall::PutSwap(DWORD addr, WORD word)
{
  WORD *p = (WORD *)CPU_getmemptr(addr);
  *p = word;
  if (CPU_getword(addr) != word) {
    *p = swap(word);
  }
}

void FakeCall::SwapRange(DWORD startaddr, DWORD endaddr)
{
  WORD *p = (WORD *)CPU_getmemptr(startaddr);
  WORD *e = (WORD *)CPU_getmemptr(endaddr);
  while (p < e) {
    *p = swap(*p);
    p++;
  }
}

DWORD FakeCall::GetResultD0()
{
  return regs.d[0];
}

DWORD FakeCall::GetResultA0()
{
  return regs.a[0];
}

const WORD sysTrapMemNumRAMHeaps            = 40968;
const WORD sysTrapMemHeapID                 = 40969;
const WORD sysTrapMemHeapFreeBytes          = 40971;
const WORD sysTrapMemChunkNew               = 40977;
const WORD sysTrapMemChunkFree              = 40978;
const WORD sysTrapMemPtrNew                 = 40979;
const WORD sysTrapMemHandleLock             = 40993;
const WORD sysTrapMemHandleUnlock           = 40994;
const WORD sysTrapDmCreateDatabase          = 41025;
const WORD sysTrapDmDeleteDatabase          = 41026;
const WORD sysTrapDmGetDatabase             = 41028;
const WORD sysTrapDmFindDatabase            = 41029;
const WORD sysTrapDmDatabaseInfo            = 41030;
const WORD sysTrapDmOpenDatabase            = 41033;
const WORD sysTrapDmCloseDatabase           = 40134;
const WORD sysTrapDmNewRecord               = 41045;
const WORD sysTrapDmReleaseRecord           = 41054;
const WORD sysTrapDmCreateDatabaseFromImage = 41087;

const DWORD memErrNotEnoughSpace = 0x102;
const DWORD dmErrDatabaseOpen    = 0x205;

const WORD dmModeReadWrite = 3;

BOOL DoLoadApp(const char *fn)
{
  CPU_setexceptionflag(32+0xF, TRUE);
  BOOL ok = CPU_wait(1000);
  CPU_setexceptionflag(32+0xF, FALSE);
  if (!ok) {
    MessageBox(CopilotWindow, "The emulator is not ready to load an application at this time.\n(Perhaps it is turned off?)", "Copilot", MB_OK);
    return FALSE;
  }
  DWORD err = 0;
  {
    HANDLE f = CreateFile(fn, GENERIC_READ, FILE_SHARE_READ, NULL, OPEN_EXISTING, FILE_FLAG_SEQUENTIAL_SCAN, NULL);
    if (f != INVALID_HANDLE_VALUE) {
      DWORD size = GetFileSize(f, NULL);
      DWORD csize = (size+7) & ~1;
      BYTE *buf = (BYTE *)malloc(csize);
      DWORD n;
      ReadFile(f, &buf[6], size, &n, NULL);
      // set up fake chunk header
      buf[0] = BYTE(csize >> 8);
      buf[1] = BYTE(csize);
      buf[2] = 0xF0;
      buf[3] = BYTE(csize - 6 - size);
      buf[4] = 0;
      buf[5] = 0;
      CPU_setscratchaddr(buf);
      DWORD dbid;
      {
        FakeCall fc;
        fc.PushLong(0x00010006); // nameP
        fc.PushWord(0); // cardNo
        fc.Call(sysTrapDmFindDatabase);
        dbid = fc.GetResultD0();
      }
      if (dbid) {
        FakeCall fc;
        fc.PushLong(dbid); // dbID
        fc.PushWord(0); // cardNo
        fc.Call(sysTrapDmDeleteDatabase);
        err = fc.GetResultD0();
      }
      if (err == 0) {
        {
          FakeCall fc;
          fc.PushLong(0x00010006);
          fc.Call(sysTrapDmCreateDatabaseFromImage);
          fc.GetResultD0();
        }
      }
      CPU_setscratchaddr(NULL);
      free(buf);
      CloseHandle(f);
    }
  }
  CPU_run();
  if (err == 0) {
    MessageBox(CopilotWindow, "Application loaded successfully!", "Copilot", MB_OK);
  } else {
    switch (err) {
      case memErrNotEnoughSpace:
        MessageBox(CopilotWindow, "That application is too large to be loaded into Dynamic RAM right now.", "Copilot", MB_OK);
        break;
      case dmErrDatabaseOpen:
        MessageBox(CopilotWindow, "That application is currently in use.\nSwitch to another application before loading.", "Copilot", MB_OK);
        break;
      default:
        char buf[80];
        wsprintf(buf, "Unknown error 0x%x loading application.", err);
        MessageBox(CopilotWindow, buf, "Copilot", MB_OK);
        break;
    }
  }
  return err == 0;
}

void LoadApp()
{
  char fn[MAX_PATH];
  fn[0] = 0;
  OPENFILENAME ofn;
  ZeroMemory(&ofn, sizeof(ofn));
  ofn.lStructSize = sizeof(ofn);
  ofn.hwndOwner = CopilotWindow;
  ofn.lpstrFilter = "Pilot Applications (*.prc, *.pdb)\0*.prc;*.pdb\0";
  ofn.lpstrFile = fn;
  ofn.nMaxFile = sizeof(fn);
  ofn.lpstrInitialDir = Settings.PrcPath;
  ofn.Flags = OFN_EXPLORER | OFN_FILEMUSTEXIST | OFN_HIDEREADONLY | OFN_NOCHANGEDIR;
  ofn.lpstrDefExt = "prc";
  if (GetOpenFileName(&ofn)) {
    if (DoLoadApp(fn)) {
      Settings.UpdateMru(fn);
    }
    fn[ofn.nFileOffset] = 0;
    strcpy(Settings.PrcPath, fn);
  }
}

void ResetWindow()
{
  RECT wr, cr;
  if (Settings.Realistic) {
    SetWindowLong(CopilotWindow, GWL_STYLE, GetWindowLong(CopilotWindow, GWL_STYLE) & ~WS_CAPTION);
    GetWindowRect(CopilotWindow, &wr);
    GetClientRect(CopilotWindow, &cr);
    MoveWindow(CopilotWindow, wr.left, wr.top, PlasticWidth*Settings.Scale+(wr.right-wr.left)-(cr.right-cr.left), PlasticHeight*Settings.Scale+(wr.bottom-wr.top)-(cr.bottom-cr.top), TRUE);
    POINT p[NPOINTS];
    for (int i = 0; i < NPOINTS; i++) {
      p[i].x = points[i].x * Settings.Scale;
      p[i].y = points[i].y * Settings.Scale;
    }
    HRGN region = CreatePolygonRgn(p, NPOINTS, ALTERNATE);
    SetWindowRgn(CopilotWindow, region, TRUE);
  } else {
    SetWindowRgn(CopilotWindow, NULL, TRUE);
    SetWindowLong(CopilotWindow, GWL_STYLE, GetWindowLong(CopilotWindow, GWL_STYLE) | WS_CAPTION);
    GetWindowRect(CopilotWindow, &wr);
    GetClientRect(CopilotWindow, &cr);
    MoveWindow(CopilotWindow, wr.left, wr.top, 160*Settings.Scale+(wr.right-wr.left)-(cr.right-cr.left), (160+60)*Settings.Scale+(wr.bottom-wr.top)-(cr.bottom-cr.top), TRUE);
    GetWindowRect(CopilotWindow, &wr);
    GetClientRect(CopilotWindow, &cr);
    MoveWindow(CopilotWindow, wr.left, wr.top, 160*Settings.Scale+(wr.right-wr.left)-(cr.right-cr.left), (160+60)*Settings.Scale+(wr.bottom-wr.top)-(cr.bottom-cr.top), TRUE);
  }
  SetTimer(CopilotWindow, 1, 1000/Settings.FPS, NULL);
  InvalidateRect(CopilotWindow, NULL, FALSE);
}

BOOL CALLBACK PropertyProc(HWND hwnd, UINT msg, WPARAM wparam, LPARAM lparam)
{
  switch (msg) {
    case WM_COMMAND:
      switch (HIWORD(wparam)) {
        case BN_CLICKED:
          if (LOWORD(wparam) == IDC_BROWSE_ROMFILE) {
            char fn[MAX_PATH];
            if (!GetDlgItemText(hwnd, IDC_ROMFILE, fn, sizeof(fn))) {
              fn[0] = 0;
            }
            OPENFILENAME ofn;
            ZeroMemory(&ofn, sizeof(ofn));
            ofn.lStructSize = sizeof(ofn);
            ofn.hwndOwner = hwnd;
            ofn.lpstrFilter = "Pilot ROM files (*.rom)\0*.rom\0";
            ofn.lpstrFile = fn;
            ofn.nMaxFile = sizeof(fn);
            ofn.Flags = OFN_EXPLORER | OFN_FILEMUSTEXIST | OFN_HIDEREADONLY | OFN_NOCHANGEDIR;
            ofn.lpstrDefExt = "rom";
            if (GetOpenFileName(&ofn)) {
              SetDlgItemText(hwnd, IDC_ROMFILE, fn);
            }
            break;
          }
          // FALL THROUGH //
        case CBN_SELCHANGE:
        case EN_CHANGE:
          if (LOWORD(wparam) == IDC_REALISTIC) {
            EnableWindow(GetDlgItem(hwnd, IDC_BACKLIGHT), SendMessage((HWND)lparam, BM_GETCHECK, 0, 0) == BST_CHECKED);
          }
          PropSheet_Changed(GetParent(hwnd), hwnd);
          break;
      }
      break;
    case WM_INITDIALOG: {
      SendDlgItemMessage(hwnd, IDC_ZOOM2X, BM_SETCHECK, Settings.Scale==2, 0);
      SendDlgItemMessage(hwnd, IDC_REALISTIC, BM_SETCHECK, Settings.Realistic, 0);
      SendDlgItemMessage(hwnd, IDC_BACKLIGHT, BM_SETCHECK, Settings.Backlight, 0);
      if (!Settings.Realistic) {
        EnableWindow(GetDlgItem(hwnd, IDC_BACKLIGHT), FALSE);
      }
      SendDlgItemMessage(hwnd, IDC_SOUNDS, BM_SETCHECK, Settings.Sounds, 0);
      SetDlgItemInt(hwnd, IDC_FPS, Settings.FPS, FALSE);
      SendDlgItemMessage(hwnd, IDC_RAMSIZE, CB_ADDSTRING, 0, (LPARAM)"128 KB");
      SendDlgItemMessage(hwnd, IDC_RAMSIZE, CB_ADDSTRING, 0, (LPARAM)"512 KB");
      SendDlgItemMessage(hwnd, IDC_RAMSIZE, CB_ADDSTRING, 0, (LPARAM)"1024 KB (1 MB)");
      SendDlgItemMessage(hwnd, IDC_RAMSIZE, CB_ADDSTRING, 0, (LPARAM)"2048 KB (2 MB)");
      SendDlgItemMessage(hwnd, IDC_RAMSIZE, CB_ADDSTRING, 0, (LPARAM)"4096 KB (4 MB)");
      SendDlgItemMessage(hwnd, IDC_RAMSIZE, CB_ADDSTRING, 0, (LPARAM)"8192 KB (8 MB)");
      char buf[20];
      wsprintf(buf, "%d", Settings.RamSize);
      SendDlgItemMessage(hwnd, IDC_RAMSIZE, CB_SELECTSTRING, (WPARAM)-1, (LPARAM)buf);
      SetDlgItemText(hwnd, IDC_ROMFILE, Settings.RomFile);
      SendDlgItemMessage(hwnd, IDC_PORT, CB_ADDSTRING, 0, (LPARAM)"None");
      for (int i = 1; i <= 4; i++) {
        char buf[10];
        wsprintf(buf, "COM%d", i);
        SendDlgItemMessage(hwnd, IDC_PORT, CB_ADDSTRING, 0, (LPARAM)buf);
      }
      SendDlgItemMessage(hwnd, IDC_PORT, CB_SELECTSTRING, (WPARAM)-1, (LPARAM)Settings.CommPort);
      SendDlgItemMessage(hwnd, IDC_DEBUGATSTARTUP, BM_SETCHECK, Settings.DebugAtStartup, 0);
      TempSettings = Settings;
      break;
    }
    case WM_NOTIFY:
      switch (((NMHDR *)lparam)->code) {
        case PSN_APPLY: {
          if (SendDlgItemMessage(hwnd, IDC_ZOOM2X, BM_GETCHECK, 0, 0) == BST_CHECKED) {
            Settings.Scale = 2;
          } else {
            Settings.Scale = 1;
          }
          Settings.Realistic = SendDlgItemMessage(hwnd, IDC_REALISTIC, BM_GETCHECK, 0, 0) == BST_CHECKED;
          Settings.Backlight = SendDlgItemMessage(hwnd, IDC_BACKLIGHT, BM_GETCHECK, 0, 0) == BST_CHECKED;
          Settings.Sounds = SendDlgItemMessage(hwnd, IDC_SOUNDS, BM_GETCHECK, 0, 0) == BST_CHECKED;
          CPU_setsounds(Settings.Sounds);
          BOOL ok;
          int fps = GetDlgItemInt(hwnd, IDC_FPS, &ok, FALSE);
          if (ok && fps > 0) {
            Settings.FPS = fps;
          }
          char buf[MAX_PATH];
          SendDlgItemMessage(hwnd, IDC_RAMSIZE, CB_GETLBTEXT, SendDlgItemMessage(hwnd, IDC_RAMSIZE, CB_GETCURSEL, 0, 0), (LPARAM)buf);
          Settings.RamSize = atoi(buf);
          if (Settings.RamSize != TempSettings.RamSize) {
            MessageBox(hwnd, "Changes to the RAM size will not take effect until you shut down and restart Copilot.", "Copilot", MB_OK);
          }
          if (GetDlgItemText(hwnd, IDC_ROMFILE, buf, sizeof(buf))) {
            if (GetFileAttributes(buf) != 0xFFFFFFFF
             || MessageBox(hwnd, "The ROM file name you selected does not exist. Save anyway?", "Copilot", MB_YESNO) == IDYES) {
              strcpy(Settings.RomFile, buf);
            }
          }
          if (stricmp(Settings.RomFile, TempSettings.RomFile) != 0) {
            MessageBox(hwnd, "Changes to the ROM file will not take effect until you shut down and restart Copilot.", "Copilot", MB_OK);
          }
          SendDlgItemMessage(hwnd, IDC_PORT, CB_GETLBTEXT, SendDlgItemMessage(hwnd, IDC_PORT, CB_GETCURSEL, 0, 0), (LPARAM)Settings.CommPort);
          if (stricmp(Settings.CommPort, TempSettings.CommPort) != 0) {
            MessageBox(hwnd, "Changes to the communications port will not take effect until you shut down and restart Copilot.", "Copilot", MB_OK);
          }
          Settings.DebugAtStartup = SendDlgItemMessage(hwnd, IDC_DEBUGATSTARTUP, BM_GETCHECK, 0, 0) == BST_CHECKED;
          ResetWindow();
          Settings.Save(CopilotWindow);
          PropSheet_UnChanged(GetParent(hwnd), hwnd);
          break;
        }
        case PSN_RESET:
          Settings = TempSettings;
          ResetWindow();
          Settings.Save(CopilotWindow);
          break;
      }
      break;
    default:
      return FALSE;
  }
  return TRUE;
}

void Properties(HWND hwnd)
{
  PROPSHEETPAGE psp[1];
  ZeroMemory(&psp, sizeof(psp));
  psp[0].dwSize = sizeof(PROPSHEETPAGE);
  psp[0].dwFlags = PSP_DEFAULT;
  psp[0].hInstance = GetModuleHandle(NULL);
  psp[0].pszTemplate = MAKEINTRESOURCE(IDD_PROPERTIES);
  psp[0].pfnDlgProc = PropertyProc;
  PROPSHEETHEADER psh;
  ZeroMemory(&psh, sizeof(psh));
  psh.dwSize = sizeof(psh);
  psh.dwFlags = PSH_PROPSHEETPAGE | PSH_PROPTITLE;
  psh.hwndParent = hwnd;
  psh.hInstance = GetModuleHandle(NULL);
  psh.pszCaption = "Copilot";
  psh.nPages = 1;
  psh.ppsp = &psp[0];
  PropertySheet(&psh);
}

BOOL CALLBACK AboutDlgProc(HWND hwnd, UINT msg, WPARAM wparam, LPARAM lparam)
{
  switch (msg) {
    case WM_COMMAND:
      switch (LOWORD(wparam)) {
        case IDOK:
        case IDCANCEL:
          EndDialog(hwnd, LOWORD(wparam));
          break;
      }
      break;
    case WM_INITDIALOG:
      SetDlgItemText(hwnd, IDC_ABOUT_DATE, "("__DATE__")");
      break;
    default:
      return FALSE;
  }
  return TRUE;
}

BOOL memcmpy(void *dest, const void *src, int len)
{
  BYTE r;
  __asm {
    mov edx,0
    mov esi,src
    mov edi,dest
    mov ecx,len
    shr ecx,2
  dloop:
    mov eax,[esi]
    mov ebx,[edi]
    add esi,4
    xor ebx,eax
    add edi,4
    or  edx,ebx
    mov [edi-4],eax
    loop dloop
    or  edx,edx
    setne al
    mov r,al
  }
  return r;
}

void PaintScreen(HDC dc, BOOL always)
{
  BOOL lcdon = (CPU_getbyte(DB+PFDATA) & hwrTD1PortFLCDEnableOn) != 0;
  COLORREF background, foreground;
  if (Settings.Realistic) {
    if (Settings.Backlight && lcdon) {
      background = RGB(100, 240, 220);
    } else {
      background = RGB(84, 108, 85);
    }
  } else {
    background = RGB(255, 255, 255);
  }
  foreground = RGB(0, 0, 0);
  if (!lcdon) {
    SetBkColor(dc, PALETTEINDEX(GetNearestPaletteIndex(Palette, background)));
    RECT r = {PlasticBaseX*Settings.Realistic*Settings.Scale, PlasticBaseY*Settings.Realistic*Settings.Scale};
    r.right = r.left + 160*Settings.Scale;
    r.bottom = r.top + 160*Settings.Scale;
    ExtTextOut(dc, 0, 0, ETO_OPAQUE, &r, NULL, 0, NULL);
    screenimage[0][0]++; // tweak the screen image so we'll always update it
    return;
  }
  BOOL different = memcmpy(screenimage, CPU_getmemptr(CPU_getlong(DB+LSSA)), 160*160/8);
  if (!always && !different) {
    return;
  }
  BITMAPINFO *bmi = (BITMAPINFO *)_alloca(sizeof(BITMAPINFOHEADER)+2*sizeof(RGBQUAD));
  ZeroMemory(bmi, sizeof(BITMAPINFOHEADER));
  bmi->bmiHeader.biSize = sizeof(BITMAPINFOHEADER);
  bmi->bmiHeader.biWidth = 160;
  bmi->bmiHeader.biHeight = -160;
  bmi->bmiHeader.biPlanes = 1;
  bmi->bmiHeader.biBitCount = 1;
  bmi->bmiHeader.biClrUsed = 2;
  bmi->bmiHeader.biClrImportant = 2;
  bmi->bmiColors[0].rgbRed   = GetRValue(background);
  bmi->bmiColors[0].rgbGreen = GetGValue(background);
  bmi->bmiColors[0].rgbBlue  = GetBValue(background);
  bmi->bmiColors[0].rgbReserved = 0;
  bmi->bmiColors[1].rgbRed   = GetRValue(foreground);
  bmi->bmiColors[1].rgbGreen = GetGValue(foreground);
  bmi->bmiColors[1].rgbBlue  = GetBValue(foreground);
  bmi->bmiColors[1].rgbReserved = 0;
  BYTE *bits;
  HBITMAP bmp = CreateDIBSection(dc, bmi, DIB_RGB_COLORS, (void **)&bits, NULL, 0);
  WORD *pbits = (WORD *)screenimage;
  for (int y = 0; y < 160; y++) {
    for (int x = 0; x < 160/8; x += 2) {
      bits[y*160/8+x] = *pbits >> 8;
      bits[y*160/8+x+1] = *pbits & 0xFF;
      pbits++;
    }
  }
  HDC mdc = CreateCompatibleDC(NULL);
  HBITMAP ob = (HBITMAP)SelectObject(mdc, bmp);
  if (Settings.Scale == 1) {
    BitBlt(dc, PlasticBaseX*Settings.Realistic, PlasticBaseY*Settings.Realistic, 160, 160, mdc, 0, 0, SRCCOPY);
  } else if (OSVersionInfo.dwPlatformId == VER_PLATFORM_WIN32_NT) {
    HDC tdc = CreateCompatibleDC(NULL);
    HBITMAP ob = (HBITMAP)SelectObject(tdc, CreateBitmap(160*Settings.Scale, 160*Settings.Scale, 1, 1, NULL));
    StretchBlt(tdc, 0, 0, 160*Settings.Scale, 160*Settings.Scale, mdc, 0, 0, 160, 160, SRCCOPY);
    BitBlt(dc, 0, 0, 160*Settings.Scale, 160*Settings.Scale, tdc, 0, 0, SRCCOPY);
    SetBkColor(dc, background);
    SetTextColor(dc, foreground);
    BitBlt(dc, PlasticBaseX*Settings.Realistic*Settings.Scale, PlasticBaseY*Settings.Realistic*Settings.Scale, 160*Settings.Scale, 160*Settings.Scale, tdc, 0, 0, SRCCOPY);
    DeleteObject(SelectObject(tdc, ob));
    DeleteDC(tdc);
  } else {
    StretchBlt(dc, PlasticBaseX*Settings.Realistic*Settings.Scale, PlasticBaseY*Settings.Realistic*Settings.Scale, 160*Settings.Scale, 160*Settings.Scale, mdc, 0, 0, 160, 160, SRCCOPY);
  }
  SelectObject(mdc, ob);
  DeleteDC(mdc);
  DeleteObject(bmp);
}

void PenEvent(HWND hwnd, LPARAM lparam, BOOL down)
{
  if (movedrag) {
    POINT p;
    p.x = (short)LOWORD(lparam);
    p.y = (short)HIWORD(lparam);
    ClientToScreen(hwnd, &p);
    p.x += DragOrigRect.left - DragBase.x;
    p.y += DragOrigRect.top  - DragBase.y;
    SetWindowPos(hwnd, NULL, p.x, p.y, 0, 0, SWP_NOSIZE|SWP_NOZORDER);
    movedrag = down;
    if (!movedrag) {
      ReleaseCapture();
    }
    return;
  }
  int x = LOWORD(lparam)/Settings.Scale - PlasticBaseX*Settings.Realistic;
  int y = HIWORD(lparam)/Settings.Scale - PlasticBaseY*Settings.Realistic;
  if (pentracking) {
    if (x < 0) x = 0;
    if (x >= 160) x = 160-1;
    if (y < 0) y = 0;
    if (y >= 160+60) y = 160+60-1;
    CPU_pen(down, x, y);
    pentracking = down;
    if (!pentracking) {
      ReleaseCapture();
    }
  } else if (keytracking) {
    keytracking = down;
    if (!keytracking) {
      ReleaseCapture();
      CPU_key(0, curkey);
    }
  } else if (down) {
    if (x >= 0 && x < 160 && y >= 0 && y <= 160+60) {
      SetCapture(hwnd);
      CPU_pen(1, x, y);
      pentracking = TRUE;
    } else if (PlasticBaseY+y >= 276 && PlasticBaseY+y < 318) {
      x += PlasticBaseX;
      y += PlasticBaseY;
      curkey = -1;
      if (x >= 0 && x < 17) {
        curkey = 0; // power
      } else if (x >= 25 && x < 53) {
        curkey = 3; // datebook
      } else if (x >= 64 && x < 92) {
        curkey = 4; // phone
      } else if (x >= 100 & x < 125) {
        if (y >= 280 && y < 292) {
          curkey = 1; // up
        } else if (y >= 302 && y < 314) {
          curkey = 2; // down
        }
      } else if (x >= 135 && x < 162) {
        curkey = 5; // todo
      } else if (x >= 174 && x < 200) {
        curkey = 6; // memo
      }
      if (curkey >= 0) {
        SetCapture(hwnd);
        CPU_key(1, curkey);
        keytracking = TRUE;
      }
    } else if (Settings.Realistic) {
      SetCapture(hwnd);
      GetWindowRect(hwnd, &DragOrigRect);
      DragBase.x = LOWORD(lparam);
      DragBase.y = HIWORD(lparam);
      ClientToScreen(hwnd, &DragBase);
      movedrag = TRUE;
    }
  }
}

void PopupMenu(HWND hwnd, int x, int y)
{
  POINT p = {x, y};
  ClientToScreen(hwnd, &p);
  HMENU apps = CreatePopupMenu();
  for (int i = 0; i < TSettings::MRU_COUNT; i++) {
    if (Settings.PrcMru[i][0] == 0) {
      break;
    }
    char buf[MAX_PATH];
    wsprintf(buf, "&%d %s", i+1, Settings.PrcMru[i]);
    AppendMenu(apps, MF_STRING, CM_LOADAPPMRU+i, buf);
  }
  if (i == 0) {
    AppendMenu(apps, MF_STRING|MF_GRAYED, 0, "(Empty)");
  }
  AppendMenu(apps, MF_SEPARATOR, 0, NULL);
  AppendMenu(apps, MF_STRING, CM_LOADAPP, "&Other...");
  HMENU m = CreatePopupMenu();
  AppendMenu(m, MF_STRING, CM_RESET, "&Reset");
  AppendMenu(m, MF_STRING, CM_HOTSYNC, "&HotSync");
  AppendMenu(m, MF_POPUP, (UINT)apps, "&Load app");
  AppendMenu(m, MF_STRING|MF_GRAYED, CM_DEBUG, "&Debugger");
  AppendMenu(m, MF_STRING, CM_EXIT, "E&xit");
  AppendMenu(m, MF_STRING, CM_ABOUT, "&About Copilot");
  AppendMenu(m, MF_SEPARATOR, 0, NULL);
  AppendMenu(m, MF_STRING, CM_PROPERTIES, "&Properties");
  TrackPopupMenu(m, TPM_LEFTALIGN|TPM_RIGHTBUTTON, p.x, p.y, 0, hwnd, NULL);
  DestroyMenu(m);
}

LRESULT CALLBACK DisplayWndProc(HWND hwnd, UINT msg, WPARAM wparam, LPARAM lparam)
{
  switch (msg) {
    case WM_CHAR:
      if (wparam == 13) {
        wparam = 10;
      }
      CPU_putkey(wparam);
      break;
    case WM_COMMAND:
      switch (wparam) {
        case CM_RESET:
          CPU_reset();
          break;
        case CM_HOTSYNC:
          CPU_hotsync(1);
          HotSyncDownStart = GetTickCount();
          break;
        case CM_LOADAPP:
          LoadApp();
          break;
        case CM_DEBUG:
          StartDebugger();
          break;
        case CM_EXIT:
          DestroyWindow(hwnd);
          break;
        case CM_ABOUT:
          DialogBox(GetModuleHandle(NULL), MAKEINTRESOURCE(IDD_ABOUT), hwnd, AboutDlgProc);
          break;
        case CM_PROPERTIES:
          Properties(hwnd);
          break;
        default:
          if (wparam >= CM_LOADAPPMRU && wparam < CM_LOADAPPMRU+TSettings::MRU_COUNT) {
            char fn[MAX_PATH];
            strcpy(fn, Settings.PrcMru[wparam-CM_LOADAPPMRU]);
            if (fn && DoLoadApp(fn)) {
              Settings.UpdateMru(fn);
            }
          }
          break;
      }
      break;
    case WM_CREATE: {
      CopilotWindow = hwnd;
      ResetWindow();
      break;
    }
    case WM_DESTROY:
      Settings.Save(CopilotWindow);
      KillTimer(hwnd, 1);
      PostQuitMessage(0);
      break;
    case WM_KEYDOWN:
      switch (wparam) {
        case VK_ESCAPE: CPU_key(1, 0); break;
        case VK_PRIOR : CPU_key(1, 1); break;
        case VK_NEXT  : CPU_key(1, 2); break;
        case VK_F1    : CPU_key(1, 3); break;
        case VK_F2    : CPU_key(1, 4); break;
        case VK_F3    : CPU_key(1, 5); break;
        case VK_F4    : CPU_key(1, 6); break;
        case VK_LEFT  : CPU_putkey(0x1c); break;
        case VK_RIGHT : CPU_putkey(0x1d); break;
      }
      break;
    case WM_KEYUP:
      switch (wparam) {
        case VK_ESCAPE: CPU_key(0, 0); break;
        case VK_PRIOR : CPU_key(0, 1); break;
        case VK_NEXT  : CPU_key(0, 2); break;
        case VK_F1    : CPU_key(0, 3); break;
        case VK_F2    : CPU_key(0, 4); break;
        case VK_F3    : CPU_key(0, 5); break;
        case VK_F4    : CPU_key(0, 6); break;
      }
      break;
    case WM_LBUTTONDOWN:
      PenEvent(hwnd, lparam, TRUE);
      break;
    case WM_LBUTTONUP:
      PenEvent(hwnd, lparam, FALSE);
      break;
    case WM_MOUSEMOVE:
      if (GetCapture()) {
        PenEvent(hwnd, lparam, TRUE);
      }
      break;
    case WM_PAINT: {
      PAINTSTRUCT ps;
      HDC dc = BeginPaint(hwnd, &ps);
      HPALETTE op;
      if (Settings.Realistic) {
        op = SelectPalette(dc, Palette, FALSE);
        RealizePalette(dc);
      }
      HDC mdc = CreateCompatibleDC(NULL);
      HBITMAP ob;
      if (Settings.Realistic) {
        StretchDIBits(dc, 0, 0, PlasticWidth*Settings.Scale, PlasticHeight*Settings.Scale, 0, 0, PlasticWidth, PlasticHeight, plasticBits, plasticBMI, DIB_RGB_COLORS, SRCCOPY);
      } else {
        if (Settings.Scale == 1) {
          ob = (HBITMAP)SelectObject(mdc, silkscreen);
          BitBlt(dc, 0, 160, 160, 60, mdc, 0, 0, SRCCOPY);
        } else {
          ob = (HBITMAP)SelectObject(mdc, silkscreen2);
          StretchBlt(dc, 0, 160*Settings.Scale, 160*Settings.Scale, 60*Settings.Scale, mdc, 0, 0, 320, 120, SRCCOPY);
        }
      }
      SelectObject(mdc, ob);
      DeleteDC(mdc);
      PaintScreen(dc, TRUE);
      if (Settings.Realistic) {
        SelectPalette(dc, op, TRUE);
      }
      EndPaint(hwnd, &ps);
      break;
    }
    case WM_PALETTECHANGED:
      if (HWND(wparam) == hwnd) {
        break;
      }
      /***** FALL THROUGH *****/
    case WM_QUERYNEWPALETTE: {
      if (Settings.Realistic) {
        HDC dc = GetDC(hwnd);
        HPALETTE op = SelectPalette(dc, Palette, FALSE);
        int n = RealizePalette(dc);
        SelectPalette(dc, op, TRUE);
        ReleaseDC(hwnd, dc);
        if (n > 0) {
          InvalidateRect(hwnd, NULL, FALSE);
        }
        return n;
      }
      break;
    }
    case WM_RBUTTONDOWN: 
      PopupMenu(hwnd, LOWORD(lparam), HIWORD(lparam));
      break;
    case WM_SYSKEYDOWN:
      switch (wparam) {
        case VK_F10   : PopupMenu(hwnd, 0, 0); break;
      }
      break;
    case WM_TIMER: {
      HDC dc = GetDC(hwnd);
      HPALETTE op;
      if (Settings.Realistic) {
        op = SelectPalette(dc, Palette, FALSE);
        RealizePalette(dc);
      }
      PaintScreen(dc, FALSE);
      if (Settings.Realistic) {
        SelectPalette(dc, op, TRUE);
      }
      ReleaseDC(hwnd, dc);
      if (HotSyncDownStart && GetTickCount() - HotSyncDownStart > 1000) {
        CPU_hotsync(0);
        HotSyncDownStart = 0;
      }
      if (!CPU_running()) {
        StartDebugger();
      }
      break;
    }
    default:
      return DefWindowProc(hwnd, msg, wparam, lparam);
  }
  return 0;
}

DWORD CALLBACK DoDisplayThread(void *)
{
  GetVersionEx(&OSVersionInfo);
  silkscreen = LoadBitmap(GetModuleHandle(NULL), MAKEINTRESOURCE(IDB_SILKSCREEN));
  silkscreen2 = LoadBitmap(GetModuleHandle(NULL), MAKEINTRESOURCE(IDB_SILKSCREEN2));
  
  plasticBMI = (BITMAPINFO *)LockResource(LoadResource(NULL, FindResource(NULL, MAKEINTRESOURCE(IDB_CASE), RT_BITMAP)));
  plasticBits = ((BYTE *)plasticBMI) + sizeof(BITMAPINFO)+255*sizeof(RGBQUAD);
  LOGPALETTE *lp = (LOGPALETTE *)malloc(sizeof(LOGPALETTE)+256*sizeof(PALETTEENTRY));
  lp->palVersion = 0x300;
  lp->palNumEntries = 256;
  for (int i = 0; i < 256; i++) {
    lp->palPalEntry[i].peRed = plasticBMI->bmiColors[i].rgbRed;
    lp->palPalEntry[i].peGreen = plasticBMI->bmiColors[i].rgbGreen;
    lp->palPalEntry[i].peBlue = plasticBMI->bmiColors[i].rgbBlue;
    lp->palPalEntry[i].peFlags = 0;
  }
  Palette = CreatePalette(lp);
  free(lp);

  CPU_setsounds(Settings.Sounds);

  WNDCLASS wc;
  ZeroMemory(&wc, sizeof(wc));
  wc.style = CS_HREDRAW | CS_VREDRAW;
  wc.lpfnWndProc = DisplayWndProc;
  wc.hIcon = LoadIcon(GetModuleHandle(NULL), MAKEINTRESOURCE(IDI_COPILOT));
  wc.hCursor = LoadCursor(NULL, IDC_ARROW);
  wc.lpszClassName = "PilotDisplay";
  RegisterClass(&wc);
  CopilotWindow = CreateWindow("PilotDisplay", "copilot", WS_CAPTION|WS_MINIMIZEBOX|WS_OVERLAPPED, Settings.Window.x, Settings.Window.y, CW_USEDEFAULT, CW_USEDEFAULT, NULL, NULL, 0, NULL);
  ShowWindow(CopilotWindow, SW_SHOW);
  if (Settings.DebugAtStartup) {
    StartDebugger();
  } else {
    CPU_run();
  }
  MSG msg;
  while (GetMessage(&msg, NULL, 0, 0)) {
    TranslateMessage(&msg);
    DispatchMessage(&msg);
  }
  DeleteObject(silkscreen);
  DeleteObject(silkscreen2);
  DeleteObject(Palette);
  return 0;
}

HANDLE DisplayThread = NULL;

HANDLE StartLCD()
{
  if (DisplayThread) {
    return DisplayThread;
  }
  DWORD tid;
  DisplayThread = CreateThread(NULL, 0, DoDisplayThread, 0, 0, &tid);
  return DisplayThread;
}
