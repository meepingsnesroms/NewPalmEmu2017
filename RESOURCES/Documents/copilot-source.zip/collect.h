/////////////////////////////////////////////////////////////////////////////
// Collect.h
//
// Simple task specifc collection classes
/////////////////////////////////////////////////////////////////////////////

#if !defined(__COLLECT_H__)
#define __COLLECT_H__

struct ElemPP // e
{
	void *pvKey;
	void *pv;
};

class MapPP // mp
{
public:
	MapPP();
	~MapPP();

	bool Add(void *pvKey, void *pv);
	bool Remove(void *pvKey);
	bool At(int i, void **ppvKey, void **ppv);
	int Find(void *pvKey, void **ppv);
	inline int GetCount()
	{
		return m_cMac;
	}

private:
	ElemPP *m_pe;
	int m_cMac;
	int m_cMax;
};

// Maintains a list of non-unique pointers

struct ElemLP // e
{
	void *pv;
};

class ListP // ls
{
public:
	ListP();
	~ListP();

	bool Add(void *pv);
	bool Remove(int i);
	void *At(int i);
	int Find(void *pv, int i = 0);
	inline int GetCount()
	{
		return m_cMac;
	}

private:
	ElemLP *m_pe;
	int m_cMac;
	int m_cMax;
};

const ulong kcElemAlloc = 5;

#endif // if !defined(__COLLECT_H__)