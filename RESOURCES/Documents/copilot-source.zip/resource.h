//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by copilot.rc
//
#define IDB_SILKSCREEN                  101
#define IDB_SILKSCREEN2                 102
#define IDB_CASE                        104
#define IDD_PROPERTIES                  106
#define IDR_MENU                        106
#define IDD_ABOUT                       108
#define IDI_COPILOT                     110
#define IDC_ZOOM2X                      1000
#define IDC_REALISTIC                   1001
#define IDC_BACKLIGHT                   1002
#define IDC_FPS                         1003
#define IDC_DEBUGATSTARTUP              1004
#define IDC_ABOUT_DATE                  1005
#define IDC_PORT                        1006
#define IDC_RAMSIZE                     1007
#define IDC_ROMFILE                     1008
#define IDC_BROWSE_ROMFILE              1009
#define IDC_SOUNDS                      1010
#define ID_VIEW_REGISTERS               40001
#define ID_VIEW_MEMORY                  40002
#define ID_VIEW_STACK                   40003
#define ID_VIEW_DISASSEMBLY             40004
#define ID_FILE_HIDE                    40005
#define ID_DEBUG_GO                     40006
#define ID_DEBUG_BREAK                  40007
#define ID_DEBUG_STEPINTO               40008
#define ID_DEBUG_STEPOVER               40009
#define ID_DEBUG_STEPOUT                40010
#define ID_DEBUG_RUNTOCURSOR            40011

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        111
#define _APS_NEXT_COMMAND_VALUE         40012
#define _APS_NEXT_CONTROL_VALUE         1011
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
