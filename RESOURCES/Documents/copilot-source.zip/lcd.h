// LCD control routines

HANDLE StartLCD();
