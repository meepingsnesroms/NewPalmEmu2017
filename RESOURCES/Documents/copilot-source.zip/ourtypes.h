/////////////////////////////////////////////////////////////////////////////
// OurTypes.h
//
// Shared type definitions
/////////////////////////////////////////////////////////////////////////////

#if !defined(__OurTypes_H__)
#define __OurTypes_H__

#include <Windows.h>

// Our favorite lower case types

typedef unsigned char byte;         // b
typedef unsigned char uchar;        // uchar
typedef unsigned short ushort;      // us
typedef unsigned long ulong;        // ul
//#pragma warning(disable : 4237)	    // disable bool keyword warning
//typedef BOOL bool;                  // f

#if defined(__cplusplus)

// Critical section class

class CriticalSection { // cs
public:
    CriticalSection()
    {
        InitializeCriticalSection(&m_cs);
    }

    ~CriticalSection()
    {
        DeleteCriticalSection(&m_cs);
    }

    void Enter()
    {
        EnterCriticalSection(&m_cs);
    }

    void Leave()
    {
        LeaveCriticalSection(&m_cs);
    }

private:
    CRITICAL_SECTION m_cs;
};

class FunctionCritical {    // fcs
public:
    FunctionCritical(CriticalSection *pcs) {
        m_pcs = pcs;
        m_pcs->Enter();
    }

    ~FunctionCritical() {
        m_pcs->Leave();
    }

private:
    CriticalSection *m_pcs;
};

#define ProtectFunction(pcs) FunctionCritical fcs(pcs)

// Position class, used for enumeration

const ulong kPosFirst = (ulong)-1;

class Position { // pos
public:
    Position()
    {
        m_pvNext = (void *)kPosFirst;
        m_ulUser = kPosFirst;
    }
    void Reset()
    {
        m_pvNext = (void *)kPosFirst;
        m_ulUser = kPosFirst;
    }

    void *m_pvNext;
    ulong m_ulUser;
};

// OosDeleter class, for deleting items when they go out of
// scope. Note that this is for void * objects only (meaning
// only operator delete() is going to get called!)

class OosDeleter { // osd
public:
    inline OosDeleter(void **ppv)
    {
        m_ppv = ppv;
    }
    inline ~OosDeleter()
    {
        delete *m_ppv;
    }

private:
    void **m_ppv;
};

// Use line number for uniqueness in naming, since this can be used
// multiple times within one scope. Use void ** so item can be
// allocated some time after OosDeleter construction (such as global
// variables)

#define OosDelete(pv) OosDeleter osd##__LINE__((void **)&##pv)

// Since we have WIN32_LEAN_AND_MEAN defined, PURE isn't defined for us

#define PURE = 0

#endif // !defined(__cplusplus)

#endif // !defined(__OurTypes_H__)
