// Copilot main
//
// Copyright (c) 1996 Greg Hewgill

#include <windows.h>
#pragma hdrstop

#include "lcd.h"
#include "pilotcpu\pilotcpu.h"
#include "settings.h"

#include "resource.h"

static const char *CpuInitErrors[] = {
  "",
  "Pilot.ROM file not found",
  "Error loading Pilot.ROM file",
  "Error loading Pilot.RAM file",
};

int WINAPI WinMain(HINSTANCE, HINSTANCE, LPSTR, int)
{
  HANDLE commhandle = NULL;
  if (strnicmp(Settings.CommPort, "COM", 3) == 0) {
    commhandle = CreateFile(Settings.CommPort, GENERIC_READ|GENERIC_WRITE, 0, NULL, OPEN_EXISTING, FILE_FLAG_OVERLAPPED, NULL);
    if (commhandle == INVALID_HANDLE_VALUE) {
      char buf[MAX_PATH];
      wsprintf(buf, "Communications port %s already in use", Settings.CommPort);
      MessageBox(NULL, buf, "Copilot", MB_OK);
      commhandle = NULL;
    }
  }
  int r = CPU_init(commhandle, Settings.RamSize, Settings.RomFile);
  if (r != 0) {
    MessageBox(NULL, CpuInitErrors[r], "Copilot", MB_OK);
    return 0;
  }

  WaitForSingleObject(StartLCD(), INFINITE);

  return 0;
}
