/////////////////////////////////////////////////////////////////////////////
// rip.h
/////////////////////////////////////////////////////////////////////////////
//
// This module contains all the macros that do rips. Those are:
//
// Assertion macros
// Warning macros
// Bad Param macros
// Rip macros
//
// All of this below code does not compile into retail builds. All the code
// for rips is defined in \utopia\rip.cpp.
//
/////////////////////////////////////////////////////////////////////////////

#if !defined(__RIP_H__)
#define __RIP_H__

// Remove old definition.

#ifdef Assert
#undef Assert
#endif

#if defined(_DEBUG)


// These are macroized solely so they can be redefined. This is useful
// if the below macros are going to be used in helper functions where you
// want the file and line of the caller and not the helper function.

#define __XFILE __FILE__
#define __XLINE __LINE__

//
// The below macros constitute system support for asserts, warnings,
// bad param reporting, and rips.  These are macros and not inlines
// so that __XFILE & __XLINE values are set to where the macro is
// used, where that information is most useful.
//
// The macros are:
//
//   Assert(f, ...)
//      Standard assertion macro.  If present, the second parameter is a
//      sprintf format string.
//
//   Warning(f, ...)
//      Used for debugging or interesting things only the developer wants to
//      see. In [ms-bob] section, set Warnings=1 to see these warnings.
//      If present, the second parameter is a sprintf format string.
//
//   BadParam(psz, ...)
//      For use in validation routines or custom validation. First parameter
//      is a sprintf format string.
//
//   Rip(psz, ...)
//      For generic use anywhere. First parameter is a sprintf format string.

// These globals need to be defined for rip to work.

extern char *gpszRipFile;
extern int giRipLine;

void DoAssertRip(BOOL fAssert, char *psz, ...);
void DoAssertRip(BOOL fAssert);
void DoWarningRip(BOOL fWarn, char *psz, ...);
void DoWarningRip(BOOL fWarn);
void DoBadParamRip(char * psz, ...);
void DoGenericRip(char * psz, ...);

#define Assert   gpszRipFile = __XFILE, giRipLine = __XLINE, ::DoAssertRip
#define Warning  gpszRipFile = __XFILE, giRipLine = __XLINE, ::DoWarningRip
#define BadParam gpszRipFile = __XFILE, giRipLine = __XLINE, ::DoBadParamRip
#define Rip      gpszRipFile = __XFILE, giRipLine = __XLINE, ::DoGenericRip

#else // _DEBUG

// This hack allows us to create varargs macros that compile to nothing
// on retail.

inline void DoConditionalRip(BOOL, ...) { }
inline void DoGenericRip(char *, ...) { }

#define Assert             1 ? (void)0 : ::DoConditionalRip
#define Warning            1 ? (void)0 : ::DoConditionalRip
#define BadParam           1 ? (void)0 : ::DoGenericRip
#define Rip                1 ? (void)0 : ::DoGenericRip

#endif // _DEBUG

#endif // !defined(__RIP_H__)

