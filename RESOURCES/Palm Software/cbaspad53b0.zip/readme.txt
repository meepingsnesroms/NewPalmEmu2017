README for  cbasPad5 for PalmOS 5, version 5.3b

This is mostly a toy, but also a demonstration of what can be done
using PalmOS 5 ARM/PNOlets (accelerated native ARM RISC CPU code
modules).

cbasPad5 is a Basic Programming language interpreter, based on the
original 1996 PalmPilot version of cbasPad.  It does not have any of
the database commands or special functions included in HotPaw Basic.

(But... cbasPad5 should run Basic programs a little faster. :-)

cbasPad5 only runs on PalmOS 5 handhelds.  This is beta test
experimental code.  It is only for use at your own risk, on a fully
backed-up handheld where you don't mind program crashes and resets.

This release of cbasPad5 is Free for educational, experimental and
non-commercial personal use.

If you don't know how to program in Basic, this is a very poor
application with which to start learning.

Operation:

Enter a Basic program line or command and hit the "enter" button.

Program lines can start with a line number.  Example:

new
10 for i=1 to 10
20 print i,
30 next i
40 end
run

You can also load text in from a MemoPad Memo by using the "Import"
menu selection, then entering the title of the Memo (the first few
characters will do, as long as they are unique).

--
Command Summary:

# lines starting with the '#' character are comments

  :' this is also a non executable comment
  : rem - this is another comment
  
Program lines must be preceded by a line number.

  10 print 1+1	:' is a program line.

  print 2+2	:' is a direct execution command.

  run	:' start running the program in memory
  new	:' clears a program out of memory


Basic Language: Statement, Function Summary:

Operators, Statements, Functions and other reserved Keywords:

  Operators:
  
    +  -  *  /  mod  ^
    =   <>  >  >=  <  <=   and  or  xor  not
    &

  Commands and Statement Keywords:
  
    let 
    if  then  else endif  elseif
    for  to  step  next
    while wend exit
    goto  gosub  return
    end  run  new  stop  :  rem
    dim
    data read restore
    randomize

  Functions:
  
    int() abs() sgn()  rnd()
    sqr() exp() log() log10()  sin() cos() tan() atn() 
    len()  val()  str$() chr$() hex$() mid$() asc()
    ucase$() lcase$() right$() left$() field$() instr()
    eval()
    pi
    
  Special functions and commands:
  
    print  ?  input
    peek()  varptr()
    def fn
    fn timer()
    fn moveto
    fn lineto
    
  Reserved words (for future use):
    option base  pi
    output append load save  random lof loc get
    files  fseek  usr  bload bsave  exec
    quit cont  renum  clear elseif
    date$ time$ timer  erase  say
    home cls gotoxy htab vtab pos  button field
    graphics sprite pset moveto lineto window scrn
    push pop  isarray  mat  select case  function
    type class extends  string integer double
    sinh cosh tanh floor ubound  err erl
    dprint tab  sub()  end sub
    fre   timer poke  call  form
    on as  using open close  eof
    db db$() get$() put find() kill
    

Variables and Constants:

  Variable names may be up to 15 characters in length.
  
  Floating point constants may use the "e" notation.
    e.g. 7.0, -3.5e10, 6.022e23, 6.6261e-34

  Floating point numbers and variable are represented by a format
  similar to IEEE double.  This is a binary format, which means
  that many decimal fractions will not be exactly represented.

  Hex constants may be entered by preceding with "0x".
  
  Integer variable names end with the '%' character.
  Alternately, an integer variable name may be defined by:
    dim x as integer
  Integer variables are stored as 32-bit signed integers.

String Variables:

  String variables end with the '$' character.
  Alternately, a string variable name may be defined by:
    dim a as string

  There is a limit of 7 string variables.
  Strings may contain a maximum of 126 or 127 characters.

  String arrays must be dimensioned before use. String arrays are
  limited to one dimension and may not be redimensioned.

  There is 1 built-in string array: s$(), auto-dimensioned to
  8 elements: e.g. s$(0) .. s$(7)
  
Numeric Arrays:

    dim a(10), b(10,10)
    
  Creates and allocates memory for an array.  Numeric arrays must
  be dimensioned before use with the DIM statement.  Numeric
  array may be multidimensional but are limited to 3 dimensions.
  
    option base 0
    
  Only option base 0 is allowed. Arrays indexes start with 0
  (zero), so dim a(n) creates an array with n+1 elements.
	

Expressions and Operators

  Assignment:
    
    let a = b + 2
    
  Using the "let" keywoard before an assignment is optional.
    
    a = b + 3
	
  Arithmetic expressions are limited in complexity to around
  8 levels of parenthesis so as to not overflow the very small
  PalmOS application stack.
   
    a = (b^2 + (d/(2+2))) * c

  The "and", "or" and "xor" operators do bit-wise operations;
  "not" is a boolean operator and only returns 1 or 0.
    
  Use either the "&" or the "+" operator for string concatenation.
  
    a$ = "hello "
    b$ = a$ & "there!"	:' -> result is the string "hello there!"

Flow-of-Control Statements

    :
    	A colon may be used to seperate multiple statements
    	on one line.

    end

  	Program execution ends at the first end or stop command.

    if then endif

    	Standard single line IF THEN
    	
    		if x > 1 then y = 2
    		if y = 3 then goto 300
 
    	Multistatement IF THEN  (acts as a single block if-endif)
    	
    		if x > 1 then y = 2 : z = 3
 
    	Multiline block IF ENDIF  (No "then" keyword used.)
    	
    		30 if (x > 1)
    		40 	y = 2
    		50 	z = 3
    		60 endif


    for step next

    	20 for i=1 to 5 step 2
    	30   print i
    	40 next i

    while wend

    	30 n = 1
    	40 while (n < 100) : rem - loop until this condition is false
    	50   n = n * 2
    	60 wend
    	70 print n

    gosub sub return

    	Standard BASIC subroutine usage:
    		100 gosub 500
    		200 end
    		:' ...
    		500 print x+1
    		510 return

    	Named subroutines usage:
    		100 gosub foo(5)
    		190 end
    		:' ...
    		600 sub foo(x)
    		610 print x+1
    		620 end sub

    	(Note that HotPaw Basic user-defined subroutines
    	are static (no true local variables), and may not
    	be used recursively.  The name of a user-defined
    	subroutine may be used as a global return variable.)

    goto N

    	(No example.  See old Basic programming books.)

    on N goto M

    	(No example.  See old Basic programming books.)

	
Input/Output Statements:

    print x
    	Prints out a variable.
    print a$
    	Prints out a string.
    	
    input a$
    	Inputs a string variable (line-input only).
    input "prompt:", a$
    	Inputs a string after displaying a prompt string.
    	
Built-in Special functions:

    fn timer(1)
    	Returns the seconds clock
    fn timer(100)
    	Returns the 100ths of a second timer.
    	
    fn moveto( x, y )
    	Sets the start point of a line
    fn lineto( x, y )
    	Draws a graphic line to the x,y coordinate.
    	
    fn byteswap32( x )
    	Swaps integer byte-order between ARM & 68k.
    fn bswap64( x )
    	Swaps floating point byte order between ARM & 68k.
    	
    	
Warning: If you use unsupported commands or syntax, cbasPad5
should report an error, but it's possible that it may just
crash and soft reset your handheld.

--
Version History:

Version 5.3b0  -  2004Feb19
 - Compiled with Codewarrior v9.3 for better optimization.
 - Fixed a data alignment bug.
Version 5.2a4  -  2003-Dec-10
 - Added s$(0) string parameters to yBasic fn cbas5x() call.
 - Added fn bswap32().
Version 5.0a7  -  2003-Feb-21
 - Fixed print speed bug.
Version 5.0a3  -  2003-Jan-10
 - First public alpha test release
 
--
This application is free for non-commercial and personal use.
No warranties of any kind implied.

See  <http://www.hotpaw.com/rhn/hotpaw>  for updates, and for
other HotPaw applications.      email: rhn@hotpaw.com

Copyright 2003 HotPaw Software.  All Rights Reserved.
--
